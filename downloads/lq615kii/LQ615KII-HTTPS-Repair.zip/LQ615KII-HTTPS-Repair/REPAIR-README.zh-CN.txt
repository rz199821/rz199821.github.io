LQ615KII HTTPS 小修复包

适用于已安装v2、手机可发现但选择后卡在收集打印机信息的Mac。

1. 保留原Downloads里的LQ615KII-AirPrint-v2.0.1文件夹（包括.build）。
2. 在该Mac双击Repair-TLS.command。它自动寻找并核对缓存源码、修复重复加锁、重新链接和签名。
3. 工具先验证候选接收服务的真实HTTPS握手和加密IPP查询，不打印；通过后才更新本工具后台程序。
4. 出现“HTTPS接收服务已修复并通过加密IPP自检”后，关闭iPhone打印面板，重新打开并选择LQ615KII iPhone v2。确认241x140mm后只测1页1份。

修复期间不修改Mac USB驱动，不发送打印任务，不关闭TLS或证书检查。若检查失败，工具会显示诊断内容；请保留输出。

源码级重复加锁已核对，Linux实际HTTPS及完整转换流程31项检查通过。Mac原生HTTPS与iPhone结果仍以本次实测为准。
