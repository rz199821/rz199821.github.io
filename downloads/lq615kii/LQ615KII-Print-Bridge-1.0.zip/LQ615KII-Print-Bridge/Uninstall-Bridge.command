#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
/bin/bash bridge/Uninstall-AirPrint.command
