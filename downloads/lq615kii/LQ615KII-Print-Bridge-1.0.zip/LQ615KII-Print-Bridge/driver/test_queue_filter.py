"""Linux integration tests for the actual CUPS filter, with a controlled PDF
renderer stand-in and the real ESC/P encoder. Never opens a printer."""
from pathlib import Path
import tempfile, subprocess, os, unittest, shutil, signal, time
ROOT=Path(__file__).parent
class QueueFilterTest(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.tmp=tempfile.TemporaryDirectory(prefix='lq615-test-'); cls.r=Path(cls.tmp.name)
  cls.prefix=cls.r/'driver'; cls.prefix.mkdir()
  subprocess.run(['cc','-std=c11','-O2','-Wall','-Wextra','-Werror',str(ROOT/'pbmto615.c'),'-o',str(cls.prefix/'pbmto615')],check=True)
  subprocess.run(['cc','-std=c11','-O2','-Wall','-Wextra','-Werror','-DLQ_PREFIX="'+str(cls.prefix)+'"',str(ROOT/'lq615filter.c'),'-l:libcups.so.2','-o',str(cls.r/'filter')],check=True)
  stub=cls.prefix/'pdf615'
  stub.write_text('''#!/usr/bin/env python3
import sys, pathlib, time
args=sys.argv
if args[1]=='count':
 print(2); sys.exit(0)
page=args[3]
if pathlib.Path(args[2]).read_bytes().endswith(b'FAIL') and page=='2':
 print('ERROR: simulated later-page renderer failure',file=sys.stderr);sys.exit(9)
if pathlib.Path(args[2]).read_bytes().endswith(b'SLOW'):
 time.sleep(30)
assert args[5]=='-'
assert args[6] in ('90','85')
assert args[7] in ('128','192')
assert args[8]=='ink-center'
pathlib.Path(args[4]).write_bytes(b'P4\\n2 1\\n'+(b'\\x80' if page=='1' else b'\\x40'))
''')
  stub.chmod(0o755)
  cls.pdf=cls.r/'sample with spaces;$(never).pdf'; cls.pdf.write_bytes(b'%PDF-1.3\nTEST')
  cls.jobtmp=cls.r/'jobs';cls.jobtmp.mkdir()
 @classmethod
 def tearDownClass(cls):cls.tmp.cleanup()
 def runjob(self,options='',copies='1',path=None,stdin=False):
  env=os.environ.copy();env['TMPDIR']=str(self.jobtmp);env.pop('PPD',None)
  args=[str(self.r/'filter'),'1','testuser','job',copies,options]
  if not stdin:args.append(str(path or self.pdf))
  return subprocess.run(args,input=self.pdf.read_bytes() if stdin else None,capture_output=True,env=env)
 def assert_clean(self):self.assertEqual(list(self.jobtmp.iterdir()),[])
 def test_file_job_produces_real_protocol_and_no_text(self):
  p=self.runjob();self.assertEqual(p.returncode,0,p.stderr)
  self.assertTrue(p.stdout.startswith(b'\0\0\0\x1b\x01@EJL'))
  self.assertEqual(p.stdout.count(b'\0\0\0\x1b\x01@EJL'),2)
  self.assertNotIn(b'INFO:',p.stdout);self.assertIn(b'PAGE: 2 1',p.stderr);self.assert_clean()
 def test_stdin_and_ranges(self):
  a=self.runjob('page-ranges=2',stdin=True);b=self.runjob('page-ranges=1')
  self.assertEqual(a.returncode,0,a.stderr);self.assertEqual(b.returncode,0,b.stderr)
  self.assertEqual(a.stdout.count(b'\0\0\0\x1b\x01@EJL'),1)
  self.assertNotEqual(a.stdout,b.stdout);self.assert_clean()
 def test_explicit_options_and_queue_defaults(self):
  p=self.runjob('LQScale=S85 LQInk=Dark LQX=-1 LQY=2');self.assertEqual(p.returncode,0,p.stderr)
  ppd=self.r/'defaults.ppd';ppd.write_text('*DefaultLQScale: invalid\n')
  env=os.environ.copy();env['TMPDIR']=str(self.jobtmp);env['PPD']=str(ppd)
  p=subprocess.run([str(self.r/'filter'),'1','u','t','1','',str(self.pdf)],capture_output=True,env=env)
  self.assertNotEqual(p.returncode,0);self.assertEqual(p.stdout,b'');self.assert_clean()
 def test_later_page_failure_sends_zero_bytes(self):
  f=self.r/'fail.pdf';f.write_bytes(b'%PDF-1.3\nFAIL')
  p=self.runjob(path=f);self.assertNotEqual(p.returncode,0);self.assertEqual(p.stdout,b'');self.assert_clean()
 def test_bad_settings_and_ranges_rejected(self):
  for options in ['LQScale=S100','LQInk=garbage','LQX=11','LQY=-1','PageSize=A4','sides=two-sided-long-edge','number-up=2','page-set=odd','page-ranges=0','page-ranges=2-1','page-ranges=3','page-ranges=1,','outputorder=reverse']:
   with self.subTest(options=options):
    p=self.runjob(options);self.assertNotEqual(p.returncode,0);self.assertEqual(p.stdout,b'');self.assert_clean()
  p=self.runjob(copies='2');self.assertNotEqual(p.returncode,0);self.assertEqual(p.stdout,b'')
 def test_non_pdf_is_not_forwarded(self):
  f=self.r/'not.pdf';f.write_bytes(b'NOT PDF')
  p=self.runjob(path=f);self.assertNotEqual(p.returncode,0);self.assertEqual(p.stdout,b'');self.assert_clean()
 def test_cancellation_during_conversion_emits_nothing(self):
  f=self.r/'slow.pdf';f.write_bytes(b'%PDF-1.3\nSLOW')
  env=os.environ.copy();env['TMPDIR']=str(self.jobtmp);env.pop('PPD',None)
  p=subprocess.Popen([str(self.r/'filter'),'1','u','t','1','',str(f)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env)
  time.sleep(0.4);p.send_signal(signal.SIGTERM);out,err=p.communicate(timeout=5)
  self.assertNotEqual(p.returncode,0);self.assertEqual(out,b'');self.assert_clean()
if __name__=='__main__':unittest.main(verbosity=2)
