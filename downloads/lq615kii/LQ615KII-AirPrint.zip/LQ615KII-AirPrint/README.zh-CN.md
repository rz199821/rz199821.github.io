# iPhone → Mac → USB LQ-615KII：AirPrint发现桥接试验

架构：手机通过局域网访问Mac已有CUPS PDF队列，Mac继续用已验证的90%/顶部对齐驱动输出到USB打印机。iPhone不安装针式驱动，也不把USB插到手机。

**当前是试验接入包。** 已有的Mac系统打印已实测成功，但本包的Mac后台发现服务、iPhone识别、手机纸型和实际AirPrint打印尚未验证，不能称为已完成的AirPrint驱动或Apple认证产品。只发布Bonjour名称不等于能打印。

## 准备条件

- 选一台已经通过⌘P打印的Mac作为固定桥接机，USB连接LQ-615KII；不用在所有Mac上都装桥接服务。
- Mac保持登录、开机、不休眠。合盖、退出登录或关机通常会让服务不可用。工具不修改全局电源设置。
- iPhone与Mac接入互通的同一个可信局域网；不要用隔离的访客Wi-Fi。Wi-Fi频段可不同，只要路由器允许相互访问。
- 当前适配普通私有IPv4 LAN；IPv6-only、跨网段、VPN远程打印未实现。
- 沿用241×140mm PDF、单张进纸和每任务一份的范围。先测试一页。

## 1. 仅共享这一个打印队列

在桥接Mac打开：系统设置 → 通用 → 共享 → 打印机共享。

打开该功能，在打印机列表中仅勾选`LQ-615KII 241x140 Local PDF`（内部队列名`LQ615KII_Local241`）。手机没有Mac账号时，通常需在该队列的用户权限中允许“所有人”打印；这意味着允许可信局域网内的设备使用这台共享打印机，应在你信任的网络上操作。

不要开启路由器公网端口转发，不要关闭整个系统防火墙，也不要把其他打印机全部勾上。若系统提示本地网络/共享访问权限，按需要允许该本机打印共享服务。

脚本不会替你修改cupsd.conf、系统共享开关、账号权限、防火墙或其他队列。共享本身仍由macOS设置管理。

## 2. 安装发现辅助服务（一次）

解压到下载目录，文件夹名`LQ615KII-AirPrint`，终端执行：

```sh
bash "$HOME/Downloads/LQ615KII-AirPrint/Install-AirPrint.command"
```

它使用现有Apple开发工具编译一个小的CUPS协议检查器，不需要完整Xcode、Python、Homebrew或Ghostscript，也不需要再次安装针式驱动。

安装器会检查本地队列共享状态、PDF支持、局域网地址访问，并发送**不创建任务的Validate-Job**查询，检查241×140mm、单份、单面是否被接受。拒绝或替换纸型、需要凭据、无法访问时，会停止，不发布虚假的“可打印”状态。整个安装不上传PDF，也不发送测试打印。

成功后在当前用户的后台运行Bonjour发现服务，随用户登录自动启动，关闭终端不影响它。只在共享队列检查通过时公告名称，网络地址或队列UUID改变时重新注册。它复用Mac的IPP端口631，不新建HTTP打印服务器。

## 3. 手机测试

iPhone打开原来那份241×140mm PDF → 共享 → 打印 → 选择`LQ615KII iPhone PDF`。

系统可能按相同队列UUID合并发现名称，届时也可能显示原队列名称。若手机根本看不到，先不要反复发送任务，用下面检查工具反馈。

第一次先检查手机打印预览与纸张大小：必须是对应单张纸，不能已被手机重排到A4后再交给Mac。如果没有可用纸型、预览内容缺失或变成A4，请先取消，发手机界面。不假定手机会保留原PDF尺寸。

确认后装好纸，选择1页、1份打印。Mac驱动继续内部90%、左右居中、顶部对齐，标准较细。iPhone是否选择PDF格式、传来的页边界/缩放是否如预期，都必须由实际作业验证。

手机无需每次打开Mac终端；但桥接Mac必须在线，打印机USB必须接着。

## 4. 检查和撤销

只读检查，不打印：

```sh
bash "$HOME/Downloads/LQ615KII-AirPrint/Check-AirPrint.command"
```

它显示Mac队列、IPP检查和本工具日志。日志可能含局域网地址，不要直接公开整份记录。安装或发现失败，先提供末尾错误和手机打印界面。

卸载发现辅助服务：

```sh
bash "$HOME/Downloads/LQ615KII-AirPrint/Uninstall-AirPrint.command"
```

只移除本工具的当前用户LaunchAgent和安装文件，不删现有Mac驱动或队列。你在系统设置中开启的打印机共享不会被脚本自动关闭；不再需要时自行取消该队列共享。日志保留在`~/Library/Logs/LQ615KII-AirPrint`，可按需要自行删除。

安装位置：

- `~/Library/Application Support/LQ615KII-AirPrint`（检查器、运行脚本、标记）。
- `~/Library/LaunchAgents/local.lq615kii.airprint.plist`。
- `~/Library/Logs/LQ615KII-AirPrint`。

遇到已有同名服务/目录时不覆盖。此服务只在当前Mac用户登录后运行，不是开机未登录也能工作的系统守护进程。

## 能力公告的边界

Bonjour使用`_ipp._tcp`及`_universal`子类型，目标为已有`printers/LQ615KII_Local241`，UUID取自实际队列，仅公告`application/pdf`。`URF=none`表示本包没有实现URF光栅输入，不会虚构已实现的格式能力。

这是PDF-only兼容性试验，不保证所有iOS版本接受这组公告或自定义纸型。需要真实iPhone验证发现、IPP属性查询、作业提交和纸面结果；若手机要求URF或其他特性，需后续增加经过验证的接收/转换路径，不能只补一个格式字符串假装支持。

本包不开放新的公网入口、不上传文件到云端；文档由局域网的Mac打印服务接收，使用已有共享策略。请勿把局域网打印口映射到公网。

## 已做与待做的检查

已执行：C11严格编译；实际libcups客户端对loopback IPP测试服务的8项集成测试。覆盖共享关闭、没有PDF格式、需要认证、纸型拒绝/替换、队列UUID匹配和正常查询。捕获的操作仅为Get-Printer-Attributes与Validate-Job，没有Print-Job、Send-Document或PDF文档数据。所有shell入口语法检查通过。

尚未执行：Mac SDK编译、macOS共享设置与LAN实际权限、LaunchAgent/Bonjour发布、本地网络隐私许可、iPhone发现与打印、手机自定义纸型、USB实际输出。不能用云端协议测试替代这些项目。

本包没有内置用户PDF、打印数据、照片、设备序列号或本地网络地址。源码基于CUPS公开IPP/DNS-SD接口；Mac驱动包的单机打印成功不等于本AirPrint流程已验证。

参考：

- https://github.com/apple/cups/blob/v2.3.6/scheduler/dirsvc.c
- https://github.com/apple/cups/blob/v2.3.6/scheduler/printers.c
