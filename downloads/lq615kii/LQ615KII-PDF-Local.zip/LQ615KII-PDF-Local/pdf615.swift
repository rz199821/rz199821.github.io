import Foundation
import AppKit
import PDFKit

func fail(_ message: String) -> Never {
    FileHandle.standardError.write(Data(("ERROR: " + message + "\n").utf8))
    exit(1)
}
let args = CommandLine.arguments
guard args.count >= 3 else { fail("usage: pdf615 count file.pdf | render file.pdf page output.pbm preview.png") }
guard let document = PDFDocument(url: URL(fileURLWithPath: args[2])) else { fail("Cannot open PDF") }
guard !document.isLocked else { fail("Password-protected PDF: export an unlocked copy first") }
if args[1] == "count" {
    guard args.count == 3, document.pageCount > 0 else { fail("Empty PDF or invalid arguments") }
    print(document.pageCount)
    exit(0)
}
guard args[1] == "render", args.count == 6,
      let number = Int(args[3]), number > 0, number <= document.pageCount,
      let page = document.page(at: number - 1) else { fail("Invalid page or arguments") }
// 100% mode: accept only a page matching the actual paper. Never silently
// fit an A4 page or crop a larger drawing down to this sheet.
let bounds = page.bounds(for: .cropBox)
guard page.rotation % 360 == 0 else { fail("Rotated PDF pages need to be exported with rotation applied before this original-size test") }
let mmWidth = Double(bounds.width) * 25.4 / 72.0
let mmHeight = Double(bounds.height) * 25.4 / 72.0
guard abs(mmWidth - 241.0) < 0.5, abs(mmHeight - 140.0) < 0.5 else {
    fail("100% mode requires a 241x140mm PDF page; this page is \(mmWidth)x\(mmHeight)mm. No shrinking or cropping was performed")
}
let width = Int((Double(bounds.width) * 180.0 / 72.0).rounded())
let height = Int((Double(bounds.height) * 180.0 / 72.0).rounded())
guard width <= 1708, height <= 992 else { fail("Page raster exceeds the original-size test limits") }
// PDFKit renders embedded fonts and respects PDF page rotation. This uses
// native PDFKit; no PDF or printer data is sent over the network.
let thumbnail = page.thumbnail(of: NSSize(width: CGFloat(width), height: CGFloat(height)), for: .cropBox)
guard let image = thumbnail.cgImage(forProposedRect: nil, context: nil, hints: nil) else { fail("PDF rendering failed") }
let bitmap = NSBitmapImageRep(cgImage: image)
let scale = min(Double(width) / Double(bitmap.pixelsWide), Double(height) / Double(bitmap.pixelsHigh))
let drawWidth = max(1, min(width, Int((Double(bitmap.pixelsWide) * scale).rounded())))
let drawHeight = max(1, min(height, Int((Double(bitmap.pixelsHigh) * scale).rounded())))
let offsetX = (width - drawWidth) / 2, offsetY = (height - drawHeight) / 2
let stride = (width + 7) / 8
var bits = [UInt8](repeating: 0, count: stride * height)
// NSBitmapImageRep row coordinates address the rendered image top-to-bottom;
// do not introduce another PDF coordinate flip. Verify on the first page.
for y in 0..<drawHeight {
    let sy = min(bitmap.pixelsHigh - 1, Int((Double(y) + 0.5) / scale))
    for x in 0..<drawWidth {
        let sx = min(bitmap.pixelsWide - 1, Int((Double(x) + 0.5) / scale))
        guard let color = bitmap.colorAt(x: sx, y: sy)?.usingColorSpace(.deviceRGB) else { fail("Unable to read rendered pixel") }
        let alpha = Double(color.alphaComponent)
        let luminance = 255.0 * (alpha * (0.2126 * Double(color.redComponent) + 0.7152 * Double(color.greenComponent) + 0.0722 * Double(color.blueComponent)) + 1.0 - alpha)
        // Slightly dark threshold helps retain fine invoice strokes at 180dpi.
        if luminance < 192.0 {
            let dx = x + offsetX, dy = y + offsetY
            bits[dy * stride + dx / 8] |= UInt8(0x80 >> (dx % 8))
        }
    }
}
var pbm = Data("P4\n\(width) \(height)\n".utf8)
pbm.append(contentsOf: bits)
// Write a preview of the exact thresholded PBM pixels, not a second rendering.
guard let preview = NSBitmapImageRep(bitmapDataPlanes: nil, pixelsWide: width, pixelsHigh: height,
    bitsPerSample: 8, samplesPerPixel: 1, hasAlpha: false, isPlanar: false,
    colorSpaceName: .deviceWhite, bytesPerRow: width, bitsPerPixel: 8),
    let pixels = preview.bitmapData else { fail("Preview allocation failed") }
for y in 0..<height { for x in 0..<width {
    pixels[y * preview.bytesPerRow + x] = bits[y * stride + x / 8] & UInt8(0x80 >> (x % 8)) != 0 ? 0 : 255
} }
guard let png = preview.representation(using: .png, properties: [:]) else { fail("Preview encoding failed") }
do {
    try pbm.write(to: URL(fileURLWithPath: args[4]), options: .atomic)
    try png.write(to: URL(fileURLWithPath: args[5]), options: .atomic)
} catch { fail(error.localizedDescription) }
print("Page \(number): \(width)x\(height) monochrome; 100 percent original-size raster; physical printer margins still need verification")
