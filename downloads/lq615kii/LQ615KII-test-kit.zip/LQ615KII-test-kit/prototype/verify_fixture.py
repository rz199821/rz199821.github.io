"""Independently decode generated ESC * bands; compare every printable pixel."""
from pathlib import Path
r=Path(__file__).parent/'fixtures'
p=(r/'calibration.pbm').read_bytes()
# Ghostscript fixture header; do not use the filter's input parser.
lines=p.split(b'\n',4)
assert lines[0]==b'P4' and lines[1].startswith(b'#')
w,h=map(int,lines[2].split()); raster=p[p.index(lines[2])+len(lines[2])+1:]
assert len(raster)==((w+7)//8)*h
wire=(r/'calibration.prn').read_bytes()
start=bytes([13,27,36,44,0,27,42,39,w&255,w>>8]); index=wire.index(start)
recovered=bytearray(len(raster)); stride=(w+7)//8
for y in range(0,h,24):
 assert wire[index:index+len(start)]==start; index+=len(start)
 band=wire[index:index+w*3]; assert len(band)==w*3; index+=w*3
 for x in range(w):
  for k in range(24):
   if y+k<h and band[x*3+k//8] & (128>>(k%8)):
    recovered[(y+k)*stride+x//8] |= 128>>(x%8)
 if y+24<h:
  assert wire[index:index+4]==bytes([13,27,74,24]); index+=4
assert wire[index:]==bytes([12,27,64,13])
for y in range(h):
 for x in range(w):
  mask=128>>(x%8); off=y*stride+x//8
  assert recovered[off]&mask==raster[off]&mask,(x,y)
print(f'PASS full round-trip: {w}x{h}, {w*h} pixels, 86 bands; no printer involved')
