#!/bin/bash
# All selected pages are validated before a single local queue submission.
set -euo pipefail
umask 077
export PATH=/usr/bin:/bin:/usr/sbin:/sbin LC_ALL=C
unset CUPS_SERVER CUPS_ENCRYPTION LPDEST PRINTER
base="$(cd "$(dirname "$0")" && pwd)"
renderer='/Library/Printers/LQ615KII-Local/pdf615'
fail() { printf 'ERROR: %s\n' "$*" >&2; exit 1; }
[ "$#" = 1 ] && [ -f "$1" ] || fail 'No uploaded document.'
[ "${IPP_COPIES:-1}" = 1 ] || fail 'Select one copy; multipage documents are supported.'
[ "${IPP_SIDES:-one-sided}" = one-sided ] || fail 'Only simplex printing is supported.'
size="$(/usr/bin/wc -c < "$1")"
[ "$size" -gt 0 ] && [ "$size" -le 134217728 ] || fail 'Empty document or document larger than 128 MiB.'
started=$SECONDS
printf 'INFO: Received complete %s document (%s bytes); preparing pages.\n' "${CONTENT_TYPE:-unknown}" "$size" >&2
work="$(/usr/bin/mktemp -d "${TMPDIR:-/tmp}/lq615-airprint.XXXXXXXX")"
cleanup() { /bin/rm -rf "$work"; }
trap cleanup EXIT
trap 'exit 1' HUP INT TERM
case "${CONTENT_TYPE:-}" in
 application/pdf) /bin/cp "$1" "$work/pages.pdf" ;;
 image/urf|image/pwg-raster) "$base/raster615" "$1" "$work/pages.pdf" ;;
 *) fail 'Only PDF, Apple URF and PWG raster are accepted.' ;;
esac
count="$("$renderer" count "$work/pages.pdf")"
case "$count" in ''|*[!0-9]*) fail 'Invalid PDF page count.';; esac
[ "$count" -ge 1 ] && [ "$count" -le 100 ] || fail 'Select a document of 1 to 100 pages.'
# Parse as data. Only canonical positive page numbers reach the CUPS options.
selected="$(/usr/bin/awk -v count="$count" -v ranges="${IPP_PAGE_RANGES:-}" 'BEGIN {
 if(length(ranges)>1024)exit 1
 if(ranges=="") {for(i=1;i<=count;i++) chosen[i]=1}
 else {
  n=split(ranges,parts,",")
  for(i=1;i<=n;i++) {
   if(parts[i]!~/^[1-9][0-9]*(-[1-9][0-9]*)?$/)exit 1
   m=split(parts[i],ends,"-");a=ends[1]+0;b=m==2?ends[2]+0:a
   if(a>1000000||b>1000000||a>b)exit 1
   for(j=a;j<=b&&j<=count;j++)chosen[j]=1
  }
 }
 total=0;for(i=1;i<=count;i++)if(chosen[i]) {print i;total++}
 if(!total)exit 1
}')" || fail 'Invalid page range or no selected pages.'
canonical="$(printf '%s\n' "$selected" | /usr/bin/paste -sd, -)"
number="$(printf '%s\n' "$selected" | /usr/bin/awk 'END {print NR}')"
while IFS= read -r page; do
 printf 'INFO: Checking page %s of %s; no printer data sent yet.\n' "$page" "$count" >&2
 "$renderer" render "$work/pages.pdf" "$page" "$work/preflight.pbm" - 90 128 ink-center 0 0 >&2
done <<< "$selected"
printf 'INFO: Prepared %s selected page(s) in %s seconds; submitting one Mac job.\n' "$number" "$((SECONDS-started))" >&2
/usr/bin/lp -h localhost:631 -d LQ615KII_Local241 -n 1 \
 -t "iPhone PDF - $number page(s)" \
 -o document-format=application/pdf -o PageSize=LQ241x140 \
 -o LQScale=S90 -o LQInk=Standard -o LQX=0 -o LQY=0 \
 -o sides=one-sided -o number-up=1 -o job-sheets=none \
 -o "page-ranges=$canonical" "$work/pages.pdf" >&2
printf 'INFO: Submitted to Mac queue. Feed the next sheet after each page ejects; check paper for completion.\n' >&2
