#!/bin/bash
# ippeveprinter executes this once for an uploaded document. No shell evaluation
# of client-supplied job names, options, filenames or IPP attributes.
set -euo pipefail
umask 077
export PATH=/usr/bin:/bin:/usr/sbin:/sbin LC_ALL=C
unset CUPS_SERVER CUPS_ENCRYPTION LPDEST PRINTER
base="$(cd "$(dirname "$0")" && pwd)"
renderer='/Library/Printers/LQ615KII-Local/pdf615'
fail() { printf 'ERROR: %s\n' "$*" >&2; exit 1; }
[ "$#" = 1 ] && [ -f "$1" ] || fail 'No uploaded document.'
[ "${IPP_COPIES:-1}" = 1 ] || fail 'Select one copy per manual sheet.'
[ "${IPP_SIDES:-one-sided}" = one-sided ] || fail 'Only simplex printing is supported.'
[ -z "${IPP_PAGE_RANGES:-}" ] || fail 'Export/select a single-page PDF first.'
# Limit input to 128 MiB, and never use an untrusted job title as a command.
size="$(/usr/bin/wc -c < "$1")"
[ "$size" -gt 0 ] && [ "$size" -le 134217728 ] || fail 'Empty document or document larger than 128 MiB.'
work="$(/usr/bin/mktemp -d "${TMPDIR:-/tmp}/lq615-airprint.XXXXXXXX")"
cleanup() { /bin/rm -rf "$work"; }
trap cleanup EXIT
trap 'exit 1' HUP INT TERM
case "${CONTENT_TYPE:-}" in
 application/pdf) /bin/cp "$1" "$work/page.pdf" ;;
 image/urf|image/pwg-raster) "$base/raster615" "$1" "$work/page.pdf" ;;
 *) fail 'Only PDF, Apple URF and PWG raster are accepted.' ;;
esac
[ "$("$renderer" count "$work/page.pdf")" = 1 ] || fail 'Select exactly one page per manual-sheet job.'
# Preflight verifies actual page size, fonts, rotation, ink bounds and selected
# scale before enqueueing. The validated original PDF is submitted unchanged:
# the USB driver applies 90% once, not to this discarded preflight PBM.
"$renderer" render "$work/page.pdf" 1 "$work/preflight.pbm" - 90 128 ink-center 0 0 >&2
printf 'INFO: Validated one 241x140mm page; sending to Mac USB queue.\n' >&2
/usr/bin/lp -h localhost:631 -d LQ615KII_Local241 -n 1 \
 -t 'iPhone PDF - single sheet' \
 -o document-format=application/pdf -o PageSize=LQ241x140 \
 -o LQScale=S90 -o LQInk=Standard -o LQX=0 -o LQY=0 \
 -o sides=one-sided -o number-up=1 -o job-sheets=none \
 "$work/page.pdf" >&2
printf 'INFO: Submitted to Mac queue; check the paper for physical completion.\n' >&2
