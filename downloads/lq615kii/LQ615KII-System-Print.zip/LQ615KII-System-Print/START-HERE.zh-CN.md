# 给另一台Mac安装

这是本项目开发的本地PDF打印驱动，不是Epson官方驱动包。

## 已实测与要求

| 项目 | 当前范围 |
|---|---|
| 实测系统 | 一台macOS26.3.1、Apple芯片arm64电脑，已通过系统打印菜单打印241×140mm PDF |
| 其他macOS版本 | 未逐一验证，没有已确认的最低/最高系统版本；需要仍支持PPD/CUPS滤镜队列 |
| Intel Mac | 安装时本机编译，源码没有仅限arm64的构建参数；尚未实测，不能列为已验证支持 |
| 开发工具 | 首次需Swift、Clang、macOS SDK，可使用Apple Command Line Tools或已配置的Xcode；无需Python/Homebrew/Ghostscript |
| 权限 | 首次安装需要Mac管理员密码，常规系统打印不需要每次sudo |
| 设备 | Epson LQ-615KII，USB直连；其他型号、网络打印盒未验证 |
| 当前纸型 | 241×140mm，手动单张，默认90%等比、左右居中、顶部对齐、标准较细 |

当前实测针对单页、1份；多页补纸、页码、取消等包含代码和离线入口测试，但还不能当成全部实机验证。

## 新电脑安装一次

1. 解压到Mac“下载”目录，文件夹名为LQ615KII-System-Print。
2. 打印机开机，连接到这台新Mac。正常安装会自动识别这台设备的实际USB地址，不复制别人的序列号。
3. 终端执行一次：

```sh
bash "$HOME/Downloads/LQ615KII-System-Print/Install.command"
```

如缺开发工具，先执行`xcode-select --install`并完成安装，再回来继续。若已安装Xcode但SDK/工具不匹配，以实际编译错误排查，不用先重装系统。

这份新包已经合并Darwin头文件修复和PPD检查顺序修复，不再执行聊天记录里的Perl补丁。安装保留同名已有目录/队列，不盲目覆盖。会请求一次管理员授权，但不自动发送测试页，也不改变默认打印机。

首次必须先确认队列登记成功，再实际试一页。驱动弃用与PPD纸名提示可能是警告，不能据此跳过真正的错误。

## 以后打印

打开PDF→Command+P→LQ-615KII 241x140 Local PDF。纸型241 x 140 mm，应用缩放100%，驱动内部默认90%，避免叠成81%。先打印1页、1份，按机器状态逐张放纸。日常不启动终端或V5。

Printer Features中可选Driver Scale（90/85）、Monochrome（Standard/Darker）、左右微调和额外上留白。

## 离线安装与卸载

未连接时只能用自己此前实机确认过的URI运行Install-Offline.command，不能猜测或复用另一台打印机的序列号；离线登记不证明设备已经连通。新电脑优先按上面的连接安装方式操作。

检查：`bash "$HOME/Downloads/LQ615KII-System-Print/Check.command"`

卸载：`bash "$HOME/Downloads/LQ615KII-System-Print/Uninstall.command"`

详细限制、范围、权限和验证记录见README.zh-CN.md。不需要在已经成功安装的原Mac上重新安装。
