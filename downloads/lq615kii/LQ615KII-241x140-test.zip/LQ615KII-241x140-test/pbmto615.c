/* Experimental PBM P4 -> LQ-615KII 180x180 ESC * 39.
 * Model evidence: EBSD112N.GPD Resolution.Option3, V_BYTE, 24 pins.
 * NOT a cups-raster decoder. No PDF or printer-status support.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <limits.h>
static void fail(const char *s) { fprintf(stderr,"ERROR: %s\n",s); exit(1); }
static int token(FILE *f, char *s, size_t n) {
 int c; size_t i=0;
 do { c=fgetc(f); if(c=='#') while(c!=EOF && c!='\n') c=fgetc(f); } while(c!=EOF && isspace((unsigned char)c));
 if(c==EOF) return 0;
 do { if(i+1>=n) fail("PBM token too long"); s[i++]=(char)c; c=fgetc(f); } while(c!=EOF && !isspace((unsigned char)c));
 if(c==EOF) fail("missing PBM raster separator");
 /* Treat CRLF as one separator, never skip arbitrary raster whitespace. */
 if(c=='\r') { c=fgetc(f); if(c!='\n' && c!=EOF) ungetc(c,f); }
 s[i]=0; return 1;
}
static int number(const char *s) { char *e; long n=strtol(s,&e,10); if(!*s || *e || n<1 || n>10000) fail("invalid PBM dimension"); return (int)n; }
static void bytes(const unsigned char *p,size_t n) { if(fwrite(p,1,n,stdout)!=n) fail("output write failed"); }
static void b(int v) { if(putchar(v)==EOF) fail("output write failed"); }
static void word(int v) { b(v&255); b((v>>8)&255); }
int main(int argc,char **argv) {
 FILE *f=stdin; char s[64]; int w,h,d4=0,small=0;
 int maxw=1443,maxh=2044,page_length=4208,x_origin=44;
 if(argc==6 || argc==7) {
  if(strcmp(argv[4],"1")) fail("only one copy supported; resubmit separate jobs");
  /* Never silently ignore requested geometry/options. */
  if(*argv[5]) fail("CUPS options unsupported; use standalone fixed A4 path");
  if(argc==7) { f=fopen(argv[6],"rb"); if(!f) fail("cannot open job file"); }
 } else {
  for(int i=1;i<argc;i++) {
   if(!strcmp(argv[i],"--d4")) d4=1;
   else if(!strcmp(argv[i],"--paper=241x140")) small=1;
   else fail("usage: pbmto615 [--d4] [--paper=241x140] < image.pbm > job.prn");
  }
 }
 /* 241x140mm manual-sheet experiment. Page length rounded to 1/360in;
  * conservative 8.2in image width from GPD. Center horizontally on the
  * 241mm sheet, keeping clear of the side holes. Paper is not rotated.
  * 140mm -> 3968 master units, minus 120 top/bottom -> 932 rows.
  */
 if(small) { maxw=1476; maxh=932; page_length=1984; x_origin=232; }
 if(!token(f,s,sizeof s) || strcmp(s,"P4")) fail("input must be binary PBM P4, not PDF/CUPS Raster");
 if(!token(f,s,sizeof s)) fail("missing width");
 w=number(s);
 if(!token(f,s,sizeof s)) fail("missing height");
 h=number(s);
 if(w>maxw || h>maxh) fail("image exceeds selected paper printable area; no scaling performed");
 size_t stride=(size_t)(w+7)/8, size=stride*(size_t)h;
 unsigned char *image=malloc(size); if(!image) fail("allocation failed");
 if(fread(image,1,size,f)!=size) fail("truncated PBM");
 if(fgetc(f)!=EOF) fail("trailing data/multiple PBM pages unsupported");
 /* All input validated before any printer bytes are emitted. */
 if(d4) { static const unsigned char p[]={0,0,0,27,1,'@','E','J','L',' ', '1','2','8','4','.','4',10,'@','E','J','L',' ',' ',' ',' ',' ',10}; bytes(p,sizeof p); }
 static const unsigned char start[]={27,'@',13,27,'t',1,27,'6',27,'R',0,27,'P',27,'(','U',1,0,10}; bytes(start,sizeof start);
 /* GPD PrinterPriority/CUSTOMSIZE page-length template; units 1/360in. */
 static const unsigned char page[]={27,'(','C',2,0}; bytes(page,sizeof page);
 word(page_length); b(13); b(27); b('J'); b(30);
 for(int y=0;y<h;y+=24) {
  b(13); b(27); b('$'); word(x_origin); /* 1/360in, referenced to device horizontal origin */
  b(27); b('*'); b(39); word(w);
  for(int x=0;x<w;x++) for(int group=0;group<3;group++) {
   unsigned char v=0;
   for(int bit=0;bit<8;bit++) { int row=y+group*8+bit; if(row<h && (image[(size_t)row*stride+(size_t)x/8] & (0x80>>(x%8)))) v|=(unsigned char)(0x80>>bit); }
   b(v);
  }
  /* No final band advance: partial band must not cross the bottom boundary. */
  if(y+24<h) { b(13); b(27); b('J'); b(24); }
 }
 /* FF is an explicit experimental eject policy; see report re CmdFF ambiguity. */
 b(12); b(27); b('@'); b(13);
 free(image); if(f!=stdin) fclose(f); if(fflush(stdout)==EOF) fail("flush failed"); return 0;
}
