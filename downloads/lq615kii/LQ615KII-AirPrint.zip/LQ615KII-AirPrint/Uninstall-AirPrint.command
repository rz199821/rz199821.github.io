#!/bin/bash
set -euo pipefail
prefix="$HOME/Library/Application Support/LQ615KII-AirPrint"
agent="$HOME/Library/LaunchAgents/local.lq615kii.airprint.plist"
[ -f "$prefix/OWNER" ] && [ "$(cat "$prefix/OWNER")" = local.lq615kii.airprint.v1 ] || { echo '没有找到本工具标记，不删除未知内容。' >&2;exit 1; }
if [ -e "$agent" ]; then
 [ "$(/usr/bin/plutil -extract Label raw -o - "$agent")" = local.lq615kii.airprint ] || { echo '启动配置已改成其他服务，停止删除。' >&2;exit 1; }
fi
/bin/launchctl bootout "gui/$(id -u)/local.lq615kii.airprint" 2>/dev/null || true
for name in probe run-service.sh OWNER; do /bin/rm -f "$prefix/$name"; done
/bin/rmdir "$prefix" || echo '目录有其他文件，已保留。'
/bin/rm -f "$agent"
printf '已移除本工具的后台发现服务。Mac系统打印驱动和队列保留。\n'
printf '系统设置中由你开启的打印机共享不会自动关闭；如不再使用，请自行取消该队列共享。\n'
