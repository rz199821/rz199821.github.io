#!/bin/bash
set -euo pipefail
umask 077
cd "$(dirname "$0")"
kit="$PWD"
driver='/Library/Printers/LQ615KII-Local'
bridge="$HOME/Library/Application Support/LQ615KII-AirPrint-v2"
agent="$HOME/Library/LaunchAgents/local.lq615kii.airprint.v2.plist"
fail() { printf '\n安装停止：%s\n' "$*" >&2; exit 1; }
[ "$(uname -s)" = Darwin ] || fail '请在Mac上运行。'
driver_present=0
bridge_present=0
bridge_update=0
if [ -e "$driver" ]; then
 [ -f "$driver/OWNER" ] && [ "$(cat "$driver/OWNER")" = local.lq615kii.systemqueue.v1 ] || fail '已有同名驱动目录，但来源不匹配；未覆盖。'
 /usr/bin/lpstat -h localhost:631 -p LQ615KII_Local241 >/dev/null || fail '驱动文件存在但队列缺失，请先用Check.command检查。'
 for name in pdf615 pbmto615 lq615filter; do
  [ -x "$driver/$name" ] || fail '已有驱动不完整，请先检查。'
  /usr/bin/codesign --verify --strict "$driver/$name"
 done
 driver_present=1
elif /usr/bin/lpstat -h localhost:631 -p LQ615KII_Local241 >/dev/null 2>&1; then
 fail '已有同名队列，但缺少本工具的驱动目录；未覆盖。'
fi
if [ -e "$bridge" ] || [ -e "$agent" ]; then
 [ -f "$bridge/OWNER" ] && [ "$(cat "$bridge/OWNER")" = local.lq615kii.airprint.v2 ] || fail '已有同名手机接收服务，但来源不匹配；未覆盖。'
 [ -f "$agent" ] && [ "$(/usr/bin/plutil -extract Label raw -o - "$agent")" = local.lq615kii.airprint.v2 ] || fail '已有手机接收服务配置不完整，请先检查。'
 [ -r "$bridge/printer.conf" ] || fail '已有手机接收服务缺少纸型配置。'
 if /usr/bin/grep -qx 'ATTR boolean page-ranges-supported false' "$bridge/printer.conf"; then
  bridge_update=1
 fi
 bridge_present=1
fi
# Ask macOS to install missing developer tools through this same entry point.
if [ "$driver_present" = 0 ] || [ "$bridge_present" = 0 ] || [ "$bridge_update" = 1 ]; then
 tools=(clang)
 if [ "$driver_present" = 0 ]; then tools+=(swiftc); fi
 for tool in "${tools[@]}"; do
  if ! xcrun --find "$tool" >/dev/null 2>&1; then
   /usr/bin/xcode-select --install || true
   fail '请完成 Apple 命令行工具安装，再双击本文件继续。'
  fi
 done
fi
if [ "$driver_present" = 0 ]; then
 printf '\n[1/2] 安装Mac系统打印驱动。请将打印机开机并连接这台Mac的USB。\n'
 /bin/bash "$kit/driver/Install.command"
else
 printf '\n[1/2] 已识别现有系统打印驱动，保留使用。\n'
fi
if [ "$bridge_present" = 0 ]; then
 printf '\n[2/2] 安装iPhone打印桥接。首次编译可能需要几分钟。\n'
 /bin/bash "$kit/bridge/Install-AirPrint.command"
elif [ "$bridge_update" = 1 ]; then
 printf '\n[2/2] 将已有手机桥接更新为多页版。\n'
 /bin/bash "$kit/bridge/Upgrade-Multipage.command"
else
 printf '\n[2/2] 已有手机接收服务，检查HTTP、HTTPS和多页状态。\n'
 /bin/bash "$kit/bridge/Check-AirPrint.command" "$kit/bridge/check-receiver.test" || fail '已有接收服务检查未通过，请查看上面的结果。'
fi
printf '\n打印桥接安装与自检完成；没有发送打印任务。\n'
printf '手机打开每页241×140mm的PDF，选择共享 → 打印，再选连接这台Mac的打印机。\n'
printf '保持Mac登录、不休眠，USB连接打印机；手机与Mac连接同一可互通Wi-Fi。\n'
printf '先确认纸型和预览，再测试1页1份。驱动自动执行90%%，不需要手机再次缩小。\n'
