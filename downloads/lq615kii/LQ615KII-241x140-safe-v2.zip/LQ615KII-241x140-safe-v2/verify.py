from pathlib import Path
r=Path(__file__).parent
p=(r/'calibration.pbm').read_bytes().split(b'\n',3)
assert p[0]==b'P4' and p[1].startswith(b'#')
w,h=map(int,p[2].split()); image=p[3]; stride=(w+7)//8
assert (w,h)==(1476,720) and len(image)==stride*h
wire=(r/'test-safe-v2.prn').read_bytes()
assert wire.startswith(b'\0\0\0\x1b\x01@EJL')
assert bytes([27,40,67,2,0,192,7]) in wire
marker=bytes([13,27,36,232,0,27,42,39,196,5]); i=wire.index(marker)
for y in range(0,h,24):
 assert wire[i:i+10]==marker; i+=10
 data=wire[i:i+w*3]; i+=w*3
 for x in range(w):
  for k in range(24):
   assert bool(data[x*3+k//8]&(128>>(k%8)))==bool(image[(y+k)*stride+x//8]&(128>>(x%8)))
 if y+24<h: assert wire[i:i+4]==bytes([13,27,74,24]); i+=4
assert wire[i:]==bytes([12,27,64,13])
print('PASS: 1,062,720 pixels, 30 bands, D4 prefix, 140mm nominal page, one final FF. Physical positioning unverified.')
