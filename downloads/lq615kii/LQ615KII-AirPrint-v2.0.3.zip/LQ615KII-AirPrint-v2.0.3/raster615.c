/* LQ615KII AirPrint raster receiver. Uses the public libcups raster API.
 * Single sheet only; validate the entire document before writing a PDF.
 */
#if defined(__APPLE__)
#include <TargetConditionals.h>
#endif
#include <cups/raster.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <math.h>
#include <zlib.h>
static void die(const char *s) { fprintf(stderr,"ERROR: %s\n",s); exit(1); }
int main(int argc,char **argv) {
 if(argc!=3) die("usage: raster615 input output.pdf");
 int fd=open(argv[1],O_RDONLY); if(fd<0) die("Cannot open raster");
 unsigned char magic[12];
 if(read(fd,magic,12)!=12 || lseek(fd,0,SEEK_SET)<0) die("Missing raster header");
 if(!memcmp(magic,"UNIRAST\0",8)) {
  uint32_t count=((uint32_t)magic[8]<<24)|((uint32_t)magic[9]<<16)|((uint32_t)magic[10]<<8)|magic[11];
  if(count>1) die("Select exactly one page per job");
 }
 cups_raster_t *r=cupsRasterOpen(fd,CUPS_RASTER_READ); if(!r) die("Invalid raster stream");
 cups_page_header2_t h,next;
 if(!cupsRasterReadHeader2(r,&h)) die("Missing raster page");
 unsigned w=h.cupsWidth, ht=h.cupsHeight, bpp=h.cupsBitsPerPixel;
 if(!w||!ht||w>6000||ht>6000||!h.HWResolution[0]||!h.HWResolution[1]||h.HWResolution[0]>600||h.HWResolution[1]>600) die("Invalid size/resolution");
 double mmw=w*25.4/h.HWResolution[0], mmh=ht*25.4/h.HWResolution[1];
 if(fabs(mmw-241)>0.6 || fabs(mmh-140)>0.6) die("Raster must be landscape 241x140mm; no automatic fitting");
 if(h.Duplex||h.NumCopies>1||h.cupsColorOrder!=CUPS_ORDER_CHUNKED) die("Only one copy, simplex, chunky raster supported");
 int gray=h.cupsColorSpace==CUPS_CSPACE_SW || h.cupsColorSpace==CUPS_CSPACE_W;
 int black=h.cupsColorSpace==CUPS_CSPACE_K;
 int rgb=h.cupsColorSpace==CUPS_CSPACE_SRGB || h.cupsColorSpace==CUPS_CSPACE_RGB;
 if(!((gray&&bpp==8&&h.cupsBitsPerColor==8)||(black&&bpp==1&&h.cupsBitsPerColor==1)||(rgb&&bpp==24&&h.cupsBitsPerColor==8))) die("Unsupported raster color space/depth");
 unsigned row=(w*bpp+7)/8;
 if(h.cupsBytesPerLine<row || h.cupsBytesPerLine>20000) die("Invalid row length");
 size_t n=(size_t)w*ht; if(n>36000000) die("Raster too large");
 unsigned char *pixels=malloc(n), *line=malloc(h.cupsBytesPerLine);
 if(!pixels||!line) die("Out of memory");
 for(unsigned y=0;y<ht;y++) {
  if(cupsRasterReadPixels(r,line,h.cupsBytesPerLine)!=h.cupsBytesPerLine) die("Truncated raster");
  for(unsigned x=0;x<w;x++) pixels[(size_t)y*w+x]=gray?line[x]:black?((line[x/8]&(128>>(x%8)))?0:255):(unsigned char)((54u*line[3*x]+183u*line[3*x+1]+19u*line[3*x+2]+128)/256);
 }
 if(cupsRasterReadHeader2(r,&next)) die("Select exactly one page per job for manual sheets");
 cupsRasterClose(r); close(fd); free(line);
 uLongf zn=compressBound(n); unsigned char *z=malloc(zn); if(!z || compress2(z,&zn,pixels,n,6)!=Z_OK) die("Compression failed"); free(pixels);
 FILE *out=fopen(argv[2],"wb"); if(!out) die("Cannot write PDF");
 long off[6]; fputs("%PDF-1.4\n",out);
 off[1]=ftell(out); fputs("1 0 obj << /Type /Catalog /Pages 2 0 R >> endobj\n",out);
 off[2]=ftell(out); fputs("2 0 obj << /Type /Pages /Count 1 /Kids [3 0 R] >> endobj\n",out);
 double pw=241.0*72/25.4, ph=140.0*72/25.4;
 off[3]=ftell(out); fprintf(out,"3 0 obj << /Type /Page /Parent 2 0 R /MediaBox [0 0 %.8f %.8f] /Resources << /XObject << /Im0 4 0 R >> >> /Contents 5 0 R >> endobj\n",pw,ph);
 off[4]=ftell(out); fprintf(out,"4 0 obj << /Type /XObject /Subtype /Image /Width %u /Height %u /ColorSpace /DeviceGray /BitsPerComponent 8 /Filter /FlateDecode /Length %lu >> stream\n",w,ht,(unsigned long)zn); if(fwrite(z,1,zn,out)!=zn) die("PDF write failed"); free(z); fputs("\nendstream endobj\n",out);
 char content[160]; int len=snprintf(content,sizeof(content),"q %.8f 0 0 %.8f 0 0 cm /Im0 Do Q\n",pw,ph);
 off[5]=ftell(out); fprintf(out,"5 0 obj << /Length %d >> stream\n%sendstream endobj\n",len,content);
 long xref=ftell(out); fputs("xref\n0 6\n0000000000 65535 f \n",out); for(int i=1;i<=5;i++) fprintf(out,"%010ld 00000 n \n",off[i]); fprintf(out,"trailer << /Size 6 /Root 1 0 R >>\nstartxref\n%ld\n%%%%EOF\n",xref);
 if(ferror(out)||fclose(out)) die("PDF write failed");
 return 0;
}
