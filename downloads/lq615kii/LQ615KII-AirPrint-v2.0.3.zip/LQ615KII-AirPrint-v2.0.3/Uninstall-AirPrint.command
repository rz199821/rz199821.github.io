#!/bin/bash
set -euo pipefail
prefix="$HOME/Library/Application Support/LQ615KII-AirPrint-v2"
agent="$HOME/Library/LaunchAgents/local.lq615kii.airprint.v2.plist"
oldagent="$HOME/Library/LaunchAgents/local.lq615kii.airprint.plist"
legacy="$HOME/Library/Application Support/LQ615KII-AirPrint"
[ -f "$prefix/OWNER" ] && [ "$(cat "$prefix/OWNER")" = local.lq615kii.airprint.v2 ] || { echo '没有本工具标记，不删除未知内容。' >&2;exit 1; }
if [ -e "$agent" ]; then
 [ "$(/usr/bin/plutil -extract Label raw -o - "$agent")" = local.lq615kii.airprint.v2 ] || { echo '启动配置不匹配，停止卸载。' >&2;exit 1; }
fi
restore=none
[ ! -f "$prefix/restore-v1" ] || restore="$(cat "$prefix/restore-v1")"
oldbackup="$legacy/LaunchAgent.before-v2.plist"
/bin/launchctl bootout "gui/$(id -u)/local.lq615kii.airprint.v2" 2>/dev/null || true
for file in ippeveprinter ipptool raster615 spool-job.sh run-service.sh printer.conf check-receiver.test restore-v1 OWNER; do /bin/rm -f "$prefix/$file"; done
# Only our own spool directory; no USB drivers or system CUPS data are removed.
[ ! -d "$prefix/spool" ] || /bin/rm -rf "$prefix/spool"
/bin/rmdir "$prefix" || echo '目录中还有其他文件，已保留。'
/bin/rm -f "$agent"
if [ "$restore" != none ] && [ -f "$oldbackup" ] && [ ! -e "$oldagent" ] && [ -f "$legacy/OWNER" ] && [ "$(cat "$legacy/OWNER")" = local.lq615kii.airprint.v1 ] && [ "$(/usr/bin/plutil -extract Label raw -o - "$oldbackup")" = local.lq615kii.airprint ]; then
 /bin/mv "$oldbackup" "$oldagent"
 if [ "$restore" = 1 ] && ! /bin/launchctl print "gui/$(id -u)/local.lq615kii.airprint" >/dev/null 2>&1; then
  /bin/launchctl bootstrap "gui/$(id -u)" "$oldagent"
 fi
 echo '旧版启动配置已恢复。'
fi
printf '已移除v2手机接收服务；Mac系统打印驱动、队列和诊断日志保留。\n'
