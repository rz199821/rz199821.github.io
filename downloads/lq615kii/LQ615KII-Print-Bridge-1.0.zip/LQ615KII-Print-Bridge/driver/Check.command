#!/bin/bash
set -u
queue='LQ615KII_Local241'
prefix='/Library/Printers/LQ615KII-Local'
printf '系统：\n'; /usr/bin/sw_vers; /usr/bin/uname -m
printf '\n队列状态（不存在时会显示错误）：\n'
/usr/bin/lpstat -p "$queue" -v "$queue"
printf '\n队列任务：\n'; /usr/bin/lpstat -o "$queue"
printf '\n驱动选项：\n'; /usr/bin/lpoptions -p "$queue" -l
printf '\n安装文件权限：\n'; /bin/ls -ld "$prefix" "$prefix/"*
printf '\n签名检查：\n'
for name in pdf615 pbmto615 lq615filter; do /usr/bin/codesign --verify --strict "$prefix/$name"; done
printf '\n以上检查不会发送打印数据。记录可能包含本机USB序列号或任务标题，不要直接公开发布。\n'
