#!/usr/bin/env python3
"""Linux/macOS loopback tests: real IPP server and raster codecs; fake only the
native PDFKit renderer and final USB queue to avoid hardware/network printing.
Requires CUPS headers/libcups, cc, Ghostscript, Pillow and Python 3.
"""
import os, sys, struct, subprocess, tempfile, pathlib, socket, time, http.client, json, shutil
ROOT=pathlib.Path(__file__).resolve().parents[1]
CUPS=pathlib.Path(sys.argv[1]).resolve()
SERVER=CUPS/'tools/ippeveprinter-static'; TOOL=CUPS/'tools/ipptool-static'
libflags=subprocess.check_output([str(CUPS/'cups-config'),'--static','--libs'],cwd=CUPS,text=True).split()
# cups-config's static path is relative to its configured tree.
libflags=[str(CUPS/'cups/libcups.a') if x.endswith('/cups/libcups.a') else x for x in libflags]
passed=0

def check(condition,msg):
 global passed
 assert condition,msg
 passed+=1;print('PASS',msg,flush=True)

def run(*args,ok=True,**kwargs):
 p=subprocess.run([str(x) for x in args],stdout=subprocess.PIPE,stderr=subprocess.PIPE,**kwargs)
 if ok and p.returncode: raise AssertionError((p.stdout+p.stderr).decode(errors='replace'))
 return p

def ipp_attr(tag,name,value):
 name=name.encode();value=value.encode() if isinstance(value,str) else value
 return bytes([tag])+struct.pack('>H',len(name))+name+struct.pack('>H',len(value))+value

def parse_ipp(data):
 status=struct.unpack('>H',data[2:4])[0];p=8;attrs={};name=''
 while p<len(data):
  tag=data[p];p+=1
  if tag==3:break
  if tag<16:continue
  n=struct.unpack('>H',data[p:p+2])[0];p+=2
  if n:name=data[p:p+n].decode();p+=n
  n=struct.unpack('>H',data[p:p+2])[0];p+=2
  v=data[p:p+n];p+=n
  if tag in (0x21,0x23):v=struct.unpack('>i',v)[0]
  elif tag in (0x22,):v=bool(v[0])
  elif tag in (0x41,0x42,0x44,0x45,0x47,0x48,0x49):v=v.decode()
  attrs.setdefault(name,[]).append(v)
 return status,attrs

with tempfile.TemporaryDirectory(prefix='lq615-test-') as td:
 d=pathlib.Path(td)
 for name,src in [('raster615',ROOT/'raster615.c'),('fixture',ROOT/'tests/fixture.c')]:
  run('cc','-O2','-Wall','-Wextra','-Werror','-I',CUPS,src,*libflags,'-o',d/name)
 # The renderer mock validates a PDF, records exact 90% call, and can fail.
 renderer=d/'renderer';renderer.write_text('''#!/usr/bin/env python3
import sys,os,pathlib
p=pathlib.Path(sys.argv[2]);assert p.read_bytes().startswith(b'%PDF-')
if sys.argv[1]=='count':print('1');sys.exit(0)
if os.path.exists(os.environ['TEST_LOG']+'.fail'):sys.exit(2)
assert sys.argv[6:]==['90','128','ink-center','0','0']
pathlib.Path(sys.argv[4]).write_bytes(b'P4\\n8 1\\n\\x80')
''');renderer.chmod(0o755)
 lp=d/'fake-lp';lp.write_text('''#!/usr/bin/env python3
import sys,os,pathlib,json,shutil
with open(os.environ['TEST_LOG'],'a') as f:f.write(json.dumps(sys.argv[1:])+'\\n')
shutil.copyfile(sys.argv[-1],os.environ['TEST_LOG']+'.pdf')
print('request id is LQ615KII_Local241-1',file=sys.stderr)
''');lp.chmod(0o755)
 hook=d/'spool-job.sh';hook.write_text((ROOT/'spool-job.sh').read_text().replace("renderer='/Library/Printers/LQ615KII-Local/pdf615'",'renderer='+repr(str(renderer))).replace('/usr/bin/lp -h',str(lp)+' -h'));hook.chmod(0o755)
 env=dict(os.environ,TEST_LOG=str(d/'submissions'),TMPDIR=str(d))
 for name,mode,pages,kind in [('gray',0,1,0),('black',1,1,1),('rgb',0,1,2),('multi',0,2,0)]:
  run(d/'fixture',d/(name+'.ras'),mode,pages,kind)
  p=run(d/'raster615',d/(name+'.ras'),d/(name+'.pdf'),ok=pages==1)
  if pages>1:check(p.returncode!=0 and not (d/(name+'.pdf')).exists(),'multi-page raster rejected before output')
  else:
   run('gs','-q','-dSAFER','-dBATCH','-dNOPAUSE','-sDEVICE=pnggray','-r72','-sOutputFile='+str(d/(name+'.png')),d/(name+'.pdf'))
   from PIL import Image
   im=Image.open(d/(name+'.png'));w,h=im.size
   check(im.getpixel((10,10))<10 and im.getpixel((w//2,h//2))>250 and im.getpixel((int(w*.755),h-5))<10,name+' actual raster→PDF: size, orientation and polarity')
 (d/'short.ras').write_bytes((d/'gray.ras').read_bytes()[:200])
 p=run(d/'raster615',d/'short.ras',d/'short.pdf',ok=False)
 check(p.returncode!=0 and not (d/'short.pdf').exists(),'truncated raster rejected before output')
 # Decode at both advertised resolutions and reject other media/duplex/color.
 run(d/'fixture',d/'600.ras',0,1,0,env=dict(env,F_DPI='1'))
 run(d/'raster615',d/'600.ras',d/'600.pdf')
 check((d/'600.pdf').exists(),'600 dpi Apple URF decoded at original physical size')
 for flag in ['F_A4','F_DUPLEX']:
  run(d/'fixture',d/(flag+'.ras'),0,1,0,env=dict(env,**{flag:'1'}))
  p=run(d/'raster615',d/(flag+'.ras'),d/(flag+'.pdf'),ok=False)
  check(p.returncode!=0 and not (d/(flag+'.pdf')).exists(),flag+' rejected before output')
 run(d/'fixture',d/'cmyk.ras',1,1,3)
 p=run(d/'raster615',d/'cmyk.ras',d/'cmyk.pdf',ok=False)
 check(p.returncode!=0,'unsupported CMYK rejected')
 claimed=bytearray((d/'gray.ras').read_bytes());claimed[8:12]=struct.pack('>I',2)
 (d/'claimed.ras').write_bytes(claimed)
 check(run(d/'raster615',d/'claimed.ras',d/'claimed.pdf',ok=False).returncode!=0,'URF claiming two pages rejected even if second page missing')
 s=socket.socket();s.bind(('127.0.0.1',0));port=s.getsockname()[1];s.close()
 (d/'spool').mkdir();log=open(d/'server.log','wb')
 proc=subprocess.Popen([str(SERVER),'-r','off','-n','localhost','-p',str(port),'-a',str(ROOT/'printer.conf'),'-d',str(d/'spool'),'-c',str(hook),'-v','Integration test'],stdout=log,stderr=log,env=env)
 uri=f'ipp://localhost:{port}/ipp/print'
 def request(op,extra=b'',jobattrs=b'',doc=b''):
  body=struct.pack('>BBHI',2,0,op,1)+b'\x01'+ipp_attr(0x47,'attributes-charset','utf-8')+ipp_attr(0x48,'attributes-natural-language','en')+ipp_attr(0x45,'printer-uri',uri)+extra
  if jobattrs:body+=b'\x02'+jobattrs
  body+=b'\x03'+doc
  c=http.client.HTTPConnection('localhost',port,timeout=10);c.request('POST','/ipp/print',body,{'Content-Type':'application/ipp'});r=c.getresponse();data=r.read();c.close();assert r.status==200,r.status
  return parse_ipp(data)
 try:
  for _ in range(50):
   try:status,attrs=request(11);break
   except OSError:time.sleep(.1)
  else:raise AssertionError('server startup failed')
  p=run(TOOL,'-T','5','-t',uri,ROOT/'check-receiver.test')
  check(p.returncode==0,'Get-Printer-Attributes + Validate-Job with real media-col')
  check(set(attrs['document-format-supported'])=={'application/octet-stream','application/pdf','image/urf','image/pwg-raster'},'MIME types match implemented inputs')
  check(3 not in attrs['operations-supported'] and 7 not in attrs['operations-supported'],'reference-URI operations not advertised')
  check(request(3,ipp_attr(0x45,'document-uri','file:///etc/passwd'))[0]==0x0501,'Print-URI rejected, never reads referenced files')
  check('ipp-features-supported' not in attrs,'limited receiver does not claim IPP Everywhere conformance')
  check(request(4,ipp_attr(0x49,'document-format','application/pdf'),ipp_attr(0x21,'copies',struct.pack('>i',2)))[0]>=0x0400,'two copies rejected even without fidelity flag')
  check(request(4,ipp_attr(0x49,'document-format','application/pdf'),ipp_attr(0x44,'sides','two-sided-long-edge'))[0]>=0x0400,'duplex rejected even without fidelity flag')
  extra=ipp_attr(0x49,'document-format','application/pdf')+ipp_attr(0x22,'ipp-attribute-fidelity',b'\x01')
  check(request(4,extra,ipp_attr(0x21,'copies',struct.pack('>i',2)))[0]>=0x0400,'Validate-Job rejects two copies')
  check(request(4,extra,ipp_attr(0x44,'media','iso_a4_210x297mm'))[0]>=0x0400,'Validate-Job rejects A4')
  def waitjob(jid):
   for _ in range(100):
    _,a=request(9,ipp_attr(0x21,'job-id',struct.pack('>i',jid)))
    state=a['job-state'][0]
    if state>=7:return state
    time.sleep(.05)
   raise AssertionError('job did not finish')
  def submit(mime,file,create=False):
   if create:
    status,a=request(5,jobattrs=ipp_attr(0x21,'copies',struct.pack('>i',1)));assert status<0x100
    jid=a['job-id'][0]
    status,_=request(6,ipp_attr(0x21,'job-id',struct.pack('>i',jid))+ipp_attr(0x49,'document-format',mime)+ipp_attr(0x22,'last-document',b'\x01'),doc=file.read_bytes());assert status<0x100
   else:
    status,a=request(2,ipp_attr(0x49,'document-format',mime),ipp_attr(0x21,'copies',struct.pack('>i',1)),file.read_bytes());assert status<0x100,(status,a)
    jid=a['job-id'][0]
   return waitjob(jid)
  for mime,name,create in [('image/urf','gray.ras',False),('image/pwg-raster','black.ras',True),('application/pdf','gray.pdf',False)]:
   check(submit(mime,d/name,create)==9,mime+' actual IPP upload→codec→preflight→queue handoff')
  calls=(d/'submissions').read_text().splitlines();check(len(calls)==3,'exactly one queue submission per accepted document')
  for call in calls:
   args=json.loads(call)
   assert args.count('LQScale=S90')==1 and 'fit-to-page' not in args and '-n' in args and args[args.index('-n')+1]=='1'
  check(True,'90% applied exactly once in USB queue, one copy')
  check(submit('image/urf',d/'multi.ras')==8,'multi-page IPP job aborts before queue submission')
  check(submit('image/urf',d/'short.ras')==8,'truncated IPP job aborts before queue submission')
  (d/'submissions.fail').touch()
  check(submit('application/pdf',d/'gray.pdf')==8,'native-renderer failure aborts before queue submission')
  check(len((d/'submissions').read_text().splitlines())==3,'no queue submissions on conversion/preflight failures')
  check(not list(d.glob('lq615-airprint.*')),'temporary document directories cleaned after success and failure')
 finally:
  proc.terminate()
  try:proc.wait(timeout=5)
  except subprocess.TimeoutExpired:proc.kill();proc.wait()
  log.close()
print(f'{passed} checks passed; no physical printer used.')
