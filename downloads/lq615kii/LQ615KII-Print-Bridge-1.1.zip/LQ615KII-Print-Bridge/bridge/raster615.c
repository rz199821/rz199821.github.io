/* Convert complete Apple URF / PWG documents to multipage PDF. An incomplete
 * or unsupported later page never publishes even the earlier PDF pages. */
#if defined(__APPLE__)
#include <TargetConditionals.h>
#endif
#include <cups/raster.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <math.h>
#include <zlib.h>
#define MAX_PAGES 100
#define MAX_OUTPUT (128L*1024L*1024L)
static char temporary[4096];
static void cleanup(void) { if(*temporary) unlink(temporary); }
static void die(const char *s) { fprintf(stderr,"ERROR: %s\n",s); exit(1); }
static long position(FILE *f) { long n=ftell(f);if(n<0||n>MAX_OUTPUT)die("PDF exceeds output limit");return n; }
static unsigned char *decode(cups_raster_t *r,const cups_page_header2_t *h,size_t *len) {
 unsigned w=h->cupsWidth,ht=h->cupsHeight,bpp=h->cupsBitsPerPixel;
 if(!w||!ht||w>6000||ht>6000||!h->HWResolution[0]||!h->HWResolution[1]||h->HWResolution[0]>600||h->HWResolution[1]>600) die("Invalid raster size/resolution");
 double mmw=w*25.4/h->HWResolution[0], mmh=ht*25.4/h->HWResolution[1];
 if(fabs(mmw-241)>0.6||fabs(mmh-140)>0.6)die("Every raster page must be landscape 241x140mm");
 if(h->Duplex||h->NumCopies>1||h->cupsColorOrder!=CUPS_ORDER_CHUNKED)die("One copy, simplex, chunky raster required");
 int gray=h->cupsColorSpace==CUPS_CSPACE_SW||h->cupsColorSpace==CUPS_CSPACE_W;
 int black=h->cupsColorSpace==CUPS_CSPACE_K;
 int rgb=h->cupsColorSpace==CUPS_CSPACE_SRGB||h->cupsColorSpace==CUPS_CSPACE_RGB;
 if(!((gray&&bpp==8&&h->cupsBitsPerColor==8)||(black&&bpp==1&&h->cupsBitsPerColor==1)||(rgb&&bpp==24&&h->cupsBitsPerColor==8)))die("Unsupported raster color space/depth");
 unsigned row=(w*bpp+7)/8;
 if(h->cupsBytesPerLine<row||h->cupsBytesPerLine>20000)die("Invalid raster row length");
 size_t n=(size_t)w*ht;if(n>36000000)die("Raster page too large");
 unsigned char *pixels=malloc(n),*line=malloc(h->cupsBytesPerLine);
 if(!pixels||!line)die("Out of memory");
 for(unsigned y=0;y<ht;y++) {
  if(cupsRasterReadPixels(r,line,h->cupsBytesPerLine)!=h->cupsBytesPerLine)die("Truncated raster; no pages submitted");
  for(unsigned x=0;x<w;x++)pixels[(size_t)y*w+x]=gray?line[x]:black?((line[x/8]&(128>>(x%8)))?0:255):(unsigned char)((54u*line[3*x]+183u*line[3*x+1]+19u*line[3*x+2]+128)/256);
 }
 free(line);*len=n;return pixels;
}
int main(int argc,char **argv) {
 if(argc!=3)die("usage: raster615 input output.pdf");
 atexit(cleanup);
 int fd=open(argv[1],O_RDONLY);if(fd<0)die("Cannot open raster");
 unsigned char magic[12];
 if(read(fd,magic,12)!=12||lseek(fd,0,SEEK_SET)<0)die("Missing raster header");
 uint32_t declared=0;
 if(!memcmp(magic,"UNIRAST\0",8)) {
  declared=((uint32_t)magic[8]<<24)|((uint32_t)magic[9]<<16)|((uint32_t)magic[10]<<8)|magic[11];
  if(declared==UINT32_MAX)declared=0;
  if(declared>MAX_PAGES)die("At most 100 pages per job");
 }
 cups_raster_t *r=cupsRasterOpen(fd,CUPS_RASTER_READ);if(!r)die("Invalid raster stream");
 int n=snprintf(temporary,sizeof(temporary),"%s.tmpXXXXXX",argv[2]);
 if(n<0||(size_t)n>=sizeof(temporary))die("Output path too long");
 int outfd=mkstemp(temporary);if(outfd<0)die("Cannot create private PDF");
 FILE *out=fdopen(outfd,"wb");if(!out)die("Cannot open PDF stream");
 long off[3+3*MAX_PAGES];memset(off,0,sizeof(off));
 fputs("%PDF-1.4\n",out);
 off[1]=position(out);fputs("1 0 obj << /Type /Catalog /Pages 2 0 R >> endobj\n",out);
 cups_page_header2_t h;int pages=0;uint64_t total=0;
 double pw=241.0*72/25.4,ph=140.0*72/25.4;
 while(cupsRasterReadHeader2(r,&h)) {
  if(pages==MAX_PAGES)die("At most 100 pages per job");
  total+=(uint64_t)h.cupsWidth*h.cupsHeight;
  if(total>1024ULL*1024ULL*1024ULL)die("Document exceeds decoded-pixel limit");
  size_t length=0;unsigned char *pixels=decode(r,&h,&length);
  uLongf zn=compressBound(length);unsigned char *z=malloc(zn);
  if(!z||compress2(z,&zn,pixels,length,6)!=Z_OK)die("PDF compression failed");
  free(pixels);
  if((uint64_t)position(out)+zn+65536>MAX_OUTPUT)die("PDF exceeds 128 MiB limit");
  int p=3+3*pages,im=p+1,c=p+2;
  off[p]=position(out);fprintf(out,"%d 0 obj << /Type /Page /Parent 2 0 R /MediaBox [0 0 %.8f %.8f] /Resources << /XObject << /Im0 %d 0 R >> >> /Contents %d 0 R >> endobj\n",p,pw,ph,im,c);
  off[im]=position(out);fprintf(out,"%d 0 obj << /Type /XObject /Subtype /Image /Width %u /Height %u /ColorSpace /DeviceGray /BitsPerComponent 8 /Filter /FlateDecode /Length %lu >> stream\n",im,h.cupsWidth,h.cupsHeight,(unsigned long)zn);
  if(fwrite(z,1,zn,out)!=zn)die("PDF write failed");
  free(z);fputs("\nendstream endobj\n",out);
  char content[160];int len=snprintf(content,sizeof(content),"q %.8f 0 0 %.8f 0 0 cm /Im0 Do Q\n",pw,ph);
  off[c]=position(out);fprintf(out,"%d 0 obj << /Length %d >> stream\n%sendstream endobj\n",c,len,content);
  if(ferror(out))die("PDF write failed");
  pages++;
 }
 cupsRasterClose(r);close(fd);
 if(!pages||(declared&&declared!=(uint32_t)pages))die("Raster page count mismatch or empty input; no pages submitted");
 off[2]=position(out);fprintf(out,"2 0 obj << /Type /Pages /Count %d /Kids [",pages);
 for(int i=0;i<pages;i++)fprintf(out,"%d 0 R ",3+3*i);
 fputs("] >> endobj\n",out);
 int objects=3+3*pages;long xref=position(out);
 fprintf(out,"xref\n0 %d\n0000000000 65535 f \n",objects);
 for(int i=1;i<objects;i++)fprintf(out,"%010ld 00000 n \n",off[i]);
 fprintf(out,"trailer << /Size %d /Root 1 0 R >>\nstartxref\n%ld\n%%%%EOF\n",objects,xref);
 if(ferror(out)||fclose(out))die("PDF write failed");
 if(rename(temporary,argv[2]))die("Cannot publish completed PDF");
 temporary[0]=0;fprintf(stderr,"INFO: Decoded %d raster page(s).\n",pages);return 0;
}
