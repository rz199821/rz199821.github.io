#!/bin/bash
set -u
prefix="$HOME/Library/Application Support/LQ615KII-AirPrint"
printf 'Mac和队列：\n'; /usr/bin/sw_vers; /usr/bin/lpstat -p LQ615KII_Local241
printf '\n本地IPP检查（不创建打印任务）：\n'
"$prefix/probe" localhost
printf '\n后台服务：\n'; /bin/launchctl print "gui/$(id -u)/local.lq615kii.airprint"
printf '\n最近服务记录：\n'; /usr/bin/tail -n 12 "$HOME/Library/Logs/LQ615KII-AirPrint/service.log" "$HOME/Library/Logs/LQ615KII-AirPrint/error.log"
printf '\n日志可能含局域网地址；不要直接公开整份记录。\n'
