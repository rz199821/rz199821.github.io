#!/bin/sh
set -eu
cd "$(dirname "$0")"
# No sudo, no system directories, no queue creation or modification.
make -B pbmto615
install_dir="$HOME/Library/Application Support/LQ615KII-Experiment"
if [ -e "$install_dir" ]; then
  echo 'Target already exists; preserve it and choose another location manually.' >&2
  exit 1
fi
mkdir -p "$install_dir"
cp pbmto615 "$install_dir/pbmto615"
chmod 755 "$install_dir/pbmto615"
printf 'Installed only the local converter: %s/pbmto615\n' "$install_dir"
