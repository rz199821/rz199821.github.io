#!/bin/bash
set -euo pipefail
umask 077
cd "$(dirname "$0")"
bundle_dir="$PWD"
job_dir=""
cleanup() { if [ -n "$job_dir" ] && [ -d "$job_dir" ]; then rm -rf -- "$job_dir"; fi; }
trap cleanup EXIT
trap 'exit 130' INT TERM
fail() { printf '\n%s\n' "$*" >&2; exit 1; }
[ "$(uname -s)" = Darwin ] || fail '此工具只在Mac上运行。'
[ -x /usr/libexec/cups/backend/usb ] || fail '未找到系统USB打印后端。'
mkdir -p .build/module-cache
if [ ! -x .build/pdf615 ] || [ pdf615.swift -nt .build/pdf615 ]; then
  printf '首次运行：正在编译Mac本机PDF转换器（可能需要一会儿）…\n'
  xcrun swiftc -O -module-cache-path "$bundle_dir/.build/module-cache" pdf615.swift -o .build/pdf615 || fail 'PDF工具编译失败。请截图发送编译错误；不要继续打印。'
fi
if [ ! -x .build/pbmto615 ] || [ pbmto615.c -nt .build/pbmto615 ]; then
  xcrun clang -O2 -Wall -Wextra -Werror -std=c11 pbmto615.c -o .build/pbmto615 || fail '打印编码器编译失败。'
fi
pdf_file="$(/usr/bin/osascript -e 'POSIX path of (choose file with prompt "选择要用241×140mm单张纸打印的PDF" of type {"com.adobe.pdf"})')" || exit 0
[ -f "$pdf_file" ] || fail '没有选到PDF文件。'
pages="$(.build/pdf615 count "$pdf_file")"
case "$pages" in ''|*[!0-9]*) fail '无法读取PDF页数。';; esac
printf 'PDF共 %s 页；100%%原尺寸测试，仅接受241×140mm PDF页面，不自动缩放。\n' "$pages"
job_dir="$(mktemp -d "${TMPDIR:-/tmp}/lq615-local.XXXXXX")"
log_dir="$HOME/Library/Logs/LQ615KII"
mkdir -p "$log_dir"
log_file="$log_dir/session-$(date +%Y%m%d-%H%M%S)-$$.log"
# Discover only USB devices; avoid network discovery hanging lpinfo -v.
/usr/libexec/cups/backend/usb > "$job_dir/devices.txt" 2>> "$log_file" || fail "USB设备查询失败。日志：$log_file"
/usr/bin/awk '$1=="direct" && $2 ~ /^usb:\/\/EPSON\/LQ-615KII([?]|$)/ {print $2}' "$job_dir/devices.txt" > "$job_dir/uris.txt"
count="$(/usr/bin/awk 'END {print NR}' "$job_dir/uris.txt")"
[ "$count" = 1 ] || fail '没有找到唯一的LQ-615KII。请开机并连接USB；多台同型号设备请先只保留一台。'
IFS= read -r uri < "$job_dir/uris.txt"
for ((page=1;page<=pages;page++)); do
  printf '\n正在处理第 %s/%s 页…\n' "$page" "$pages"
  .build/pdf615 render "$pdf_file" "$page" "$job_dir/page.pbm" "$job_dir/preview.png"
  .build/pbmto615 --d4 --paper=241x140-original < "$job_dir/page.pbm" > "$job_dir/page.prn"
  /usr/bin/open -a Preview "$job_dir/preview.png"
  # This is a page-by-page manual sheet workflow: never queue all pages at once.
  /usr/bin/osascript -e 'on run argv' -e 'display dialog ("第 " & item 1 of argv & "/" & item 2 of argv & " 页：请检查预览的方向、中文和数字。按100%原尺寸输出，不自动缩放；设备边界及装纸原点仍待验证。\n\n放好一张241×140mm单页纸，241mm横跨进纸口，确认自动装纸并在线。\n\n上一页须完整退出且无残留，再点发送。本按钮发送后不能保证由电脑取消打印机缓冲内容。") buttons {"停止", "发送这一页"} default button "发送这一页" cancel button "停止" with title "LQ-615KII 本机PDF打印"' -e 'end run' "$page" "$pages" >/dev/null || exit 0
  # Authenticate visibly before redirecting backend diagnostics into a log.
  sudo -v || fail '没有获得本机USB发送权限。'
  if ! sudo -n /usr/bin/env DEVICE_URI="$uri" /usr/libexec/cups/backend/usb "$page" "$USER" LQ615KII-PDF 1 '' "$job_dir/page.prn" >> "$log_file" 2>&1; then
    tail -n 15 "$log_file" >&2
    fail "USB发送失败，停止后续页面。日志：$log_file"
  fi
  printf '后端已返回；请以纸张实际输出判断是否成功。日志：%s\n' "$log_file"
  /usr/bin/osascript -e 'display dialog "请检查刚才这页：内容完整、正常退纸，且没有缺纸续打或残留任务。\n\n若异常，请停止，不要连续补纸或重发。" buttons {"停止", "本页正常"} default button "本页正常" cancel button "停止" with title "确认实际输出"' >/dev/null || exit 0
done
printf '\n所选PDF已逐页发送，请核对纸面结果。\n'
