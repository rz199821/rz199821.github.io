#!/bin/bash
set -euo pipefail
prefix='/Library/Printers/LQ615KII-Local'
queue='LQ615KII_Local241'
[ "$(uname -s)" = Darwin ] || { echo '请在Mac上运行。' >&2; exit 1; }
[ -f "$prefix/OWNER" ] && [ "$(cat "$prefix/OWNER")" = 'local.lq615kii.systemqueue.v1' ] || { echo '未找到本工具安装标记；为保护已有文件，不删除任何内容。' >&2; exit 1; }
printf '仅撤销本工具的独立队列和驱动目录；V5与其他打印机保留。\n'
sudo -v
if /usr/bin/lpstat -p "$queue" >/dev/null 2>&1; then
 # Verify the queue is still using our driver before removing it.
 ppd="/etc/cups/ppd/$queue.ppd"
 if ! sudo -n /usr/bin/grep -q '/Library/Printers/LQ615KII-Local/lq615filter' "$ppd"; then
  echo '该队列已改用其他驱动，停止自动卸载，请检查状态。' >&2; exit 1
 fi
 sudo -n /usr/bin/cancel -a "$queue"
 sudo -n /usr/sbin/lpadmin -x "$queue"
fi
for name in pdf615 pbmto615 lq615filter LQ615KII-241x140.ppd OWNER; do
 sudo -n /bin/rm -f "$prefix/$name"
done
sudo -n /bin/rmdir "$prefix" || { echo '目录还有其他文件，已保留它们。'; exit 0; }
printf '已撤销。不会清除打印机硬件中可能已缓冲的内容。\n'
