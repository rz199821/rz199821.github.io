#!/bin/bash
set -uo pipefail
cd "$(dirname "$0")"
printf 'Mac本机驱动检查（不打印）：\n'
/bin/bash driver/Check.command
printf '\niPhone桥接HTTP/HTTPS检查（不打印）：\n'
/bin/bash bridge/Check-AirPrint.command
