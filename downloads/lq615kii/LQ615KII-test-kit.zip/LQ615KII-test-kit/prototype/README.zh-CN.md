# 实验滤镜：编译、安装、打印、撤销

此程序只做 **PBM P4 → 180×180 dpi、24针 ESC *39**。不是PDF解释器、CUPS Raster滤镜或完整macOS驱动。请先读上级 REPORT.zh-CN.md 的协议限制与实机检查表。没有任何命令会自动发送打印作业。

## 1. 离线编译与测试

在Mac终端切换到解包后的 `prototype` 目录：

```sh
xcrun --find clang
make pbmto615
./pbmto615 < fixtures/calibration.pbm > test.prn
```

如未安装Command Line Tools，使用Apple的正常安装流程（`xcode-select --install`）后再编译。下载ZIP不含Linux二进制；若从云工作目录直接复制文件，`make`可能认为Linux测试二进制已是最新，跨系统时应先 `make clean` 再 `make pbmto615`。下文安装脚本也会强制重建。

有Python3时可选运行：

```sh
make test
python3 verify_fixture.py
```

`verify_fixture.py` 检查的是随包的 calibration.prn/PBM；如重新生成了原始样例PBM，应先重新生成同名PRN再运行。测试通过仅意味着字节编码自洽。

## 2. 用户目录安装（不改打印系统）

```sh
sh install-local.sh
```

安装脚本在本机编译，并只安装一个程序到：

```
~/Library/Application Support/LQ615KII-Experiment/pbmto615
```

脚本拒绝覆盖已有同名目录；不使用sudo、不复制Windows DLL、不创建队列、不改默认打印机。它也不向 `/usr/libexec/cups/filter` 注册滤镜。

## 3. PDF转换流程

先确认本机已通过可信来源安装Ghostscript（`gs --version`）。本次云环境已有gs；脚本不替Mac安装包管理器或Ghostscript。中文PDF须嵌入字体或在本机正确渲染。

以下是**仅第一页、缩放到A4可打印区**的测试流程。`-dPDFFitPage`会缩放整页，不能用这个路径打印需1:1精确尺寸的票据。

```sh
gs -q -dSAFER -dBATCH -dNOPAUSE \
  -sDEVICE=pbmraw -r180 -g1443x2044 -dFIXEDMEDIA -dPDFFitPage \
  -dFirstPage=1 -dLastPage=1 \
  -sOutputFile=page.pbm fixtures/calibration.pdf
"$HOME/Library/Application Support/LQ615KII-Experiment/pbmto615" \
  < page.pbm > page.prn
```

先检查转换退出码和PBM图像，再发送PRN。不要把PDF或UTF-8中文文本直接送到原始队列。若转换失败，勿发送空的或部分生成的输出文件；不要用一个没有保留退出码的shell管道把转换直接接到打印命令。

需要对照D4前导时，只改第二条命令为 `pbmto615 --d4`，输出到新的 `page-d4.prn`；一次只送一个样本。`--d4`仅增加GPD前导，不实现D4帧、通道协商或双向监视器。

## 4. 可选：建立独立的CUPS实验队列

先记录当前状态：

```sh
sw_vers
uname -m
lpstat -t
lpinfo -v
lpinfo -m
```

从本机 `lpinfo -v` 选取**已连接这台打印机**的完整URI，不从INF猜USB URI，不照抄其他型号地址。确认没有同名队列，然后在仍支持raw队列的CUPS/macOS上执行：

```sh
lpstat -p LQ615KII_Experiment
# 若上条显示已存在，停止；不要覆盖现有队列。
# 将下面变量值替换成本机确认的完整URI。
PRINTER_URI='REPLACE_WITH_THE_CONFIRMED_URI'
sudo lpadmin -p LQ615KII_Experiment -v "$PRINTER_URI" -m raw -E
```

这一步需要本机管理员权限；**不要执行含占位符的命令**。不运行 `lpoptions -d`，保留现有默认打印机。若系统拒绝raw队列或 `-m raw`，到此停止；不要关闭系统保护、修改系统CUPS目录或改用随机喷墨PPD。该系统需要另行实现并验证Printer Application/合适的受支持队列路径。

准备好单页纸后，只发送已检查的PRN：

```sh
lp -d LQ615KII_Experiment -o raw page.prn
lpstat -o LQ615KII_Experiment
```

CUPS raw队列仅负责传输，**没有自动PDF转换**。不同macOS的USB后端可能有额外要求；队列完成不代表设备打印正确。用面板、输出纸张和日志共同判断。网络服务器若不透明传输，须先解决服务器协议；本方案未验证任何网络打印盒。

## 5. 撤销

仅在确实创建了本次实验队列时，停止它的未完成作业并删除它：

```sh
cancel -a LQ615KII_Experiment
sudo lpadmin -x LQ615KII_Experiment
```

确认没有对同名现有队列复用这些命令。取消传输未必能清空打印机硬件缓冲，应按机器手册操作面板停止/复位。

删除本次安装的单个用户程序及空目录：

```sh
rm "$HOME/Library/Application Support/LQ615KII-Experiment/pbmto615"
rmdir "$HOME/Library/Application Support/LQ615KII-Experiment"
```

`rmdir` 遇到其他文件会拒绝删除，保留新增内容。随后可自行删除工作目录内的page.pbm/page.prn；无需卸载Windows组件，也无需重启CUPS。Command Line Tools、Ghostscript若为原有软件不要卸载。本实验不修改默认打印机、PPD、系统MIME或系统滤镜目录。

## 6. 当前交付状态

Linux编译、7项测试、PDF转换和完整位图往返比较通过；macOS编译、CUPS raw队列、设备字节接收、D4行为、针序、真实dpi、纸边距、走纸与退纸均待实机验证。标准纸型和多页支持尚未实现，勿将此原型用于正式票据。
