v2.0.3 修复 macOS TLS 凭据查询的重复加锁：调用方已持有非递归 tls_mutex，凭据查询助手不能再次加同一把锁。保持调用方对查找与创建证书的保护。安装和检查程序现在验证真实 HTTPS，而不只检查普通 HTTP。已有v2用户可运行本包 Repair-TLS.command，复用Downloads中的已编译源码；无需卸载USB驱动。修复器先验证源码哈希、编译、签名和候选HTTPS，通过后更新用户接收服务，失败时尝试恢复原程序。

v2.0.3 在两个光栅程序中先包含 Apple TargetConditionals.h，再加载 CUPS 头文件，修正用户 macOS 编译时 TARGET_OS_OSX 未定义的问题；保留 -Werror。

本次 v2.0.3 修复用户在 macOS 12.2.1 上遇到的编译错误：CUPS 的 macOS TLS 分支调用 _cupsSetHTTPError 时漏传 http 参数；同步修正构建失败后仍继续执行下一步的问题。没有删除 TLS、签名或协议自检。此 macOS 分支修正仍需原生重试确认。

# LQ615KII iPhone 接收服务 v2.0.3（实机待验证）

目标：iPhone 打开 241×140mm 单页 PDF，在系统“共享→打印”中选择 **LQ615KII iPhone v2**，通过这台 Mac 已安装的 LQ615KII_Local241 队列打印。

本版增加完整 IPP 接收、实际 Apple URF/PWG 解码和 PDF 转换，不再只是广播一个 PDF 队列名称。安装与协议自检不会打印。Linux 回环集成测试通过；本版在 macOS 上的编译、Bonjour/iPhone 发现、纸型选择和实际出纸尚未验证，不能当作已认证的 AirPrint 产品。

## 安装

1. 在已经能正常打印的那台 Mac 上解压本包。保留整个文件夹，不要单独移动脚本。
2. 双击 **Install-AirPrint.command**。也可以在终端运行（如果下载文件夹被加上“2”，请用实际文件夹名）：

   ```bash
   bash "$HOME/Downloads/LQ615KII-AirPrint-v2.0.3/Install-AirPrint.command"
   ```

3. 等待本机编译完成。需要 Apple 命令行工具中的 Clang；已安装系统驱动时用过的工具可复用，无需完整 Xcode。本包内附 CUPS 源码，安装阶段不再下载 GitHub 文件。编译失败时会显示日志位置，旧后台服务不会被替换。
4. 出现“新版接收服务已启动”后，让 Mac 保持登录、不休眠，USB 连接打印机。手机和 Mac 连接可互通的同一 Wi-Fi。若系统防火墙询问，允许本工具 `ippeveprinter` 接收局域网连接。
5. 关闭手机原来的打印面板，重新打开 PDF→共享→打印，选择 **LQ615KII iPhone v2**。先测试 **1页、1份**，确认纸型和预览是 241×140mm，再装好一张纸打印。如果选择打印机后仍变成 A4/美国信纸，先不要打印。

可以先在没有接上打印机时安装，但实际测试时必须连接。这不是安装 USB 驱动的替代包：Mac 必须已有正常工作的 LQ615KII_Local241 队列及 /Library/Printers/LQ615KII-Local/pdf615。

目标为具备 Apple 命令行工具和现有驱动的 Mac（Intel 或 Apple Silicon）；本版本没有完成这些架构/系统的原生测试。现有 USB 驱动的成功记录不等于本次手机接收服务已经验证。

## 保持的打印效果

- 241×140mm 手动单张，横向页面。
- 90% 等比、标准较细、墨迹左右居中、顶部对齐，位置 0,0。
- 90% 只由 Mac USB 驱动执行一次。接收器预检生成的 PBM 会丢弃，送入队列的是原尺寸 PDF。
- 本版一次接受单页、单份、单面；多页 PDF 请先导出需要的一页。照片、A4、不同纸型不在本次接入范围内。

## 与旧版本的关系

安装器先完成编译、真实 URF 解码、PDFKit 预检、Get-Printer-Attributes 和 Validate-Job。后两项只查询，不创建打印任务。

只有检查通过后，才暂停本工具旧版 `local.lq615kii.airprint` 发现服务，并把其启动配置移到原目录 `LaunchAgent.before-v2.plist`，防止下次登录时两个版本一起运行。旧文件保留；卸载 v2 会恢复原启动配置和原先的加载状态。

新版使用独立用户目录 `~/Library/Application Support/LQ615KII-AirPrint-v2`、用户 LaunchAgent `local.lq615kii.airprint.v2` 和 TCP 8631。不会替换 macOS 的 CUPS，不修改已成功的 USB 驱动、默认打印机或防火墙，也不需要额外开启系统打印机共享。原来已开启的共享保持原状。

接收服务面向可互通的可信局域网，使用与普通局域网打印机类似的无密码打印入口。TLS 由 CUPS 的原生实现处理，Mac 使用其正常用户 CUPS 密钥链（`~/.cups/ssl.keychain`）；没有关闭证书验证或安装系统信任证书。Mac 当前用户必须保持登录。

## 状态与撤销

双击 **Check-AirPrint.command** 查看只读协议检查和最近接收记录。日志位于 `~/Library/Logs/LQ615KII-AirPrint-v2`，可能含文件名和局域网地址。

双击 **Uninstall-AirPrint.command** 只卸载本版用户接收服务，并按记录恢复旧版发现服务。Mac USB 驱动和队列保留。

手机上的任务完成表示“已提交 Mac 队列”，不能证明纸面已经打印完成。提交后如果需要取消，应在 Mac 的打印队列中取消；本版不把手机后续的取消操作同步到已提交的 USB 任务。不要因为纸未装好反复点打印。

## 实现和验证范围

- 使用官方 OpenPrinting CUPS 2.4.16 的 ippeveprinter / ipptool 和完整 IPP 协议处理。
- 实际支持 PDF、URF、PWG；URF/PWG 解码可处理灰8、黑1、RGB24，但广播仅声明单色 W8 与黑1/灰8，300/600dpi。
- 所有输入完整转换、检查页数和原有驱动预检后才提交。不同纸型、多页、双面、多份、超界、截断数据或渲染失败会停止，不直接向 USB 写数据。
- 上游网络服务补丁仅包括：默认输入加入 PDF、禁用 Print-URI/Send-URI（不接收本机或远端引用文件）、单份限制、拒绝选项替代、不声明完整 IPP Everywhere 符合性、修正自定义 media-col 匹配条件。详见 server.patch。
- Linux 31 项检查通过（含使用受信测试证书与主机名校验的真实HTTPS能力查询和Validate-Job），包含真实 IPP Print-Job、Create-Job/Send-Document、能力/纸型查询、实际光栅编解码及失败路径。测试使用模拟的 PDFKit 预检和最终队列，未触及真实打印机；Ghostscript 单独核对转换 PDF 的尺寸、方向和黑白。
- macOS 安装器会在本机进一步验证原生编译、签名、实际系统 libcups URF 解码、原有 PDFKit 预检与真实 IPP 查询。通过后仍需 iPhone/纸面测试。

`vendor` 内附官方源码及 Apache 2.0 LICENSE/NOTICE；来源：
https://github.com/OpenPrinting/cups/releases/download/v2.4.16/cups-2.4.16-source.tar.gz

源码 SHA-256：`0339587204b4f9428dd0592eb301dec0bf9ea6ea8dce5d9690d56be585aba92d`

开发测试：已构建并打过本包补丁的 CUPS 目录下有 tools/ippeveprinter-static、tools/ipptool-static、cups/libcups.a 后，可用 Python 3（需 Pillow/Ghostscript）运行 `python3 tests/integration.py /path/to/cups-2.4.16`。用户安装不需要 Python、Pillow 或 Ghostscript。
