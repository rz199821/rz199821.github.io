#!/bin/bash
set -euo pipefail
[ "$(uname -s)" = Darwin ] || { echo '请在Mac上运行。';exit 1; }
if xcrun --find clang >/dev/null 2>&1 && xcrun --find swiftc >/dev/null 2>&1; then
 echo 'Apple命令行工具已就绪，直接双击Install.command即可。'
else
 /usr/bin/xcode-select --install
 echo '请完成弹出窗口中的工具下载和安装，再双击Install.command。'
fi
