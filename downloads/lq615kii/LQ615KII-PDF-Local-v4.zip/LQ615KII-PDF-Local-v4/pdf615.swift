import Foundation
import AppKit
import PDFKit

func fail(_ message: String) -> Never {
    FileHandle.standardError.write(Data(("ERROR: " + message + "\n").utf8))
    exit(1)
}
let args = CommandLine.arguments
guard args.count >= 3 else { fail("usage: pdf615 count file.pdf | render file.pdf page output.pbm preview.png") }
guard let document = PDFDocument(url: URL(fileURLWithPath: args[2])) else { fail("Cannot open PDF") }
guard !document.isLocked else { fail("Password-protected PDF: export an unlocked copy first") }
if args[1] == "count" {
    guard args.count == 3, document.pageCount > 0 else { fail("Empty PDF or invalid arguments") }
    print(document.pageCount)
    exit(0)
}
guard args[1] == "render", (args.count >= 6 && args.count <= 11),
      let number = Int(args[3]), number > 0, number <= document.pageCount,
      let page = document.page(at: number - 1) else { fail("Invalid page or arguments") }
let percent: Int
if args.count >= 7 {
    guard let selected = Int(args[6]), selected == 100 || selected == 90 || selected == 85 else { fail("Select 100, 90 or 85 percent explicitly") }
    percent = selected
} else { percent = 100 }
let threshold: Double
if args.count >= 8 {
    guard let selected = Int(args[7]), selected == 128 || selected == 192 else { fail("Select a threshold of 128 or 192") }
    threshold = Double(selected)
} else { threshold = 128.0 }
let layout = args.count >= 9 ? args[8] : "legacy"
guard ["legacy", "ink-center"].contains(layout) else { fail("Invalid layout") }
func adjustment(_ index: Int) -> Double {
    if args.count <= index { return 0 }
    guard let value = Double(args[index]), value.isFinite, abs(value) <= 10 else { fail("Adjustment must be a number between -10 and +10 mm") }
    return value
}
let shiftX = Int((adjustment(9) * 180.0 / 25.4).rounded())
let shiftY = Int((adjustment(10) * 180.0 / 25.4).rounded())
// Accept only a page matching the actual paper. Never silently
// fit an A4 page or crop a larger drawing down to this sheet.
let bounds = page.bounds(for: .cropBox)
guard page.rotation % 360 == 0 else { fail("Rotated PDF pages need to be exported with rotation applied before this original-size test") }
let mmWidth = Double(bounds.width) * 25.4 / 72.0
let mmHeight = Double(bounds.height) * 25.4 / 72.0
guard abs(mmWidth - 241.0) < 0.5, abs(mmHeight - 140.0) < 0.5 else {
    fail("This diagnostic requires a 241x140mm PDF page; this page is \(mmWidth)x\(mmHeight)mm. No shrinking or cropping was performed")
}
let width = Int((Double(bounds.width) * 180.0 / 72.0).rounded())
let height = Int((Double(bounds.height) * 180.0 / 72.0).rounded())
guard width <= 1708, height <= 992 else { fail("Page raster exceeds the original-size test limits") }
let renderWidth = Int((Double(width) * Double(percent) / 100.0).rounded())
let renderHeight = Int((Double(height) * Double(percent) / 100.0).rounded())
// PDFKit renders embedded fonts and respects PDF page rotation. This uses
// native PDFKit; no PDF or printer data is sent over the network.
let thumbnail = page.thumbnail(of: NSSize(width: CGFloat(renderWidth), height: CGFloat(renderHeight)), for: .cropBox)
guard let image = thumbnail.cgImage(forProposedRect: nil, context: nil, hints: nil) else { fail("PDF rendering failed") }
let bitmap = NSBitmapImageRep(cgImage: image)
let scale = min(Double(renderWidth) / Double(bitmap.pixelsWide), Double(renderHeight) / Double(bitmap.pixelsHigh))
let drawWidth = max(1, min(renderWidth, Int((Double(bitmap.pixelsWide) * scale).rounded())))
let drawHeight = max(1, min(renderHeight, Int((Double(bitmap.pixelsHigh) * scale).rounded())))
// Ink centering uses a bounded print-coordinate trial span, not an assumed
// measured physical paper origin. Real paper centering needs calibration.
let horizontalSpan = layout == "ink-center" ? min(width, 1476) : width
// First render at the origin in ink-center mode, then translate marked pixels
// as a rigid group. No rescaling, erosion or clipping during placement.
let offsetX = layout == "ink-center" ? 0 : (horizontalSpan - drawWidth) / 2 + shiftX
let offsetY = layout == "ink-center" ? 0 : (height - drawHeight) / 2 + shiftY
var inkLeft = width, inkRight = -1, inkTop = height, inkBottom = -1
let stride = (width + 7) / 8
var bits = [UInt8](repeating: 0, count: stride * height)
// NSBitmapImageRep row coordinates address the rendered image top-to-bottom;
// do not introduce another PDF coordinate flip. Verify on the first page.
for y in 0..<drawHeight {
    let sy = min(bitmap.pixelsHigh - 1, Int((Double(y) + 0.5) / scale))
    for x in 0..<drawWidth {
        let sx = min(bitmap.pixelsWide - 1, Int((Double(x) + 0.5) / scale))
        guard let color = bitmap.colorAt(x: sx, y: sy)?.usingColorSpace(.deviceRGB) else { fail("Unable to read rendered pixel") }
        let alpha = Double(color.alphaComponent)
        let luminance = 255.0 * (alpha * (0.2126 * Double(color.redComponent) + 0.7152 * Double(color.greenComponent) + 0.0722 * Double(color.blueComponent)) + 1.0 - alpha)
        // Threshold is explicit: 128 standard; 192 preserves the previous darker setting.
        if luminance < threshold {
            let dx = x + offsetX, dy = y + offsetY
            guard dx >= 0, dx < width, dy >= 0, dy < height else {
                fail("Position would cut marked content at the paper edge; no files written and no printing")
            }
            
            inkLeft = min(inkLeft, dx); inkRight = max(inkRight, dx)
            inkTop = min(inkTop, dy); inkBottom = max(inkBottom, dy)
            bits[dy * stride + dx / 8] |= UInt8(0x80 >> (dx % 8))
        }
    }
}
guard inkRight >= 0 else { fail("Blank page; nothing to print") }
if layout == "ink-center" {
    let inkWidth = inkRight - inkLeft + 1, inkHeight = inkBottom - inkTop + 1
    guard inkWidth <= horizontalSpan, inkHeight <= height else {
        fail("Content at this selected scale exceeds the trial area; no auto shrinking and no printing")
    }
    let newLeft = (horizontalSpan - inkWidth) / 2 + shiftX
    let newTop = (height - inkHeight) / 2 + shiftY
    guard newLeft >= 0, newLeft + inkWidth <= horizontalSpan,
          newTop >= 0, newTop + inkHeight <= height else {
        fail("Position adjustment would exceed the trial area; return adjustment to 0,0. No printing")
    }
    var placed = [UInt8](repeating: 0, count: bits.count)
    for y in inkTop...inkBottom { for x in inkLeft...inkRight {
        if bits[y * stride + x / 8] & UInt8(0x80 >> (x % 8)) != 0 {
            let dx = x - inkLeft + newLeft, dy = y - inkTop + newTop
            placed[dy * stride + dx / 8] |= UInt8(0x80 >> (dx % 8))
        }
    } }
    bits = placed
    inkLeft = newLeft; inkRight = newLeft + inkWidth - 1
    inkTop = newTop; inkBottom = newTop + inkHeight - 1
}
var pbm = Data("P4\n\(width) \(height)\n".utf8)
pbm.append(contentsOf: bits)
// Write a preview of the exact thresholded PBM pixels, not a second rendering.
let previewWidth = layout == "ink-center" ? horizontalSpan : width
guard let preview = NSBitmapImageRep(bitmapDataPlanes: nil, pixelsWide: previewWidth, pixelsHigh: height,
    bitsPerSample: 8, samplesPerPixel: 1, hasAlpha: false, isPlanar: false,
    colorSpaceName: .deviceWhite, bytesPerRow: previewWidth, bitsPerPixel: 8),
    let pixels = preview.bitmapData else { fail("Preview allocation failed") }
for y in 0..<height { for x in 0..<previewWidth {
    pixels[y * preview.bytesPerRow + x] = bits[y * stride + x / 8] & UInt8(0x80 >> (x % 8)) != 0 ? 0 : 255
} }
guard let png = preview.representation(using: .png, properties: [:]) else { fail("Preview encoding failed") }
do {
    try pbm.write(to: URL(fileURLWithPath: args[4]), options: .atomic)
    try png.write(to: URL(fileURLWithPath: args[5]), options: .atomic)
} catch { fail(error.localizedDescription) }
print("Page \(number): \(width)x\(height) monochrome; \(percent) percent, black threshold \(Int(threshold)); printer horizontal span and margins need physical verification")

print("Layout: \(layout); adjustments \(adjustment(9))mm right, \(adjustment(10))mm down; ink box \(inkLeft),\(inkTop)-\(inkRight),\(inkBottom)")
