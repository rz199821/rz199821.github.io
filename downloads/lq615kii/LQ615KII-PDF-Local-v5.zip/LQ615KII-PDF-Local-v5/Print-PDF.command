#!/bin/bash
set -euo pipefail
umask 077
cd "$(dirname "$0")"
bundle_dir="$PWD"
job_dir=""
cleanup() { if [ -n "$job_dir" ] && [ -d "$job_dir" ]; then rm -rf -- "$job_dir"; fi; }
trap cleanup EXIT
trap 'exit 130' INT TERM
fail() { printf '\n%s\n' "$*" >&2; exit 1; }
[ "$(uname -s)" = Darwin ] || fail '此工具只在Mac上运行。'
[ -x /usr/libexec/cups/backend/usb ] || fail '未找到系统USB打印后端。'
mkdir -p .build/module-cache
if [ ! -x .build/pdf615 ] || [ pdf615.swift -nt .build/pdf615 ]; then
  printf '首次运行：正在编译Mac本机PDF转换器（可能需要一会儿）…\n'
  xcrun swiftc -O -module-cache-path "$bundle_dir/.build/module-cache" pdf615.swift -o .build/pdf615 || fail 'PDF工具编译失败。请截图发送编译错误；不要继续打印。'
fi
if [ ! -x .build/pbmto615 ] || [ pbmto615.c -nt .build/pbmto615 ]; then
  xcrun clang -O2 -Wall -Wextra -Werror -std=c11 pbmto615.c -o .build/pbmto615 || fail '打印编码器编译失败。'
fi
pdf_file="$(/usr/bin/osascript -e 'POSIX path of (choose file with prompt "选择要用241×140mm单张纸打印的PDF" of type {"com.adobe.pdf"})')" || exit 0
[ -f "$pdf_file" ] || fail '没有选到PDF文件。'
pages="$(.build/pdf615 count "$pdf_file")"
case "$pages" in ''|*[!0-9]*) fail '无法读取PDF页数。';; esac
layout_choice="$(/usr/bin/osascript -e 'set selectedItems to choose from list {"90%：左右居中、顶部对齐（默认）", "85%：左右居中、顶部对齐", "100%：原尺寸原位置"} with prompt "按你的选择默认90%。保持已有左右居中，去掉软件额外上方留白，改为顶部对齐；打印机本身的装纸顶边距不由此消除。\n\n90%若超过范围会停止，不会自动缩小或裁字。实际纸面位置仍需校准。" default items {"90%：左右居中、顶部对齐（默认）"}' -e 'if selectedItems is false then error number -128' -e 'return item 1 of selectedItems')" || exit 0
case "$layout_choice" in
  '90%'*) scale_percent=90; layout_mode=ink-center;;
  '85%'*) scale_percent=85; layout_mode=ink-center;;
  '100%'*) scale_percent=100; layout_mode=legacy;;
  *) exit 0;;
esac
adjustments="$(/usr/bin/osascript -e 'text returned of (display dialog "可选位置微调，单位毫米：\n填写：左右,上下\n左右限±10；正数向右、负数向左。上下填写0至10，正数增加上方留白。\n\n第一次保持0,0；顶部对齐后上下偏移仅能为0或正数。若移动使内容超出试验范围，工具会停止而不裁字。" default answer "0,0" buttons {"取消", "确定"} default button "确定" cancel button "取消" with title "位置微调")')" || exit 0
case "$adjustments" in
  *,*) shift_x="${adjustments%%,*}"; shift_y="${adjustments#*,}";;
  *) fail '请输入两个数字，以英文逗号分隔，例如0,0或2,-1。';;
esac
ink_choice="$(/usr/bin/osascript -e 'button returned of (display dialog "选择黑白转换效果：\n\n标准较细：只把较深的像素印成黑点。\n原较深：保留上一版的设置，灰色边缘更容易变黑。\n\n这是位图阈值，不改变字体、比例或打印针击打力度。对比时请保持与上一张相同的比例。" buttons {"取消", "原较深", "标准较细"} default button "标准较细" cancel button "取消" with title "选择文字效果")')" || exit 0
case "$ink_choice" in
  '标准较细') ink_threshold=128;;
  '原较深') ink_threshold=192;;
  *) exit 0;;
esac
printf 'PDF共 %s 页；本次比例 %s%%，文字效果：%s。\n' "$pages" "$scale_percent" "$ink_choice"
job_dir="$(mktemp -d "${TMPDIR:-/tmp}/lq615-local.XXXXXX")"
log_dir="$HOME/Library/Logs/LQ615KII"
mkdir -p "$log_dir"
log_file="$log_dir/session-$(date +%Y%m%d-%H%M%S)-$$.log"
# Discover only USB devices; avoid network discovery hanging lpinfo -v.
/usr/libexec/cups/backend/usb > "$job_dir/devices.txt" 2>> "$log_file" || fail "USB设备查询失败。日志：$log_file"
/usr/bin/awk '$1=="direct" && $2 ~ /^usb:\/\/EPSON\/LQ-615KII([?]|$)/ {print $2}' "$job_dir/devices.txt" > "$job_dir/uris.txt"
count="$(/usr/bin/awk 'END {print NR}' "$job_dir/uris.txt")"
[ "$count" = 1 ] || fail '没有找到唯一的LQ-615KII。请开机并连接USB；多台同型号设备请先只保留一台。'
IFS= read -r uri < "$job_dir/uris.txt"
for ((page=1;page<=pages;page++)); do
  printf '\n正在处理第 %s/%s 页…\n' "$page" "$pages"
  .build/pdf615 render "$pdf_file" "$page" "$job_dir/page.pbm" "$job_dir/print-area-preview.png" "$scale_percent" "$ink_threshold" "$layout_mode" "$shift_x" "$shift_y"
  .build/pbmto615 --d4 --paper=241x140-original < "$job_dir/page.pbm" > "$job_dir/page.prn"
  /usr/bin/open -a Preview "$job_dir/print-area-preview.png"
  # This is a page-by-page manual sheet workflow: never queue all pages at once.
  /usr/bin/osascript -e 'on run argv' -e 'display dialog ("第 " & item 1 of argv & "/" & item 2 of argv & " 页：请检查预览的方向、中文和数字。本次布局：" & item 3 of argv & "，文字效果：" & item 4 of argv & "。预览是可打印试验区域，纸面精确居中还需量边距；请检查备注列和金额是否完整。\n\n放好一张241×140mm单页纸，241mm横跨进纸口，确认自动装纸并在线。\n\n上一页须完整退出且无残留，再点发送。本按钮发送后不能保证由电脑取消打印机缓冲内容。") buttons {"停止", "发送这一页"} default button "发送这一页" cancel button "停止" with title "LQ-615KII 本机PDF打印"' -e 'end run' "$page" "$pages" "$layout_choice" "$ink_choice" >/dev/null || exit 0
  # Authenticate visibly before redirecting backend diagnostics into a log.
  sudo -v || fail '没有获得本机USB发送权限。'
  if ! sudo -n /usr/bin/env DEVICE_URI="$uri" /usr/libexec/cups/backend/usb "$page" "$USER" LQ615KII-PDF 1 '' "$job_dir/page.prn" >> "$log_file" 2>&1; then
    tail -n 15 "$log_file" >&2
    fail "USB发送失败，停止后续页面。日志：$log_file"
  fi
  printf '后端已返回；请以纸张实际输出判断是否成功。日志：%s\n' "$log_file"
  /usr/bin/osascript -e 'display dialog "请检查刚才这页：内容完整、正常退纸，且没有缺纸续打或残留任务。\n\n若异常，请停止，不要连续补纸或重发。" buttons {"停止", "本页正常"} default button "本页正常" cancel button "停止" with title "确认实际输出"' >/dev/null || exit 0
done
printf '\n所选PDF已逐页发送，请核对纸面结果。\n'
