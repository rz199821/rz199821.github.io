# Epson LQ-615KII：Windows x64 包与 macOS 实验方案

结论：该包明确把 LQ-615KII 绑定到 Unidrv + Epson OEM 插件。解压后的 **EBSD112N.GPD 中按分辨率选择的命令定义**，支持制作 24 针、180×180 dpi、ESC `*` 模式 39 的有限实验实现。它不证明设备完整支持 ESC/P2，也不证明通用 ESC/P2 喷墨驱动兼容。Windows DLL 不能直接用于 macOS。本次交付是离线验证过的 PBM 光栅转换器及 CUPS 原始发送流程，**不是已获实机验证的完整 macOS 驱动**。

## 1. 材料与证据边界

- 输入 ZIP：`LQ-610KII series_WINX64_13.zip`，3,635,692 字节。
- SHA-256：`136c35dc5fbacd86578ec873630600c86b784fd04577226cd5ccdb59bdf56801`。
- ZIP 文件名的 610 与目标 615 不矛盾：以 INF 的设备绑定为准，不按压缩包名称推断型号。
- 只解包、解析和静态检查；未运行 EXE/DLL，未执行附件内的安装指令。原 Git 仓库未改动。
- `source/` 保留原始解包内容；`expanded/` 保留 CAB/SZDD 展开结果；`evidence/manifest.json` 记录 ZIP 内文件大小与 SHA-256。`extract.py`、`evidence_tools.py` 可复现展开和纸张提取，依赖 Linux libarchive。
- `evidence/EBSD112N.INF.txt` 是 UTF-16 INF 的 UTF-8 转写；`evidence/EBSD112N.GPD.txt` 是展开 GPD 的文本副本；以下行号均对应这些副本。
- CAT 存在，但未进行 Windows 驱动目录签名与信任链验证。文件摘要仅标识分析材料，不等于厂商真实性证明。
- 未取得同型号官方完整命令手册，未捕获 Windows 实际作业输出，未连接打印机或 macOS。本次访问外部源时本地代理连接失败；原型不依赖新增下载。

## 2. INF 入口与依赖闭包

入口 INF 行 8–54：DriverVer `06/05/2018,1.3.0.0`，`NTamd64.6` 和 `NTamd64` 两条安装分支；设备名 `EPSON LQ-615KII ESC/P2`，硬件 ID 为 `USBPRINT\EPSONLQ-615KII3AEA` 与 `LPTENUM\EPSONLQ-615KII3AEA`。这是 USB/并口枚举绑定，**不提供 USB VID/PID 数值**，也不证明 IPP、AirPrint、PostScript 或 PCL 支持。

| 路径/逻辑文件 | 来自何处 | 作用与限制 |
|---|---|---|
| EBSD112N.GPD | EBSD112N.GP_，MSCF CAB | DataFile，核心型号描述；含明确命令与特性分支 |
| EBSD112N.INI | 原文件 | OEMConfigFile1=EBSUIPIF.DLL；OEMDriverFile1=EBSRDPID.DLL |
| EBSDRES0.DLL | EBSDRES0.DL_，CAB | GPD ResourceDLL，字体/界面资源；不能把资源字符串当作支持证明 |
| EBSUIPIF.DLL | EBSUIPIF.DL_，CAB | OEM 配置插件；Windows PE x64 |
| EBSRDPID.DLL | EBSRDPID.DL_，CAB | OEM 渲染插件；Windows PE x64；导出 DllGetClassObject/DllCanUnloadNow，依赖 KERNEL32/GDI32/SPOOLSS/ADVAPI32；不能假定 GPD 就是最终全部输出逻辑 |
| EBSUIPIF.CHM | LANG/*/EBSUIPIF.CH_，CAB | 21 种语言帮助；CAB 内部名为 EBSUIPI1.CHM，安装逻辑名来自 INF；未解码 CHM 页面，不以帮助字符串证明命令 |
| EBPMONB.DLL | EBPMONB.DL_，SZDD | `EPSON SIDM BS64MonitorB` 语言监视器；本次已展开并保留 PE 表 |
| ECBTEGB.DLL | ECBTEGB.DL_，SZDD | 随 EBPMON 复制的通信组件；不能直接移植到 CUPS |
| EBSD112U.EXE/DAT/DLL | EBSD112U.EX_/DA_/DL_，CAB | 安装/卸载辅助，内部名 epupdate.exe/EPUPDATE.DAT/e_gifx01.dll；不能按内部名误判缺失 |
| E_DSIDMB.LMD | 原文件 | EBAPI 复制项 |
| ebsd112n.cat | 原文件 | INF CatalogFile；本次未验证目录签名 |
| UNIDRV.DLL / UNIDRVUI.DLL / UNIDRV.HLP | Windows 系统，包外 | XP 分支 DataSection 与 ntprint.inf/UNIDRV.OEM；新分支 CoreDriverSections/CoreDriverDependencies GUID `{D20EA372-DD35-4950-9ED8-A6335AFE79F0}` |
| StdNames.gpd / Unidrv 数据与字体资源 | Windows 核心驱动，包外 | GPD Include；ZIP 不包含。标准纸名的尺寸/资源因此有外部依赖 |

INF `[MINIDRV]`、`[EBPMON]`、`[EPSETUP]`、`[EBAPI]` 与 `[SourceDisksFiles]` 的厂商复制项均找到对应原文件或压缩载荷。系统依赖不在包内属于预期，并不意味着 ZIP 自包含。包中另有 EBSD111N 分支，分析原型只使用 112N，不混用邻近型号特性。

## 3. 分辨率与位图协议

GPD 行 40–79 有三个 Resolution 选项，默认 Option3：

| 选项 | dpi / TextDPI | PinsPerLogPass / PhysPass | CmdSendBlockData 的实际模板 |
|---|---|---|---|
| Option1 | 360×180 | 24 / 24 | `1B 2A 28` + `%l{NumOfDataBytes/3}`，m=40 |
| Option3（默认） | 180×180 | 24 / 24 | `1B 2A 27` + `%l{NumOfDataBytes/3}`，m=39 |
| Option4 | 120×180 | 24 / 24 | `1B 2A 21` + `%l{NumOfDataBytes/3}`，m=33 |

这里的 `(`、`'`、`!` 是 `ESC *` 的单字节参数 0x28/0x27/0x21，**不是 ESC ( 扩展光栅命令**。这是有条件的命令定义，证据强于出现“ESC/P2”字样。`%l` 为 GPD 的低字节在前参数输出；列数为数据字节数/3。配合 `OutputDataFormat: V_BYTE`（行 1136），可实现每列三个纵向字节、每字节高位先上的实验编码。针位顺序的实现仍需实机小图案确认。

没有 360×360、720 dpi、彩色模式或压缩光栅选项的证据。MasterUnits=720×720 是描述/布局坐标，不是实际打印分辨率。原型只实现默认 180×180，不冒充实现其他两档。

## 4. 纸张、可打印区、走纸

GPD 行 81–938，共 **22 个纸张选项，含 CUSTOMSIZE**；完整参数见 `evidence/papers.csv`。所有坐标以 1/720 英寸表示，换算毫米乘 25.4/720，换算 CUPS points 除以 10。

- 标准单页：LETTER、LEGAL、A4（默认）、A5、B5、B4、STATEMENT。标准选项未在本文件显式给出 PageDimensions，不能脱离 StdNames.gpd 断言完整尺寸和 B4/B5 标准。
- 连续纸：EP_LETTER_FANFOLD、EP_A4_FANFOLD、EP_FANFOLD_210x305、FANFOLD_STD_GERMAN、FANFOLD_LGL_GERMAN。
- 其他表单：EP_3_13x4、EP_7_45x4_57、EP_9x5、EP_9.5x3_23、EP_9.5x4、EP_9.5x5、EP_9.5x5.5、EP_9.5x6、EP_9.5x11。以 CSV 内显式 PageDimensions 为准，例如 EP_7_45x4_57 实际为 5616×3394 单位，不能按选项名字猜尺寸。
- A4：360 dpi 横向档的面积 5780×8176、原点 86×120；默认 180 dpi 面积 **5772×8176**、原点 **88×120**，即约 203.62×288.43 mm、原点 3.10×4.23 mm。180 dpi 实验画布取 1443×2044 像素。
- EP_A4_FANFOLD 的显式纸张为 5952×8400 单位（约 209.97×296.33 mm），180 dpi 面积 5204×8160、原点 372×120，不能直接复用单页 A4 边距。
- B4 面积宽仅 5904 单位（8.2 英寸），且原点 x=692；选项存在不等于支持满幅 B4 打印。
- CUSTOMSIZE：最小 720×720、最大 7286×15840，约 25.4×25.4 至 257.59×558.8 mm；MaxPrintableWidth=7114；左右总扣除 172、上下各120，宽度取 min(7114,纸宽-172)。末尾注释的 SafeSizeMin=2551×1984（约90×70mm）只是注释级提示，与激活的 MinSize 不同；不能把 1英寸自定义选项视作已验证物理进纸下限。

InputBin 默认 MANUAL，另有 TRACTOR；这两个选项没有自己的 CmdSelect，因此不能据此臆造“软件切换摩擦/拖纸器”命令，实际纸路可能要用拨杆切换。GPD 明确禁止 TRACTOR 搭配前述7种标准单页，禁止 MANUAL 搭配5种连续纸及 EP_3_13x4；其余表单未列同样禁配，不能擅自扩展禁配表。

横向 LANDSCAPE_CC270 存在，但 RotateRaster/Coordinate/Font 均 FALSE，可能由 Unidrv/插件处理；原型不实现横向。PrintDirection 默认沿用打印机设置；另有 `ESC U 00` 双向、`ESC U 01` 单向。半色调列有 Auto/Supercell/6×6/8×8，原型只接收已经二值化的图像，不复制 Windows 的半色调算法。

## 5. 文档、位移和通信的证据等级

GPD 行 1025–1139：

| 项目 | 可定位证据 | 可以与不可以得出的结论 |
|---|---|---|
| 起始初始化 | CmdStartDoc 分支：`ESC @ CR ESC t 01 ESC 6 ESC R 00 ESC P ESC ( U 01 00 0A` | 包内实际定义了序列；不证明所有固件/模式下行为相同 |
| D4 | 默认 UseD4 前置 `00 00 00 1B 01 @EJL 1284.4 LF @EJL` + 5空格 + LF；NoUseD4 仅初始化 | 证明驱动存在两条前导路径；不等于实现 IEEE1284.4 会话、状态查询或 macOS USB 双向兼容 |
| 页长 | A4 `ESC ( C 02 00 70 10`，即4208；自定义按 PhysPaperLength/2 输出 | 与 1/360英寸页长一致；原型沿用此值，不能用 PBM 高度代替完整页长 |
| 页边距 | MarginPriority 两分支，DriverPriority 有额外 `ESC ( c ...` 模板，PrinterPriority 无 | 涉及 GPD 转义、顶部/底部及插件联动；原型不擅自解译整个模板，使用 PrinterPriority 路径，物理原点待校准 |
| 横向位移 | XMoveUnit=360；CmdXMoveAbsolute=`ESC $` + `%l{DestX/2}` | 原型按 GPD 默认A4 x=88输出44；与打印机内部边距基准关系尚需实机确认 |
| 纵向位移 | YMoveUnit=180；`ESC J` + DestYRel/4，SEND_CR_FIRST；ESC 3 设置行距 | 原型用 CR/ESC J 逐24行推进，开始向下30单位；未额外使用 ESC 3 |
| 页结束 | CmdFF 定义为空，但 EjectPageWithFF?=TRUE | 两项共同存在，不能只看其中之一就断言 Windows 一定发/不发0C；需 RAW作业捕获确认 |
| 文档结束 | CmdEndJob=`ESC @ CR` | 原型复用；额外0C退纸是显式实验策略，不声称精确复刻 Windows |
| 字体 | DefaultFont=124，DeviceFonts列表与资源DLL；无字体选项 | 不足以证明原生 Unicode/GB18030；原型中文须先经 PDF 字体渲染成位图 |

不能据此认定支持 ESC `.`、ESC `( G`、ESC `i` 压缩光栅、PCL、PS、PDF直打、AirPrint/IPP Everywhere。也不能仅凭 DLL 中的 EJL/D4 或协议字符串认定相关握手已还原。本次不对 OEM 插件作完整反汇编；PE 导入/导出表用于确认体系与依赖，不用于宣布命令兼容。

## 6. macOS 方案选择

1. 最有依据的短期方案：PDF/图像先渲染成单色位图 → 24针ESC `*`39 → CUPS后端/原始队列。优点是与 GPD 默认分支直接对应，中文依靠主机字体；缺点是数据量大、纸路与D4需确认。
2. 系统自带或第三方“Epson 24-pin/ESC/P”驱动可作对照，但必须检查实际输出是24针位图、模式39及正确走纸，不能用喷墨 ESC/P2 驱动的名称作为兼容证明。
3. 完整后续实现应采用 CUPS Raster/PWG Raster 解码、PPD或Printer Application的受控能力声明，处理页面/份数/取消/纸型/旋转，再编码本型号数据。不要把 GPD 改名为 PPD，也不要把 DLL 放进 CUPS filter 目录。
4. USB、并口桥接、网络打印服务器是不同传输条件。INF不提供网络协议。网络服务器若有9100原始通道，需另行确认；不能凭空给本机配置 socket URI。
5. macOS 版本尚未给出。传统 PPD/filter/raw 队列在不同版本可用性不同，且属于逐步淘汰方向；须先用本机 `sw_vers`、`lpinfo -v`、`lpinfo -m`、`lpstat -t` 检查。当前未验证任何 macOS 安装或队列建立。

## 7. 原型、测试与限制

`prototype/pbmto615.c` 是无第三方库的 C11 源码；macOS 可用 Command Line Tools 编译成本机 arm64/x86_64程序，交付的现成二进制仅用于本次 Linux 测试。程序默认不加D4前导；独立参数 `--d4` 可选用包内前导，二者均需实机对照。

只支持单页二进制PBM P4，180×180 dpi，最大1443×2044，黑位=1；每24行转为列优先三字节。窄小输入不会放大。所有输入先校验再输出，拒绝PDF、CUPS Raster、超界、截断、多页/尾部数据。默认A4页长、默认A4原点；不支持自定义纸、拖纸器控制、份数、色彩、双面、设备字体、状态查询和打印中取消。提供CUPS传统argc接口用于受控离线调用，但有options时主动拒绝；没有注册MIME或提供可假装自动PDF转换的PPD。

验证结果（本次Linux云环境）：

- `cc -std=c11 -O2 -Wall -Wextra -Werror` 成功。
- 7项单元测试全部通过；覆盖针位/列序、第二条带、末尾补零、超界/坏输入零输出、二进制空白、显式D4、CUPS不支持选项拒绝、最大面积。
- Ghostscript 10.05.1：示例PS→PDF→180dpi PBM→PRN完整运行，PRN 373,528字节。出现字体缓存目录不可写提示，但命令完成且后续像素验证通过。
- 独立解码器从PRN反解86条24针带，与PBM的 **2,949,492个有效像素逐一一致**。这验证软件编码，不验证机械输出。
- 无实机打印、USB抓包、Windows对照作业、macOS编译、CUPS队列测试或代码签名验证。未打印任何纸张。

## 8. 实机验证顺序与通过标准

先用单页废纸、正确拨杆/厚度设置，停止其他作业。先打印窄小针位图，再打印整页；异常立即取消队列并按设备面板停止，不连续重试。

1. 记录机型铭牌、固件、自检/默认设置页、当前仿真模式、自动LF/CR、跳过页缝、撕纸与边距设置；记录macOS版本、架构、USB实际枚举和连接方式。
2. 在Windows用这份112N驱动对同一校准PDF生成RAW PRN，分别选择180dpi、A4、MANUAL、无设备字体及两种MarginPriority；比较前导、ESC*39列数/针序、横纵定位、最后FF和插件增加的字节。EMF/XPS后台文件不能当设备RAW数据。
3. 同纸路分别试普通前导与D4前导，确认不打印EJL文本、不乱码、不长时间挂起；不能把仅“队列已完成”作为打印成功。
4. 验证24针顶/底位序、水平/垂直尺寸、条带接缝、斜线、中文位图及丢列。整页先比对软件缩放后的预期尺寸，不把PDF fit缩放误判成dpi错误。
5. 测量x/y原点与四边边距，确认ESC $是否相对内部左边距、ESC J初始30是否叠加打印机顶边距；再决定是否实现DriverPriority的ESC(c模板。
6. 确认0C只退一页、不跨两页、重置不改变后续作业；连续两作业无累积偏移。拖纸器另用连续纸测试页长、撕纸位、跨页、断纸，不能用单页A4结果替代。
7. 单向/双向对齐、长作业流控、断连恢复、取消、离线/缺纸、USB桥接双向状态均需独立测试。通过这些之前，不把试验队列替换为默认队列。

详细编译、安装、发送和撤销步骤见 `prototype/README.zh-CN.md`。本次未在用户Mac上进行任何系统级安装。
