/* Apple CUPS includes BSD networking declarations (u_int, u_char, etc.).
 * Request the supported full Darwin namespace before any SDK headers.
 * Strict POSIX visibility is still appropriate on Linux test hosts. */
#if defined(__APPLE__)
#define _DARWIN_C_SOURCE 1
#else
#define _POSIX_C_SOURCE 200809L
#endif
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <errno.h>
#include <unistd.h>
#include <fcntl.h>
#include <signal.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <limits.h>
#if defined(__APPLE__)
#include <cups/cups.h>
#else
/* Stable public subset of the CUPS 2.x API, for Linux test hosts without dev
 * headers. Native macOS builds use the SDK's actual cups/cups.h above.
 * Reference: apple/cups v2.3.6 cups/cups.h. */
typedef struct { char *name, *value; } cups_option_t;
extern int cupsParseOptions(const char *,int,cups_option_t **);
extern const char *cupsGetOption(const char *,int,cups_option_t *);
extern void cupsFreeOptions(int,cups_option_t *);
#endif
#ifndef LQ_PREFIX
#define LQ_PREFIX "/Library/Printers/LQ615KII-Local"
#endif
static volatile sig_atomic_t canceled=0;
static volatile sig_atomic_t active_child=0;
static char work[4096],input[4096],pbm[4096],spool[4096];
static void cleanup(void) {
 if(*input) unlink(input);
 if(*pbm) unlink(pbm);
 if(*spool) unlink(spool);
 if(*work) rmdir(work);
}
static void stop(int sig) { (void)sig; canceled=1; if(active_child>0) kill((pid_t)active_child,SIGTERM); }
static void die(const char *s) { fprintf(stderr,"ERROR: LQ615KII: %s\n",s); exit(1); }
static long integer(const char *s,long lo,long hi) {
 char *end; errno=0;
 long n=strtol(s,&end,10);
 if(errno || !*s || *end || n<lo || n>hi) die("Invalid numeric job option.");
 return n;
}
static int child(char *const av[],int in,int out) {
 if(canceled) return -1;
 pid_t p=fork(); if(p<0) die("Cannot create conversion process.");
 if(!p) {
  if(dup2(in,STDIN_FILENO)<0 || dup2(out,STDOUT_FILENO)<0) _exit(126);
  execv(av[0],av); perror("ERROR: Cannot execute installed conversion helper"); _exit(127);
 }
 active_child=p; if(canceled) kill(p,SIGTERM);
 int status=0; pid_t got;
 do { got=waitpid(p,&status,0); } while(got<0 && errno==EINTR);
 active_child=0;
 return got==p && WIFEXITED(status) && !canceled ? WEXITSTATUS(status) : -1;
}
static long count_pages(int nullfd) {
 int fds[2]; if(pipe(fds)) die("Cannot create PDF information pipe.");
 pid_t p=fork(); if(p<0) die("Cannot start PDF information reader.");
 if(!p) {
  close(fds[0]);
  if(dup2(nullfd,STDIN_FILENO)<0 || dup2(fds[1],STDOUT_FILENO)<0) _exit(126);
  close(fds[1]); execl(LQ_PREFIX "/pdf615","pdf615","count",input,(char*)NULL); _exit(127);
 }
 active_child=p; if(canceled) kill(p,SIGTERM);
 close(fds[1]); char text[64]; size_t used=0;
 while(used<sizeof(text)-1) {
  ssize_t n=read(fds[0],text+used,sizeof(text)-1-used);
  if(n<0 && errno==EINTR) continue;
  if(n<=0) break;
  used+=(size_t)n;
 }
 close(fds[0]); text[used]=0;
 int status=0; pid_t got;
 do { got=waitpid(p,&status,0); } while(got<0 && errno==EINTR);
 active_child=0;
 if(got!=p || !WIFEXITED(status) || WEXITSTATUS(status)!=0 || canceled) die("PDF information reader failed; no printer data sent.");
 while(used && (text[used-1]=='\n' || text[used-1]=='\r')) text[--used]=0;
 return integer(text,1,1000);
}
static void path(char *dest,size_t len,const char *name) {
 int n=snprintf(dest,len,"%s/%s",work,name);
 if(n<0 || (size_t)n>=len) die("Temporary path is too long.");
}
static void copy_fd(int in,int out) {
 char buf[32768];
 while(!canceled) {
  ssize_t n=read(in,buf,sizeof(buf));
  if(n<0 && errno==EINTR) continue;
  if(n<0) die("Cannot read job data.");
  if(!n) return;
  ssize_t i=0;
  while(i<n) {
   if(canceled) die("Job canceled.");
   ssize_t k=write(out,buf+i,(size_t)(n-i));
   if(k<0 && errno==EINTR) continue;
   if(k<=0) die("Cannot write job data or downstream backend closed.");
   i+=k;
  }
 }
 die("Job canceled.");
}
/* Honor installed queue defaults as well as explicit job options. */
static void option(int n,cups_option_t *opts,const char *key,const char *fallback,char *out,size_t size) {
 const char *v=cupsGetOption(key,n,opts);
 if(v) { if(strlen(v)>=size) die("Job option too long."); strcpy(out,v); return; }
 snprintf(out,size,"%s",fallback);
 const char *ppd=getenv("PPD"); if(!ppd || !*ppd) return;
 FILE *f=fopen(ppd,"r"); if(!f) die("Cannot read installed PPD defaults.");
 char prefix[128],line[512]; snprintf(prefix,sizeof(prefix),"*Default%s:",key);
 while(fgets(line,sizeof(line),f)) if(!strncmp(line,prefix,strlen(prefix))) {
  char *start=line+strlen(prefix); while(*start==' ' || *start=='\t') start++;
  size_t len=strcspn(start," \t\r\n");
  if(len==0 || len>=size) { fclose(f); die("Invalid installed PPD default."); }
  memcpy(out,start,len); out[len]=0; break;
 }
 fclose(f);
}
static void select_pages(const char *ranges,int pages,unsigned char *chosen) {
 if(!ranges || !*ranges) { memset(chosen,1,(size_t)pages); return; }
 const char *p=ranges;
 while(*p) {
  char *end; errno=0; long first=strtol(p,&end,10),last=first;
  if(errno || end==p || first<1 || first>1000000) die("Invalid page-ranges option.");
  p=end;
  if(*p=='-') {
   p++; errno=0; last=strtol(p,&end,10);
   if(errno || end==p || last<first || last>1000000) die("Invalid page range end.");
   p=end;
  }
  for(long i=first;i<=last && i<=pages;i++) chosen[i-1]=1;
  if(!*p) break;
  if(*p!=',' || !p[1]) die("Invalid page range separator.");
  p++;
 }
}
int main(int argc,char **argv) {
 if(argc!=6 && argc!=7) die("Usage: job-id user title copies options [file]");
 umask(077); atexit(cleanup);
 struct sigaction sa; memset(&sa,0,sizeof(sa)); sa.sa_handler=stop; sigemptyset(&sa.sa_mask);
 sigaction(SIGTERM,&sa,NULL); sigaction(SIGINT,&sa,NULL); signal(SIGPIPE,SIG_IGN);
 if(integer(argv[4],1,999)!=1) die("This initial system queue supports one copy per job. Submit another job for more copies.");
 int n=0; cups_option_t *opts=NULL; n=cupsParseOptions(argv[5],0,&opts);
 char scale[32],ink[32],x[32],y[32],paper[64];
 option(n,opts,"PageSize","LQ241x140",paper,sizeof(paper));
 if(strcmp(paper,"LQ241x140")) die("Select the LQ 241 x 140 mm paper size.");
 option(n,opts,"LQScale","S90",scale,sizeof(scale));
 const char *percent=!strcmp(scale,"S90")?"90":!strcmp(scale,"S85")?"85":NULL;
 if(!percent) die("Unsupported driver scale; select 90 or 85 percent.");
 option(n,opts,"LQInk","Standard",ink,sizeof(ink));
 const char *threshold=!strcmp(ink,"Standard")?"128":!strcmp(ink,"Dark")?"192":NULL;
 if(!threshold) die("Unsupported monochrome setting.");
 option(n,opts,"LQX","0",x,sizeof(x)); option(n,opts,"LQY","0",y,sizeof(y));
 integer(x,-10,10); integer(y,0,10);
 const char *sides=cupsGetOption("sides",n,opts);
 if(sides && strcmp(sides,"one-sided")) die("This printer queue supports one-sided printing only.");
 const char *numberup=cupsGetOption("number-up",n,opts);
 if(numberup && strcmp(numberup,"1")) die("Use one document page per sheet.");
 const char *pageSet=cupsGetOption("page-set",n,opts);
 if(pageSet && strcmp(pageSet,"all")) die("Odd/even page sets are not implemented; use explicit page ranges.");
 const char *order=cupsGetOption("outputorder",n,opts);
 if(order && strcasecmp(order,"normal")) die("Reverse order is not implemented in this initial filter.");
 const char *tmp=getenv("TMPDIR"); if(!tmp || !*tmp) tmp="/tmp";
 int len=snprintf(work,sizeof(work),"%s/lq615-job-XXXXXX",tmp);
 if(len<0 || (size_t)len>=sizeof(work) || !mkdtemp(work)) { work[0]=0; die("Cannot create private spool directory."); }
 path(input,sizeof(input),"input.pdf"); path(pbm,sizeof(pbm),"page.pbm"); path(spool,sizeof(spool),"job.prn");
 int src=argc==7?open(argv[6],O_RDONLY):STDIN_FILENO;
 if(src<0) die("Cannot open input job.");
 int fd=open(input,O_CREAT|O_EXCL|O_WRONLY,0600); if(fd<0) die("Cannot create private input file.");
 copy_fd(src,fd); close(fd); if(src!=STDIN_FILENO) close(src);
 fd=open(input,O_RDONLY); char signature[5];
 ssize_t got=fd<0?-1:read(fd,signature,5); if(fd>=0) close(fd);
 if(got!=5 || memcmp(signature,"%PDF-",5)) die("Expected PDF input. No printer data sent.");
 int nullfd=open("/dev/null",O_RDWR); if(nullfd<0) die("Cannot open null device.");
 int pages=(int)count_pages(nullfd); unsigned char *chosen=calloc((size_t)pages,1);
 if(!chosen) die("Out of memory.");
 select_pages(cupsGetOption("page-ranges",n,opts),pages,chosen);
 int count=0; for(int p=0;p<pages;p++) if(chosen[p]) count++;
 if(!count) die("Selected range contains no pages.");
 int out=open(spool,O_CREAT|O_EXCL|O_WRONLY,0600); if(out<0) die("Cannot create converted spool.");
 off_t *ends=calloc((size_t)pages,sizeof(*ends)); if(!ends) die("Out of memory.");
 /* Render every selected page before emitting any bytes. The backend never
  * receives a half-converted job when a later page fails validation. */
 for(int p=0;p<pages;p++) if(chosen[p]) {
  char page[32]; snprintf(page,sizeof(page),"%d",p+1);
  fprintf(stderr,"INFO: LQ615KII preparing page %d (%s%%, top-aligned).\n",p+1,percent);
  char *render[]={LQ_PREFIX "/pdf615","render",input,page,pbm,"-",(char*)percent,(char*)threshold,"ink-center",x,y,NULL};
  if(child(render,nullfd,nullfd)) die("PDF conversion failed; no printer data sent. See preceding error.");
  int bits=open(pbm,O_RDONLY); if(bits<0) die("Converter did not produce page data.");
  char *encode[]={LQ_PREFIX "/pbmto615","--d4","--paper=241x140-original",NULL};
  int status=child(encode,bits,out); close(bits); unlink(pbm);
  if(status) die("ESC/P encoding failed; no printer data sent.");
  ends[p]=lseek(out,0,SEEK_CUR); if(ends[p]<0) die("Cannot measure output spool.");
 }
 close(out); if(canceled) die("Job canceled before sending.");
 fd=open(spool,O_RDONLY); if(fd<0) die("Cannot read converted spool.");
 char buffer[32768]; off_t pos=0;
 for(int p=0;p<pages;p++) if(chosen[p]) {
  fprintf(stderr,"PAGE: %d 1\n",p+1);
  while(pos<ends[p]) {
   if(canceled) die("Job canceled during sending.");
   size_t want=ends[p]-pos>(off_t)sizeof(buffer)?sizeof(buffer):(size_t)(ends[p]-pos);
   ssize_t k=read(fd,buffer,want);
   if(k<0 && errno==EINTR) continue;
   if(k<=0) die("Cannot read converted page.");
   ssize_t j=0;
   while(j<k) {
    if(canceled) die("Job canceled during sending.");
    ssize_t wrote=write(STDOUT_FILENO,buffer+j,(size_t)(k-j));
    if(wrote<0 && errno==EINTR) { if(canceled) die("Job canceled."); continue; }
    if(wrote<=0) die("Backend closed output; printing stopped.");
    j+=wrote;
   }
   pos+=k;
  }
 }
 close(fd); close(nullfd); free(ends); free(chosen); cupsFreeOptions(n,opts);
 fprintf(stderr,"INFO: LQ615KII sent %d converted page(s) to the CUPS backend.\n",count);
 return canceled?1:0;
}
