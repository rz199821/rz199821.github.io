#if defined(__APPLE__)
#define _DARWIN_C_SOURCE 1
#include <cups/cups.h>
#else
#define _POSIX_C_SOURCE 200809L
#include <sys/socket.h>
typedef struct http_s http_t;
typedef struct ipp_s ipp_t;
typedef struct ipp_attribute_s ipp_attribute_t;
typedef int ipp_tag_t;
typedef int http_encryption_t;
#define HTTP_ENCRYPTION_IF_REQUESTED 0
#define IPP_OP_GET_PRINTER_ATTRIBUTES 0x000b
#define IPP_OP_VALIDATE_JOB 0x0004
#define IPP_TAG_ZERO 0
#define IPP_TAG_OPERATION 1
#define IPP_TAG_JOB 2
#define IPP_TAG_INTEGER 0x21
#define IPP_TAG_COLLECTION 0x34
#define IPP_TAG_CHARSET 0x47
#define IPP_TAG_LANGUAGE 0x48
#define IPP_TAG_URI 0x45
#define IPP_TAG_NAME 0x42
#define IPP_TAG_MIMETYPE 0x49
#define IPP_TAG_KEYWORD 0x44
extern http_t *httpConnect2(const char*,int,void*,int,http_encryption_t,int,int,int*);
extern void httpClose(http_t*);
extern ipp_t *ippNewRequest(int);
extern void ippDelete(ipp_t*);
extern ipp_t *ippNew(void);
extern ipp_attribute_t *ippAddString(ipp_t*,ipp_tag_t,ipp_tag_t,const char*,const char*,const char*);
extern ipp_attribute_t *ippAddBoolean(ipp_t*,ipp_tag_t,const char*,int);
extern ipp_attribute_t *ippAddInteger(ipp_t*,ipp_tag_t,ipp_tag_t,const char*,int);
extern ipp_attribute_t *ippAddCollection(ipp_t*,ipp_tag_t,const char*,ipp_t*);
extern ipp_attribute_t *ippFindAttribute(ipp_t*,const char*,ipp_tag_t);
extern int ippGetStatusCode(ipp_t*);
extern int ippGetBoolean(ipp_attribute_t*,int);
extern int ippGetCount(ipp_attribute_t*);
extern const char *ippGetString(ipp_attribute_t*,int,const char**);
extern ipp_t *cupsDoRequest(http_t*,ipp_t*,const char*);
extern const char *cupsLastErrorString(void);
extern void cupsSetPasswordCB2(const char *(*)(const char*,http_t*,const char*,const char*,void*),void*);
#endif
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <errno.h>
#define RESOURCE "/printers/LQ615KII_Local241"
static const char *no_password(const char *prompt,http_t *http,const char *method,const char *resource,void *data) {
 (void)prompt;(void)http;(void)method;(void)resource;(void)data;return NULL;
}
static int has_string(ipp_t *r,const char *name,const char *value) {
 ipp_attribute_t *a=ippFindAttribute(r,name,IPP_TAG_ZERO);
 if(!a) return 0;
 for(int i=0;i<ippGetCount(a);i++) { const char *v=ippGetString(a,i,NULL); if(v && !strcmp(v,value)) return 1; }
 return 0;
}
static int successful(ipp_t *r) { return r && ippGetStatusCode(r)<0x0100; }
static ipp_t *request(int op,const char *uri) {
 ipp_t *q=ippNewRequest(op);
 ippAddString(q,IPP_TAG_OPERATION,IPP_TAG_URI,"printer-uri",NULL,uri);
 ippAddString(q,IPP_TAG_OPERATION,IPP_TAG_NAME,"requesting-user-name",NULL,"LQ615-AirPrint-Probe");
 return q;
}
int main(int argc,char **argv) {
 int uuid_only=argc>1 && !strcmp(argv[1],"--uuid");
 if(uuid_only) { argc--; argv++; }
 if(argc<2 || argc>3) { fprintf(stderr,"Usage: probe hostname [port]\n"); return 1; }
 for(const unsigned char *p=(unsigned char*)argv[1];*p;p++) if(!isalnum(*p) && *p!='.' && *p!='-') { fprintf(stderr,"Invalid hostname\n");return 1; }
 int port=631;
 if(argc==3) { char *e;errno=0;long n=strtol(argv[2],&e,10); if(errno || !*argv[2] || *e || n<1 || n>65535) return 1;port=(int)n; }
 char uri[1024];int n=snprintf(uri,sizeof(uri),"ipp://%s:%d" RESOURCE,argv[1],port);
 if(n<0 || (size_t)n>=sizeof(uri)) return 1;
 cupsSetPasswordCB2(no_password,NULL);
 http_t *http=httpConnect2(argv[1],port,NULL,AF_UNSPEC,HTTP_ENCRYPTION_IF_REQUESTED,1,4000,NULL);
 if(!http) { fprintf(stderr,"FAIL: cannot reach shared CUPS endpoint: %s\n",cupsLastErrorString()); return 2; }
 ipp_t *r=cupsDoRequest(http,request(IPP_OP_GET_PRINTER_ATTRIBUTES,uri),RESOURCE);
 if(!successful(r)) { fprintf(stderr,"FAIL: queue query denied or unavailable: %s\n",cupsLastErrorString());if(r)ippDelete(r);httpClose(http);return 3; }
 ipp_attribute_t *a=ippFindAttribute(r,"printer-is-shared",IPP_TAG_ZERO);
 if(!a || !ippGetBoolean(a,0)) { fprintf(stderr,"FAIL: target queue is not shared. Enable only this queue in macOS Printer Sharing.\n");ippDelete(r);httpClose(http);return 4; }
 if(!has_string(r,"document-format-supported","application/pdf")) { fprintf(stderr,"FAIL: queue does not advertise PDF support.\n");ippDelete(r);httpClose(http);return 5; }
 // Check HTTP/IPP URI authentication separately from backend credentials.
 if(!has_string(r,"uri-authentication-supported","none") &&
    !has_string(r,"uri-authentication-supported","requesting-user-name")) {
  fprintf(stderr,"FAIL: URI authentication is not anonymous/user-name-only; review trusted-LAN sharing.\n");
  ippDelete(r);httpClose(http);return 6;
 }
 // Do not advertise an unauthenticated Bonjour endpoint for a queue that says
 // it requires credentials. Probe never asks for or stores a password.
 a=ippFindAttribute(r,"auth-info-required",IPP_TAG_ZERO);
 if(a && !has_string(r,"auth-info-required","none")) { fprintf(stderr,"FAIL: queue requires authentication; review sharing access for the trusted LAN.\n");ippDelete(r);httpClose(http);return 6; }
 char uuid[64]="";
 a=ippFindAttribute(r,"printer-uuid",IPP_TAG_ZERO);
 const char *value=a?ippGetString(a,0,NULL):NULL;
 if(value && !strncmp(value,"urn:uuid:",9) && strlen(value+9)==36) {
  int valid=1;
  for(const char *p=value+9;*p;p++) if(!isxdigit((unsigned char)*p) && *p!='-') valid=0;
  if(valid) snprintf(uuid,sizeof(uuid),"%s",value+9);
 }
 ippDelete(r);
 ipp_t *q=request(IPP_OP_VALIDATE_JOB,uri);
 ippAddString(q,IPP_TAG_OPERATION,IPP_TAG_MIMETYPE,"document-format",NULL,"application/pdf");
 ippAddBoolean(q,IPP_TAG_OPERATION,"ipp-attribute-fidelity",1);
 ippAddInteger(q,IPP_TAG_JOB,IPP_TAG_INTEGER,"copies",1);
 ippAddString(q,IPP_TAG_JOB,IPP_TAG_KEYWORD,"sides",NULL,"one-sided");
 ipp_t *media=ippNew(),*size=ippNew();
 ippAddInteger(size,IPP_TAG_ZERO,IPP_TAG_INTEGER,"x-dimension",24100);
 ippAddInteger(size,IPP_TAG_ZERO,IPP_TAG_INTEGER,"y-dimension",14000);
 ippAddCollection(media,IPP_TAG_ZERO,"media-size",size);
 ippAddCollection(q,IPP_TAG_JOB,"media-col",media);
 ippDelete(size);ippDelete(media);
 r=cupsDoRequest(http,q,RESOURCE);
 if(!r || ippGetStatusCode(r)!=0) { fprintf(stderr,"FAIL: PDF/241x140mm Validate-Job rejected or substituted: %s\n",cupsLastErrorString());if(r)ippDelete(r);httpClose(http);return 7; }
 ippDelete(r);httpClose(http);
 if(uuid_only) { if(!*uuid) { fprintf(stderr,"FAIL: queue UUID unavailable.\n");return 8; } puts(uuid);return 0; }
 printf("PASS: shared PDF queue reachable; Validate-Job accepted 241x140mm, one copy, simplex. No job created or document sent.\n");
 return 0;
}
