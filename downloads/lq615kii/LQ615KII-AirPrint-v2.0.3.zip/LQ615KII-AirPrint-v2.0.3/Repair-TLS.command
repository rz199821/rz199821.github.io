#!/bin/bash
# Repair only the marked user AirPrint v2 receiver, not macOS CUPS or USB drivers.
set -euo pipefail
umask 077
prefix="$HOME/Library/Application Support/LQ615KII-AirPrint-v2"
agent="$HOME/Library/LaunchAgents/local.lq615kii.airprint.v2.plist"
logs="$HOME/Library/Logs/LQ615KII-AirPrint-v2"
fail() { printf '\nHTTPS修复未完成：%s\n' "$*" >&2; exit 1; }
[ "$(uname -s)" = Darwin ] || fail '请在已安装手机接收服务的Mac上运行。'
[ -f "$prefix/OWNER" ] && [ "$(cat "$prefix/OWNER")" = local.lq615kii.airprint.v2 ] || fail '未找到本工具的v2安装标记。'
[ -f "$agent" ] && [ "$(/usr/bin/plutil -extract Label raw -o - "$agent")" = local.lq615kii.airprint.v2 ] || fail '后台配置不匹配。'
xcrun --find clang >/dev/null 2>&1 || fail '找不到已安装的Apple命令行工具。'
src=''
# Reuse the already-configured native build. No GitHub downloads are needed.
for folder in "$HOME"/Downloads/LQ615KII-AirPrint-v2*; do
 candidate="$folder/.build/cups-2.4.16"
 [ -f "$candidate/cups/tls-darwin.c" ] && [ -f "$candidate/config.h" ] || continue
 /usr/bin/grep -q '^#define HAVE_CDSASSL 1' "$candidate/config.h" || continue
 sha="$(/usr/bin/shasum -a 256 "$candidate/cups/tls-darwin.c" | /usr/bin/awk '{print $1}')"
 case "$sha" in
 acd0d6367316bea78ba13e916d1a5b80453a93e395e906bd77b20daf8510bf24|d4c5f6d3e2f2c8432878186ff9025b8c0fc016e8a16761d1a3e1f7725c3b87f2) src="$candidate";break;;
 esac
done
[ -n "$src" ] || fail '没有找到已确认版本的本机源码缓存；请保留原安装文件夹和.build目录。'
mkdir -p "$logs"
if [ "$sha" = acd0d6367316bea78ba13e916d1a5b80453a93e395e906bd77b20daf8510bf24 ]; then
 /bin/cp -n "$src/cups/tls-darwin.c" "$src/cups/tls-darwin.c.before-lq615-lock-fix"
 /usr/bin/perl -0pi -e 's{(static CFArrayRef[^\n]*\nhttp_cdsa_copy_server\([\s\S]*?\n\}\n)}{my $body=$1; $body =~ s/^  _cupsMutexLock\(&tls_mutex\);/  \/* Caller holds tls_mutex for credential lookup and creation. *\//m or die "Lock not found\n"; $body =~ s/^  _cupsMutexUnlock\(&tls_mutex\);\n//m or die "Unlock not found\n"; $body}e or die "Function not found\n";' "$src/cups/tls-darwin.c"
fi
[ "$(/usr/bin/shasum -a 256 "$src/cups/tls-darwin.c" | /usr/bin/awk '{print $1}')" = d4c5f6d3e2f2c8432878186ff9025b8c0fc016e8a16761d1a3e1f7725c3b87f2 ] || fail '修补后源码校验不匹配，未替换服务。'
printf '正在重新链接HTTPS接收服务（复用已编译源码）…\n'
(
 /usr/bin/make -C "$src/cups" -j2 libcups.a || exit 1
 /usr/bin/make -C "$src/tools" -j2 ippeveprinter-static ipptool-static || exit 1
) > "$logs/repair-build.log" 2>&1 || { /usr/bin/tail -n 20 "$logs/repair-build.log"; fail '编译失败，原接收程序保留。'; }
work="$(/usr/bin/mktemp -d "${TMPDIR:-/tmp}/lq615-tls.XXXXXXXX")"
server_pid=''
changed=0
committed=0
cleanup() {
 if [ -n "$server_pid" ]; then kill "$server_pid" 2>/dev/null || true; wait "$server_pid" 2>/dev/null || true; fi
 if [ "$changed" = 1 ] && [ "$committed" = 0 ]; then
  /bin/launchctl bootout "gui/$(id -u)/local.lq615kii.airprint.v2" 2>/dev/null || true
  /bin/cp "$work/old-server" "$prefix/ippeveprinter"
  /bin/cp "$work/old-client" "$prefix/ipptool"
  /bin/launchctl bootstrap "gui/$(id -u)" "$agent" 2>/dev/null || true
  printf '新版检查失败，已尝试恢复更新前的接收程序。\n' >&2
 fi
 /bin/rm -f "$prefix/ippeveprinter.next" "$prefix/ipptool.next"
 /bin/rm -rf "$work"
}
trap cleanup EXIT
trap 'exit 1' HUP INT TERM
/usr/bin/install -m 755 "$src/tools/ippeveprinter-static" "$work/ippeveprinter"
/usr/bin/install -m 755 "$src/tools/ipptool-static" "$work/ipptool"
for name in ippeveprinter ipptool; do
 /usr/bin/codesign --force --sign - --timestamp=none --identifier "local.lq615kii.airprint.$name" "$work/$name"
 /usr/bin/codesign --verify --strict "$work/$name"
done
mkdir -p "$work/spool"
printf '检查真实HTTPS握手和加密IPP（不创建打印任务）…\n'
"$work/ippeveprinter" --no-web-forms -r off -n localhost -p 18639 \
 -a "$prefix/printer.conf" -d "$work/spool" -c /usr/bin/false \
 'LQ615KII HTTPS repair check' > "$logs/repair-server-check.log" 2>&1 &
server_pid=$!
ready=0
for attempt in 1 2 3 4 5; do
 /bin/sleep 1
 kill -0 "$server_pid" 2>/dev/null || break
 if "$work/ipptool" -T 5 -t ipp://localhost:18639/ipp/print "$prefix/check-receiver.test" > "$logs/repair-http-check.log" 2>&1; then ready=1;break;fi
done
[ "$ready" = 1 ] || fail "候选服务未启动；查看 $logs/repair-server-check.log"
if ! "$work/ipptool" -T 20 -t ipps://localhost:18639/ipp/print "$prefix/check-receiver.test" > "$logs/repair-https-check.log" 2>&1; then
 /usr/bin/tail -n 20 "$logs/repair-https-check.log" "$logs/repair-server-check.log"
 fail 'HTTPS检查未通过，尚未替换现有服务。请发来上面的记录。'
fi
kill "$server_pid" 2>/dev/null || true
wait "$server_pid" 2>/dev/null || true
server_pid=''
/bin/cp "$prefix/ippeveprinter" "$work/old-server"
/bin/cp "$prefix/ipptool" "$work/old-client"
/usr/bin/install -m 755 "$work/ippeveprinter" "$prefix/ippeveprinter.next"
/usr/bin/install -m 755 "$work/ipptool" "$prefix/ipptool.next"
printf 'HTTPS自检通过，更新本工具的后台接收程序…\n'
changed=1
/bin/launchctl bootout "gui/$(id -u)/local.lq615kii.airprint.v2"
/bin/mv -f "$prefix/ippeveprinter.next" "$prefix/ippeveprinter"
/bin/mv -f "$prefix/ipptool.next" "$prefix/ipptool"
/bin/launchctl bootstrap "gui/$(id -u)" "$agent"
localname="$(/usr/sbin/scutil --get LocalHostName)"
ready=0
for attempt in 1 2 3; do
 /bin/sleep 1
 if "$prefix/ipptool" -T 20 -t "ipps://$localname.local.:8631/ipp/print" "$prefix/check-receiver.test" > "$logs/repair-installed-https.log" 2>&1; then ready=1;break;fi
done
[ "$ready" = 1 ] || { /usr/bin/tail -n 20 "$logs/repair-installed-https.log"; fail '已安装服务HTTPS检查失败。'; }
committed=1
printf '\nHTTPS接收服务已修复并通过加密IPP自检。没有发送打印任务。\n'
printf '请关闭iPhone打印面板后重新进入，选择 LQ615KII iPhone v2。先确认241×140mm，测试1页1份。\n'
