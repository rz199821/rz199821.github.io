#!/usr/bin/env python3
"""Exercise the kit orchestration with stub modules/system tools, no installation.
Only this test copy rewrites absolute tool/installation paths into temp files.
"""
from pathlib import Path
import tempfile, subprocess, os, shlex
root=Path(__file__).resolve().parents[1]
original=(root/'Install.command').read_text()
cases=['fresh','driver_exists','both_exist','both_exist_no_tools','unknown_driver','driver_failure','bridge_failure','missing_tools']
for scenario in cases:
 with tempfile.TemporaryDirectory(prefix='lq615 kit test ') as td:
  d=Path(td);kit=d/'kit with spaces';kit.mkdir();(kit/'driver').mkdir();(kit/'bridge').mkdir();cmds=d/'bin';cmds.mkdir();log=d/'calls'
  existing=scenario in ['driver_exists','both_exist','both_exist_no_tools','unknown_driver']
  for name,body in [('uname','echo Darwin'),('xcrun','exit '+('1' if scenario in ['missing_tools','both_exist_no_tools'] else '0')),('lpstat','exit '+('0' if existing else '1')),('codesign','exit 0'),('plutil','echo local.lq615kii.airprint.v2')]:
   f=cmds/name;f.write_text('#!/bin/bash\n'+body+'\n');f.chmod(0o755)
  driver=d/'installed driver';bridge=d/'installed bridge';agent=d/'agent.plist'
  if existing:
   driver.mkdir();(driver/'OWNER').write_text(('unknown' if scenario=='unknown_driver' else 'local.lq615kii.systemqueue.v1')+'\n')
   for name in ['pdf615','pbmto615','lq615filter']:
    (driver/name).write_text('');(driver/name).chmod(0o755)
  if scenario in ['both_exist','both_exist_no_tools']:
   bridge.mkdir();(bridge/'OWNER').write_text('local.lq615kii.airprint.v2\n');agent.write_text('stub')
  for rel,tag,fail in [('driver/Install.command','driver',scenario=='driver_failure'),('bridge/Install-AirPrint.command','bridge',scenario=='bridge_failure'),('bridge/Check-AirPrint.command','check',False)]:
   f=kit/rel;f.write_text('#!/bin/bash\nprintf "'+tag+'\\n" >> "'+str(log)+'"\nexit '+('1' if fail else '0')+'\n')
  code=original.replace("driver='/Library/Printers/LQ615KII-Local'",'driver='+shlex.quote(str(driver))).replace('bridge="$HOME/Library/Application Support/LQ615KII-AirPrint-v2"','bridge='+shlex.quote(str(bridge))).replace('agent="$HOME/Library/LaunchAgents/local.lq615kii.airprint.v2.plist"','agent='+shlex.quote(str(agent)))
  for name in ['lpstat','codesign','plutil']:code=code.replace('/usr/bin/'+name,shlex.quote(str(cmds/name)))
  (kit/'Install.command').write_text(code)
  result=subprocess.run(['bash',str(kit/'Install.command')],env=dict(os.environ,PATH=str(cmds)+':/usr/bin:/bin'),capture_output=True,text=True)
  expected={'fresh':['driver','bridge'],'driver_exists':['bridge'],'both_exist':['check'],'both_exist_no_tools':['check'],'unknown_driver':[],'driver_failure':['driver'],'bridge_failure':['driver','bridge'],'missing_tools':[]}[scenario]
  calls=log.read_text().splitlines() if log.exists() else []
  assert calls==expected,(scenario,calls,result.stdout,result.stderr)
  assert (result.returncode==0)==(scenario in ['fresh','driver_exists','both_exist','both_exist_no_tools']),(scenario,result.returncode,result.stderr)
  print('PASS',scenario)
print('8 orchestration scenarios passed; no driver or service installed.')
