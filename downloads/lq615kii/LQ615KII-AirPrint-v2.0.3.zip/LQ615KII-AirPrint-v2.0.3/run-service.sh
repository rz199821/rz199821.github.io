#!/bin/bash
set -euo pipefail
umask 077
export PATH=/usr/bin:/bin:/usr/sbin:/sbin
base="$(cd "$(dirname "$0")" && pwd)"
mkdir -p "$base/spool" "$HOME/.cups"
# 128 MiB per file; jobs are never retained with the upstream -k option.
ulimit -f 262144
exec "$base/ippeveprinter" --no-web-forms -p 8631 -r _universal \
 -a "$base/printer.conf" -d "$base/spool" -c "$base/spool-job.sh" \
 -v 'LQ615KII iPhone v2'
