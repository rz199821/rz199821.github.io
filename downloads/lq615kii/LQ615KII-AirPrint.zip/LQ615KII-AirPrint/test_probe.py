"""Actual libcups client against a loopback IPP fixture; creates no print job."""
from pathlib import Path
import tempfile,subprocess,http.server,threading,struct,unittest
ROOT=Path(__file__).parent
RESOURCE='/printers/LQ615KII_Local241'
def attr(tag,name,value):
 name=name.encode();value=value.encode() if isinstance(value,str) else value
 return bytes([tag])+struct.pack('!H',len(name))+name+struct.pack('!H',len(value))+value
class ProbeTest(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.tmp=tempfile.TemporaryDirectory();cls.exe=Path(cls.tmp.name)/'probe'
  subprocess.run(['cc','-O2','-Wall','-Wextra','-Werror','-std=c11',str(ROOT/'probe.c'),'-l:libcups.so.2','-o',str(cls.exe)],check=True)
 @classmethod
 def tearDownClass(cls):cls.tmp.cleanup()
 def exercise(self,shared=True,pdf=True,auth=False,validate=0,uuid=False,http_auth=False):
  seen=[]
  class Handler(http.server.BaseHTTPRequestHandler):
   protocol_version='HTTP/1.1'
   def do_POST(self):
    body=self.rfile.read(int(self.headers['Content-Length']));op=int.from_bytes(body[2:4],'big');seen.append((op,self.path,body))
    status=0
    extra=b''
    if op==11:
     extra=b'\x04'+attr(0x22,'printer-is-shared',bytes([int(shared)]))+attr(0x49,'document-format-supported','application/pdf' if pdf else 'image/jpeg')+attr(0x44,'uri-authentication-supported','basic' if http_auth else 'none')+attr(0x45,'printer-uuid','urn:uuid:11111111-2222-3333-4444-555555555555')+attr(0x44,'auth-info-required','username,password' if auth else 'none')
    elif op==4:status=validate
    else:status=0x0501
    data=body[:2]+struct.pack('!H',status)+body[4:8]+b'\x01'+attr(0x47,'attributes-charset','utf-8')+attr(0x48,'attributes-natural-language','en')+extra+b'\x03'
    self.send_response(200);self.send_header('Content-Type','application/ipp');self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)
   def log_message(self,*args):pass
  server=http.server.ThreadingHTTPServer(('127.0.0.1',0),Handler)
  thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
  try:p=subprocess.run([str(self.exe)]+(['--uuid'] if uuid else [])+['127.0.0.1',str(server.server_port)],capture_output=True,timeout=10)
  finally:server.shutdown();server.server_close();thread.join()
  return p,seen
 def test_success_is_readonly_and_validates_real_media(self):
  p,seen=self.exercise();self.assertEqual(p.returncode,0,p.stderr)
  self.assertEqual([x[0] for x in seen],[11,4]);self.assertTrue(all(x[1]==RESOURCE for x in seen))
  self.assertIn(b'application/pdf',seen[1][2]);self.assertIn(b'x-dimension',seen[1][2]);self.assertIn(struct.pack('!I',24100),seen[1][2]);self.assertIn(struct.pack('!I',14000),seen[1][2]);self.assertIn(b'ipp-attribute-fidelity',seen[1][2]);self.assertNotIn(b'%PDF-',seen[1][2])
 def test_uuid_matches_the_underlying_queue(self):
  p,seen=self.exercise(uuid=True);self.assertEqual(p.returncode,0,p.stderr)
  self.assertEqual(p.stdout.strip(),b'11111111-2222-3333-4444-555555555555');self.assertEqual([x[0] for x in seen],[11,4])
 def test_not_shared_stops(self):
  p,seen=self.exercise(shared=False);self.assertEqual(p.returncode,4);self.assertEqual(len(seen),1)
 def test_non_pdf_queue_stops(self):
  p,seen=self.exercise(pdf=False);self.assertEqual(p.returncode,5);self.assertEqual(len(seen),1)
 def test_authentication_not_silently_advertised(self):
  p,seen=self.exercise(auth=True);self.assertEqual(p.returncode,6);self.assertEqual(len(seen),1)
 def test_unsupported_media_stops(self):
  p,seen=self.exercise(validate=0x040b);self.assertEqual(p.returncode,7)
 def test_http_authentication_not_assumed_anonymous(self):
  p,seen=self.exercise(http_auth=True);self.assertEqual(p.returncode,6);self.assertEqual(len(seen),1)
 def test_media_substitution_stops(self):
  p,seen=self.exercise(validate=1);self.assertEqual(p.returncode,7)
if __name__=='__main__':unittest.main(verbosity=2)
