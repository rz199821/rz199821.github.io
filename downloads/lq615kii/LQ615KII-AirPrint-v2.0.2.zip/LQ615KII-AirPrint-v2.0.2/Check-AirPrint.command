#!/bin/bash
set -euo pipefail
prefix="$HOME/Library/Application Support/LQ615KII-AirPrint-v2"
[ -f "$prefix/OWNER" ] && [ "$(cat "$prefix/OWNER")" = local.lq615kii.airprint.v2 ] || { echo '没有找到本包安装记录。'; exit 1; }
printf 'Mac版本和USB队列：\n'
/usr/bin/sw_vers
/usr/bin/lpstat -h localhost:631 -p LQ615KII_Local241
printf '\n接收服务自检（只查询，不打印）：\n'
"$prefix/ipptool" -T 5 -t ipp://localhost:8631/ipp/print "$prefix/check-receiver.test"
printf '\n后台服务：\n'
/bin/launchctl print "gui/$(id -u)/local.lq615kii.airprint.v2" | /usr/bin/awk 'NR<=28 {print}'
printf '\n最近记录（可能包含文件名和局域网地址）：\n'
/usr/bin/tail -n 35 "$HOME/Library/Logs/LQ615KII-AirPrint-v2/error.log"
