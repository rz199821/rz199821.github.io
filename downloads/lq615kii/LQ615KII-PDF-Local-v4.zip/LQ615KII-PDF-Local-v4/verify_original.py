"""Independent ESC *39 decoder for this kit's original-size output.
Usage: python3 verify_original.py input.pbm output.prn
Only reads local files. Prints no PDF content.
"""
import sys
from pathlib import Path
p=Path(sys.argv[1]).read_bytes()
# Fixture parser supports Ghostscript and PDF615 header forms.
lines=p.split(b'\n'); i=1
assert lines[0]==b'P4'
while lines[i].startswith(b'#'): i+=1
w,h=map(int,lines[i].split()); body=b'\n'.join(lines[i+1:]); stride=(w+7)//8
assert len(body)==stride*h
last=max(y for y in range(h) if any(body[y*stride+x//8]&(128>>(x%8)) for x in range(w)))+1
wire=Path(sys.argv[2]).read_bytes()
marker=bytes([13,27,36,0,0,27,42,39,w&255,w>>8]); pos=wire.index(marker)
assert wire.startswith(b'\0\0\0\x1b\x01@EJL')
assert bytes([27,40,67,2,0,192,7]) in wire
for y in range(0,last,24):
 assert wire[pos:pos+10]==marker; pos+=10
 data=wire[pos:pos+w*3]; pos+=w*3
 for x in range(w):
  for k in range(24):
   expected=bool(body[(y+k)*stride+x//8]&(128>>(x%8))) if y+k<last else False
   assert bool(data[x*3+k//8]&(128>>(k%8)))==expected
 if y+24<last: assert wire[pos:pos+4]==bytes([13,27,74,24]); pos+=4
assert wire[pos:]==bytes([12,27,64,13])
print(f'PASS all {w*h} pixels; trailing whitespace omitted without moving marked content; source {w}x{h}')
