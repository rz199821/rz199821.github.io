# Mac系统打印驱动

普通安装请使用整合包最外层Install.command。这里保留独立安装、检查和卸载工具，以及源代码和通用校准PDF。

本项目独立队列：LQ615KII_Local241，系统显示名LQ-615KII 241x140 Local PDF。驱动目录为/Library/Printers/LQ615KII-Local。安装需要管理员授权，但不改变默认打印机，不自动打印。新Mac通过实际USB查询识别LQ-615KII，不复制原电脑设备序列号。

默认241×140mm手动单张、90%等比、墨迹左右居中、顶部对齐、标准较细阈值128、位置0,0。Mac应用缩放保持100%。PPD打印机功能选项仍保留比例、字重和位置微调。

该驱动已由用户在macOS26.3.1/Apple Silicon与macOS15.7.9/Intel上确认本机打印成功；同一驱动与桥接在macOS12.2.1/Intel上已确认手机实际打印成功。需要仍支持PPD/CUPS滤镜的系统与Apple命令行工具（Swift/Clang/SDK）；其他系统未逐一验证，不保证所有新旧macOS兼容。

独立Install.command需要USB连接；Install-Offline.command仅供已有自己确认过的实际URI时使用，不可猜测设备地址。正常新安装请用最外层入口。

Check.command为只读检查，不打印；Uninstall.command只移除带本项目安装标记的队列与驱动，并核对队列仍使用本项目滤镜。彻底卸载前请先移除手机桥接。

打印数据沿用已确认的D4前导及24针ESC *39、180×180dpi编码。PDFKit渲染嵌入字体，完整转换后由系统USB后端发送。原有的Darwin头文件和PPD安装顺序修复均已包含，不需手工Perl补丁。

Linux队列入口测试记录见TEST-RESULTS.txt与test_queue_filter.py；普通安装不需要运行测试脚本，也不需要Python/Ghostscript。本包不是Epson官方驱动。
