#!/bin/bash
set -u
cd "$(dirname "$0")"
service_pid=''
cleanup() {
 if [ -n "$service_pid" ]; then kill "$service_pid" 2>/dev/null || true; wait "$service_pid" 2>/dev/null || true; service_pid=''; fi
}
trap 'cleanup; exit 0' INT TERM
trap cleanup EXIT
# Inspect normal LAN interfaces only; this does not change routes or firewall.
lan_address() {
 local interface ip first
 first="$(/sbin/route -n get default 2>/dev/null | /usr/bin/awk '/interface:/ {print $2;exit}')"
 for interface in "$first" $(/sbin/ifconfig -l); do
  case "$interface" in en*) ;; *) continue;; esac
  ip="$(/usr/sbin/ipconfig getifaddr "$interface" 2>/dev/null)" || continue
  case "$ip" in 10.*|192.168.*|172.1[6-9].*|172.2[0-9].*|172.3[01].*) printf '%s\n' "$ip"; return 0;; esac
 done
 return 1
}
while :; do
 if ! ip="$(lan_address)"; then
  echo 'Waiting for a normal private IPv4 LAN connection.' >&2; sleep 30; continue
 fi
 # Probe the LAN address, not just localhost. A blocked/unshared endpoint must
 # not be advertised as ready. Probe issues only Get-Printer-Attributes and
 # Validate-Job, never Print-Job or Send-Document.
 if ! uuid="$(./probe --uuid "$ip")"; then
  echo 'Sharing/IPP checks failed; Bonjour announcement paused.' >&2; sleep 30; continue
 fi
 printf 'Announcing PDF-only trial printer over Bonjour; IPP endpoint %s:631.\n' "$ip"
 /usr/bin/dns-sd -R 'LQ615KII iPhone PDF' '_ipp._tcp,_universal' 'local.' 631 \
  'txtvers=1' 'qtotal=1' 'rp=printers/LQ615KII_Local241' \
  'ty=LQ615KII via Mac - 241x140 PDF' 'product=(LQ615KII via Mac)' \
  'pdl=application/pdf' 'URF=none' 'Color=F' 'Duplex=F' \
  'priority=0' 'air=none' "UUID=$uuid" \
  'note=241x140mm PDF - driver applies 90 percent' &
 service_pid=$!
 while kill -0 "$service_pid" 2>/dev/null; do
  sleep 30
  new_ip="$(lan_address)" || break
  [ "$new_ip" = "$ip" ] || break
  new_uuid="$(./probe --uuid "$new_ip")" || break
  [ "$new_uuid" = "$uuid" ] || break
 done
 cleanup
 sleep 5
done
