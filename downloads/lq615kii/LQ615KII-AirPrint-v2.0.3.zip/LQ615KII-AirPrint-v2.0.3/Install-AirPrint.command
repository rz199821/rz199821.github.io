#!/bin/bash
set -euo pipefail
umask 077
cd "$(dirname "$0")"
bundle="$PWD"
prefix="$HOME/Library/Application Support/LQ615KII-AirPrint-v2"
agent="$HOME/Library/LaunchAgents/local.lq615kii.airprint.v2.plist"
legacy="$HOME/Library/Application Support/LQ615KII-AirPrint"
oldagent="$HOME/Library/LaunchAgents/local.lq615kii.airprint.plist"
logs="$HOME/Library/Logs/LQ615KII-AirPrint-v2"
renderer='/Library/Printers/LQ615KII-Local/pdf615'
fail() { printf '\n安装未完成：%s\n' "$*" >&2; exit 1; }
[ "$(uname -s)" = Darwin ] || fail '请在Mac上运行。'
[ ! -e "$prefix" ] && [ ! -e "$agent" ] || fail '新版目录已经存在。请先运行Check-AirPrint.command查看；需要重装时先运行本包Uninstall-AirPrint.command。'
/usr/bin/lpstat -h localhost:631 -p LQ615KII_Local241 >/dev/null || fail '先安装并验证Mac系统打印队列。'
[ -x "$renderer" ] || fail '找不到现有PDF转换器，请先完成Mac系统驱动安装。'
old_active=0
old_moved=0
oldbackup="$legacy/LaunchAgent.before-v2.plist"
if [ -e "$oldagent" ]; then
 [ ! -e "$oldbackup" ] || fail '已有旧版启动配置备份，先检查或卸载对应v2安装。'
 [ -f "$legacy/OWNER" ] && [ "$(cat "$legacy/OWNER")" = local.lq615kii.airprint.v1 ] || fail '旧后台服务来源不明，未修改。'
 [ "$(/usr/bin/plutil -extract Label raw -o - "$oldagent")" = local.lq615kii.airprint ] || fail '旧启动配置不匹配，未修改。'
 if /bin/launchctl print "gui/$(id -u)/local.lq615kii.airprint" >/dev/null 2>&1; then old_active=1; fi
fi
/bin/bash "$bundle/Build.command"
[ "$("$renderer" count .build/preflight.pdf)" = 1 ] || fail '光栅转换后的PDF自检失败。'
"$renderer" render .build/preflight.pdf 1 .build/preflight.pbm - 90 128 ink-center 0 0 > .build/render.log 2>&1 || fail '原有驱动无法处理转换结果；请查看.build/render.log。'
# Exercise the real server without Bonjour or print operations before changing
# either LaunchAgent. Native TLS setup uses the normal user CUPS keychain.
mkdir -p .build/check-spool "$HOME/.cups"
server_pid=''
cleanup_probe() { if [ -n "$server_pid" ]; then kill "$server_pid" 2>/dev/null || true; wait "$server_pid" 2>/dev/null || true; fi; }
trap cleanup_probe EXIT
.build/ippeveprinter --no-web-forms -r off -n localhost -p 18639 \
 -a "$bundle/printer.conf" -d "$bundle/.build/check-spool" -c /usr/bin/false \
 'LQ615KII installation check' > .build/server-check.log 2>&1 &
server_pid=$!
ready=0
for attempt in 1 2 3 4 5; do
 /bin/sleep 1
 kill -0 "$server_pid" 2>/dev/null || break
 if .build/ipptool -T 5 -t ipp://localhost:18639/ipp/print check-receiver.test > .build/protocol-check.log 2>&1; then ready=1; break; fi
done
if [ "$ready" = 1 ] && ! .build/ipptool -T 20 -t ipps://localhost:18639/ipp/print check-receiver.test > .build/https-check.log 2>&1; then ready=0; fi
cleanup_probe
server_pid=''
trap - EXIT
[ "$ready" = 1 ] || fail '真实IPP接收服务自检失败；查看.build/server-check.log和protocol-check.log。旧服务未修改；HTTPS结果见.build/https-check.log。'
printf '接收与转换自检通过，准备安装用户后台服务（不发送测试页）…\n'
mkdir -p "$prefix" "$prefix/spool" "$logs" "$HOME/Library/LaunchAgents"
printf 'local.lq615kii.airprint.v2\n' > "$prefix/OWNER"
# Roll back only this install if registration or the new service fails.
committed=0
rollback() {
 [ "$committed" = 0 ] || return 0
 /bin/launchctl bootout "gui/$(id -u)/local.lq615kii.airprint.v2" 2>/dev/null || true
 /bin/rm -f "$agent"
 # The marked partial installation stays for its matching uninstaller/logs.
 if [ "$old_moved" = 1 ] && [ -f "$oldbackup" ]; then /bin/mv "$oldbackup" "$oldagent"; fi
 if [ "$old_active" = 1 ]; then /bin/launchctl bootstrap "gui/$(id -u)" "$oldagent" 2>/dev/null || true; fi
 printf '新版未完成启动，原有Mac驱动保留；已尝试恢复旧发现服务。\n' >&2
}
trap rollback EXIT
for program in ippeveprinter ipptool raster615; do /usr/bin/install -m 755 ".build/$program" "$prefix/$program"; done
for script in spool-job.sh run-service.sh; do /usr/bin/install -m 700 "$script" "$prefix/$script"; done
/usr/bin/install -m 600 printer.conf check-receiver.test "$prefix/"
xml() { printf '%s' "$1" | /usr/bin/sed -e 's/&/\&amp;/g' -e 's/</\&lt;/g' -e 's/>/\&gt;/g'; }
cat > "$agent" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>Label</key><string>local.lq615kii.airprint.v2</string>
<key>ProgramArguments</key><array><string>/bin/bash</string><string>$(xml "$prefix/run-service.sh")</string></array>
<key>RunAtLoad</key><true/><key>KeepAlive</key><true/>
<key>ThrottleInterval</key><integer>30</integer>
<key>StandardOutPath</key><string>$(xml "$logs/service.log")</string>
<key>StandardErrorPath</key><string>$(xml "$logs/error.log")</string>
</dict></plist>
PLIST
chmod 600 "$agent"
/usr/bin/plutil -lint "$agent"
if [ -e "$oldagent" ]; then
 printf '%s\n' "$old_active" > "$prefix/restore-v1"
 if [ "$old_active" = 1 ]; then /bin/launchctl bootout "gui/$(id -u)/local.lq615kii.airprint"; fi
 # Move the old plist outside LaunchAgents so it cannot return next login.
 /bin/mv "$oldagent" "$oldbackup"
 old_moved=1
fi
/bin/launchctl bootstrap "gui/$(id -u)" "$agent"
ready=0
receiver_host="$(/usr/sbin/scutil --get LocalHostName).local."
for attempt in 1 2 3 4 5; do
 /bin/sleep 1
 if "$prefix/ipptool" -T 20 -t "ipps://$receiver_host:8631/ipp/print" "$prefix/check-receiver.test" > "$logs/installed-check.log" 2>&1; then ready=1; break; fi
done
[ "$ready" = 1 ] || fail '后台接收服务未通过检查；日志在~/Library/Logs/LQ615KII-AirPrint-v2。'
committed=1
trap - EXIT
printf '\n新版接收服务已启动，Mac驱动保留。没有发送打印任务。\n'
printf 'iPhone与Mac接同一可互通Wi-Fi，Mac保持登录、不休眠、USB连接打印机。\n'
printf '重新打开手机打印面板，选择 LQ615KII iPhone v2。\n'
printf '先用单页241×140mm PDF、1页1份测试。纸型/预览变成A4或信纸时先不要打印。\n'
printf '90%%、标准较细、左右居中、顶部对齐由Mac驱动执行。\n'
printf '若防火墙询问，允许本工具ippeveprinter接收局域网连接；无需关闭防火墙。\n'
printf '协议自检已通过；手机发现和实机纸面结果仍需本次验证。\n'
