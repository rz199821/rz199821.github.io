#!/bin/bash
set -euo pipefail
umask 077
cd "$(dirname "$0")"
fail() { printf '\n编译未完成：%s\n' "$*" >&2; exit 1; }
[ "$(uname -s)" = Darwin ] || fail '请在Mac上运行。'
xcrun --find clang >/dev/null 2>&1 || fail '需要Apple命令行工具；运行 xcode-select --install 后安装。无需完整Xcode。'
mkdir -p .build
printf '校验内附源码（本次无需联网下载）…\n'
[ "$(/usr/bin/shasum -a 256 vendor/cups-2.4.16.tar.gz | /usr/bin/awk '{print $1}')" = 0339587204b4f9428dd0592eb301dec0bf9ea6ea8dce5d9690d56be585aba92d ] || fail '源码校验失败，请重新下载完整安装包。'
# Build from a fresh tree; never install/replace the macOS CUPS system service.
if [ -e .build/cups-2.4.16 ]; then /bin/rm -rf .build/cups-2.4.16; fi
/usr/bin/tar -xzf vendor/cups-2.4.16.tar.gz -C .build
/usr/bin/patch -s -d .build/cups-2.4.16 -p1 < server.patch
printf '正在编译接收服务，老Mac可能需要几分钟。详细记录：%s/.build/build.log\n' "$PWD"
(
 cd .build/cups-2.4.16
 ./configure --with-components=libcupslite --enable-static --disable-shared \
  --disable-gssapi --disable-pam --disable-dbus --disable-avahi --with-tls=cdsa
 /usr/bin/grep -q '^#define HAVE_TLS 1' config.h
 /usr/bin/grep -q '^#define HAVE_MDNSRESPONDER 1' config.h
 /usr/bin/make -C cups -j2 libcups.a
 /usr/bin/make -C tools -j2 ippeveprinter-static ipptool-static
) > .build/build.log 2>&1 || { /usr/bin/tail -n 20 .build/build.log >&2; fail '详见.build/build.log。原有驱动和服务未修改。'; }
/usr/bin/install -m 755 .build/cups-2.4.16/tools/ippeveprinter-static .build/ippeveprinter
/usr/bin/install -m 755 .build/cups-2.4.16/tools/ipptool-static .build/ipptool
# Public raster API is ABI-compatible with the Mac system libcups. Include
# bundled public headers, link the actual native library, and test URF decoding.
xcrun clang -O2 -Wall -Wextra -Werror -I .build/cups-2.4.16 raster615.c -lcups -lz -o .build/raster615
xcrun clang -O2 -Wall -Wextra -Werror -I .build/cups-2.4.16 tests/fixture.c -lcups -o .build/fixture
for program in ippeveprinter ipptool raster615; do
 /usr/bin/codesign --force --sign - --timestamp=none --identifier "local.lq615kii.airprint.$program" ".build/$program"
 /usr/bin/codesign --verify --strict ".build/$program"
done
.build/fixture .build/preflight.urf 0 1 0
.build/raster615 .build/preflight.urf .build/preflight.pdf
printf '接收服务及URF解码编译完成；未发送打印任务。\n'
