# 手机接收服务：已合并实机成功修复

普通安装请使用整合包最外层 Install.command，不需要分别执行这里的脚本。

核心流程：iPhone通过Bonjour发现用户级IPP服务 → 通过HTTPS发送PDF/URF/PWG → 原生libcups解码光栅为原尺寸PDF → 现有PDFKit转换器验证241×140mm单页内容 → 提交本机LQ615KII_Local241队列。90%缩放由USB驱动执行一次。

用户已在macOS12.2.1/Intel、iOS27.2及USB LQ-615KII上确认实际出纸正常。这份整理包合并成功时的源码修复；新Mac的首次完整安装仍需本机自检和单页试打。

## 运行方式

使用当前Mac账户的LaunchAgent local.lq615kii.airprint.v2，监听TCP8631，发现名称LQ615KII iPhone v2。用户目录为 ~/Library/Application Support/LQ615KII-AirPrint-v2，日志为 ~/Library/Logs/LQ615KII-AirPrint-v2。Mac需要保持账户登录、不休眠，并用USB连接打印机。

本服务不修改系统CUPS，不需要额外开启系统打印机共享。TLS由CUPS原生后端处理；macOS使用正常用户CUPS密钥链 ~/.cups/ssl.keychain。没有关闭证书校验、添加系统信任证书或降低编译检查。服务面向可互通的可信局域网，采用普通局域网打印入口的无密码请求方式。

安装前编译和签名检查完成后，会实际解码URF、用原有PDFKit转换器预检，再验证HTTP和HTTPS Get-Printer-Attributes/Validate-Job。只读检查不创建打印任务。验证通过后才注册本工具的用户服务；原来的USB驱动保留。

已有旧版v1发现服务时，安装器会将其启动配置移出LaunchAgents保留，并在卸载本接收服务时按记录恢复。已有v2目录时不会盲目覆盖。

## 范围

输入为241×140mm横向单页PDF，或同等尺寸的Apple URF/PWG光栅；每次单页、单份、单面。广播仅声明已实现的单色W8及黑1/灰8、300/600dpi。解码器另可读取RGB24并转灰度，但不广播彩色打印能力。

完整转换、页数和内容预检之后才送入本机USB队列。不同纸型、多页、双面、多份、不完整光栅和渲染错误会停止。手机显示完成仅说明已提交Mac队列，后续手机取消不会自动取消已提交的USB任务；应在Mac打印队列中取消。

## 源码与修复

vendor/cups-2.4.16.tar.gz为官方OpenPrinting CUPS2.4.16源包；仅构建本服务自己的静态库、ippeveprinter和ipptool，不安装替换macOS系统CUPS。

上游来源： https://github.com/OpenPrinting/cups/releases/download/v2.4.16/cups-2.4.16-source.tar.gz

SHA256：0339587204b4f9428dd0592eb301dec0bf9ea6ea8dce5d9690d56be585aba92d

Apache2.0许可证和NOTICE见vendor。server.patch记录全部上游修改：加入PDF默认输入；禁用Print-URI/Send-URI及引用文件；限制单份及拒绝选项替代；不声明完整IPP Everywhere符合性；修正自定义纸型匹配；修正Darwin TLS错误调用的http实参；移除凭据助手对调用方已持有非递归锁的重复加锁。光栅程序在CUPS头文件之前加载Apple TargetConditionals.h。

31项Linux回环/转换检查见tests/VALIDATION.txt：真实IPP上传、Create-Job/Send-Document、真实光栅编解码及错误路径；实际HTTPS查询使用受信测试证书并验证主机名。测试仅模拟PDFKit和最终USB队列，没有触及硬件。普通安装无需Python、Pillow或Ghostscript。
