#!/bin/bash
set -euo pipefail
umask 077
cd "$(dirname "$0")"
prefix="$HOME/Library/Application Support/LQ615KII-AirPrint"
agent="$HOME/Library/LaunchAgents/local.lq615kii.airprint.plist"
logs="$HOME/Library/Logs/LQ615KII-AirPrint"
fail() { printf '\n未启用AirPrint试验服务：%s\n' "$*" >&2; exit 1; }
[ "$(uname -s)" = Darwin ] || fail '请在已安装并验证系统打印队列的Mac上运行。'
/usr/bin/lpstat -p LQ615KII_Local241 >/dev/null || fail '未找到现有LQ615KII_Local241队列，先完成Mac系统打印。'
[ ! -e "$prefix" ] && [ ! -e "$agent" ] || fail '已有同名服务或目录，保留现有内容；请先检查或用对应卸载工具移除。'
[ -x /usr/bin/dns-sd ] || fail '没有找到系统Bonjour注册工具。'
mkdir -p .build
xcrun clang -O2 -Wall -Wextra -Werror -std=c11 probe.c -lcups -o .build/probe
/usr/bin/codesign --force --sign - --timestamp=none --identifier local.lq615kii.airprint.probe .build/probe
/usr/bin/codesign --verify --strict .build/probe
# This is read-only and does not enable network sharing or alter CUPS policy.
.build/probe localhost || fail '请先在系统设置→通用→共享→打印机共享中，只共享LQ615KII_Local241对应队列。手机需要的打印权限也在该界面设置。'
first="$(/sbin/route -n get default 2>/dev/null | /usr/bin/awk '/interface:/ {print $2;exit}')"
ip=''
for interface in "$first" $(/sbin/ifconfig -l); do
 case "$interface" in en*) ;; *) continue;; esac
 candidate="$(/usr/sbin/ipconfig getifaddr "$interface" 2>/dev/null)" || continue
 case "$candidate" in 10.*|192.168.*|172.1[6-9].*|172.2[0-9].*|172.3[01].*) ip="$candidate"; break;; esac
done
[ -n "$ip" ] || fail '未找到普通私有IPv4局域网地址，请接入与手机互通的网络。'
.build/probe --uuid "$ip" > .build/queue-uuid.txt || fail '从局域网地址访问共享队列失败。先检查共享权限和系统防火墙，不要关闭整个防火墙。'
mkdir -p "$prefix" "$logs" "$HOME/Library/LaunchAgents"
chmod 700 "$prefix" "$logs"
printf 'local.lq615kii.airprint.v1\n' > "$prefix/OWNER"
/usr/bin/install -m 755 .build/probe "$prefix/probe"
/usr/bin/install -m 700 run-service.sh "$prefix/run-service.sh"
# XML-escape paths as data; never evaluate a user path as script code.
xml() { printf '%s' "$1" | /usr/bin/sed -e 's/&/\&amp;/g' -e 's/</\&lt;/g' -e 's/>/\&gt;/g'; }
cat > "$agent" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>Label</key><string>local.lq615kii.airprint</string>
<key>ProgramArguments</key><array><string>/bin/bash</string><string>$(xml "$prefix/run-service.sh")</string></array>
<key>RunAtLoad</key><true/><key>KeepAlive</key><true/>
<key>ThrottleInterval</key><integer>30</integer>
<key>StandardOutPath</key><string>$(xml "$logs/service.log")</string>
<key>StandardErrorPath</key><string>$(xml "$logs/error.log")</string>
</dict></plist>
PLIST
chmod 600 "$agent"
/usr/bin/plutil -lint "$agent"
/bin/launchctl bootstrap "gui/$(id -u)" "$agent" || fail '后台服务未启动；安装文件已保留，可用卸载工具移除。'
printf '\n后台发现服务已注册；手机能否发现和实际打印尚未验证。\n'
printf 'Mac保持登录、开机不休眠、USB连打印机；手机与Mac在互通的同一局域网。\n'
printf 'iPhone打开241×140mm PDF→共享→打印→选择LQ615KII iPhone PDF，先1页1份。\n'
printf '若手机纸型无法选择或PDF预览变成A4，先不要打印，把手机界面发来。\n'
printf '诊断日志保存在：%s\n' "$logs"
