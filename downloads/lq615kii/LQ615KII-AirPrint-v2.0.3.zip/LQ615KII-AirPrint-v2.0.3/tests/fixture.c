#if defined(__APPLE__)
#include <TargetConditionals.h>
#endif
#include <cups/raster.h>
#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
int main(int ac,char **av){
 if(ac!=5) return 1;
 int fd=open(av[1],O_CREAT|O_WRONLY|O_TRUNC,0600),mode=atoi(av[2]),pages=atoi(av[3]),kind=atoi(av[4]);
 cups_raster_t *r=cupsRasterOpen(fd,mode?CUPS_RASTER_WRITE_PWG:CUPS_RASTER_WRITE_APPLE);
 cups_page_header2_t h={0}; h.HWResolution[0]=h.HWResolution[1]=300;
 h.cupsWidth=2846; h.cupsHeight=1654;h.cupsBitsPerColor=kind==1?1:8;h.cupsBitsPerPixel=kind==2?24:kind==1?1:8;
 h.cupsColorSpace=kind==2?CUPS_CSPACE_SRGB:kind==1?CUPS_CSPACE_K:CUPS_CSPACE_SW;
 h.cupsNumColors=kind==2?3:1;h.cupsBytesPerLine=(h.cupsWidth*h.cupsBitsPerPixel+7)/8;
 h.cupsPageSize[0]=241*72/25.4;h.cupsPageSize[1]=140*72/25.4;h.PageSize[0]=h.cupsPageSize[0];h.PageSize[1]=h.cupsPageSize[1];h.NumCopies=1;
 if(getenv("F_DPI")) {h.HWResolution[0]=h.HWResolution[1]=600;h.cupsWidth*=2;h.cupsHeight*=2;}
 if(getenv("F_A4")) {h.cupsWidth=2480;h.cupsHeight=3508;}
 if(getenv("F_DUPLEX")) h.Duplex=1;
 if(kind==3) {h.cupsColorSpace=CUPS_CSPACE_CMYK;h.cupsNumColors=4;h.cupsBitsPerPixel=32;}
 h.cupsBytesPerLine=(h.cupsWidth*h.cupsBitsPerPixel+7)/8;
 unsigned char *row=malloc(h.cupsBytesPerLine);
 for(int p=0;p<pages;p++){
 if(!cupsRasterWriteHeader2(r,&h))return 2;
 for(unsigned y=0;y<h.cupsHeight;y++){
 memset(row,kind==1?0:255,h.cupsBytesPerLine);
 for(unsigned x=0;x<h.cupsWidth;x++){
 int mark=(y<180&&x<250)||(y>h.cupsHeight-50&&x>3*h.cupsWidth/4&&x<3*h.cupsWidth/4+50);
 if(kind==1){if(mark)row[x/8]|=128>>(x%8);}else if(kind==2){row[x*3]=row[x*3+1]=row[x*3+2]=mark?0:255;}else row[x]=mark?0:255;
 }
 if(cupsRasterWritePixels(r,row,h.cupsBytesPerLine)!=h.cupsBytesPerLine)return 3;
 }} free(row);cupsRasterClose(r);close(fd);return 0;
}
