#!/bin/bash
set -euo pipefail
umask 077
cd "$(dirname "$0")"
bundle="$PWD"
prefix="$HOME/Library/Application Support/LQ615KII-AirPrint-v2"
agent="$HOME/Library/LaunchAgents/local.lq615kii.airprint.v2.plist"
driver='/Library/Printers/LQ615KII-Local'
logs="$HOME/Library/Logs/LQ615KII-AirPrint-v2"
fail() { printf '\n多页更新未完成：%s\n' "$*" >&2;exit 1; }
[ "$(uname -s)" = Darwin ] || fail '请在已安装本项目桥接的Mac上运行。'
[ -f "$prefix/OWNER" ] && [ "$(cat "$prefix/OWNER")" = local.lq615kii.airprint.v2 ] || fail '未找到本项目手机桥接安装标记。'
[ -f "$agent" ] && [ "$(/usr/bin/plutil -extract Label raw -o - "$agent")" = local.lq615kii.airprint.v2 ] || fail '后台配置不匹配。'
[ -f "$driver/OWNER" ] && [ "$(cat "$driver/OWNER")" = local.lq615kii.systemqueue.v1 ] || fail '未找到本项目系统驱动。'
for name in pdf615 pbmto615 lq615filter; do /usr/bin/codesign --verify --strict "$driver/$name";done
xcrun --find clang >/dev/null 2>&1 || fail '找不到此前安装的Apple命令行工具。'
mkdir -p "$logs"
receiver_host="$(/usr/sbin/scutil --get LocalHostName).local."
ensure_idle() {
 local jobs
 jobs="$(/usr/bin/lpstat -h localhost:631 -o LQ615KII_Local241)" || fail '无法查询本机打印队列。'
 [ -z "$jobs" ] || fail '本机队列还有任务。请等待打印结束；若任务已卡住，请在Mac打印队列处理后重试。'
 "$prefix/ipptool" -T 15 -t "ipps://$receiver_host:8631/ipp/print" "$bundle/idle.test" > "$logs/multipage-idle.log" 2>&1 || fail '桥接尚有任务或HTTPS查询失败。先关闭手机打印面板、等待任务完成，再重试；记录在multipage-idle.log。'
}
ensure_idle
work="$(/usr/bin/mktemp -d "${TMPDIR:-/tmp}/lq615-multipage.XXXXXXXX")"
changed=0
committed=0
cleanup() {
 if [ "$changed" = 1 ] && [ "$committed" = 0 ]; then
  /bin/launchctl bootout "gui/$(id -u)/local.lq615kii.airprint.v2" 2>/dev/null || true
  for name in raster615 spool-job.sh printer.conf; do /bin/cp "$work/old-$name" "$prefix/$name";done
  /bin/launchctl bootstrap "gui/$(id -u)" "$agent" 2>/dev/null || true
  printf '更新未完成，已尝试恢复更新前的手机桥接。\n' >&2
 fi
 for name in raster615 spool-job.sh printer.conf; do /bin/rm -f "$prefix/$name.next";done
 /bin/rm -rf "$work"
}
trap cleanup EXIT
trap 'exit 1' HUP INT TERM
printf '[1/3] 编译多页光栅接收器…\n'
xcrun clang -O2 -Wall -Wextra -Werror -I "$bundle/include" "$bundle/raster615.c" -lcups -lz -o "$work/raster615"
/usr/bin/codesign --force --sign - --timestamp=none --identifier local.lq615kii.airprint.raster615 "$work/raster615"
/usr/bin/codesign --verify --strict "$work/raster615"
/bin/bash -n "$bundle/spool-job.sh"
printf '[2/3] 校验两页PDF与原系统驱动（仅生成文件，不打印）…\n'
"$work/raster615" "$bundle/sample-two-pages.urf" "$work/two-pages.pdf" > "$logs/multipage-decode.log" 2>&1 || fail '多页解码自检失败，详见multipage-decode.log。'
[ "$("$driver/pdf615" count "$work/two-pages.pdf")" = 2 ] || fail '本机PDFKit未确认两页。'
PPD="$driver/LQ615KII-241x140.ppd" "$driver/lq615filter" 1 "$USER" Multipage-Selftest 1 \
 'PageSize=LQ241x140 LQScale=S90 LQInk=Standard LQX=0 LQY=0' "$work/two-pages.pdf" \
 > "$work/two-pages.prn" 2> "$logs/multipage-filter.log" || fail '原系统驱动两页自检失败，详见multipage-filter.log。'
[ -s "$work/two-pages.prn" ] || fail '系统驱动未生成页面数据。'
/usr/bin/grep -q '^PAGE: 1 1' "$logs/multipage-filter.log" || fail '未确认第一页编码。'
/usr/bin/grep -q '^PAGE: 2 1' "$logs/multipage-filter.log" || fail '未确认第二页编码。'
# Preserve the user's printer name and all existing native TLS settings.
/usr/bin/perl -0pe 's/^ATTR boolean page-ranges-supported (?:false|true)\r?$/ATTR boolean page-ranges-supported true/m or die "Page-range setting not found\n";' "$prefix/printer.conf" > "$work/printer.conf"
for name in raster615 spool-job.sh printer.conf; do /bin/cp "$prefix/$name" "$work/old-$name";done
/usr/bin/install -m 755 "$work/raster615" "$prefix/raster615.next"
/usr/bin/install -m 700 "$bundle/spool-job.sh" "$prefix/spool-job.sh.next"
/usr/bin/install -m 600 "$work/printer.conf" "$prefix/printer.conf.next"
ensure_idle
printf '[3/3] 更新并重新检查HTTPS接收服务…\n'
changed=1
/bin/launchctl bootout "gui/$(id -u)/local.lq615kii.airprint.v2"
for name in raster615 spool-job.sh printer.conf; do /bin/mv -f "$prefix/$name.next" "$prefix/$name";done
/bin/launchctl bootstrap "gui/$(id -u)" "$agent"
ready=0
for attempt in 1 2 3; do
 /bin/sleep 1
 if "$prefix/ipptool" -T 20 -t "ipps://$receiver_host:8631/ipp/print" "$bundle/check-receiver.test" > "$logs/multipage-https.log" 2>&1; then ready=1;break;fi
done
[ "$ready" = 1 ] || { /usr/bin/tail -n 20 "$logs/multipage-https.log";fail '更新后的能力查询未通过。'; }
committed=1
printf '\n手机桥接已支持多页，打印机名称保持不变。更新过程没有打印。\n'
printf '关闭手机打印面板后重新进入。先选一个两页、每页241×140mm的PDF，1份测试。\n'
printf '全部选中页会先检查，再交给Mac队列；页数多时开始打印前的等待也会增加。\n'
printf '每页退纸后再放下一张，90%%、标准较细和顶部对齐保持。\n'
printf '本次仅完成本机文件/协议自检，多页走纸仍需这次实机测试确认。\n'
