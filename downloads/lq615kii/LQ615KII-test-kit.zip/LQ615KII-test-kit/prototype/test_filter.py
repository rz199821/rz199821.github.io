import subprocess, unittest
from pathlib import Path
EXE=str(Path(__file__).with_name('pbmto615'))
def run(data,*args): return subprocess.run([EXE,*args],input=data,capture_output=True)
def pbm(w,h,data): return f'P4\n{w} {h}\n'.encode()+data
class FilterTest(unittest.TestCase):
 def test_pins_and_column_order(self):
  # Independent wire inspection: dots at (0,0),(0,7),(0,8),(0,23),(1,1).
  rows=bytearray(24); rows[0]=128; rows[7]=128; rows[8]=128; rows[23]=128; rows[1]=64
  p=run(pbm(2,24,rows)); self.assertEqual(p.returncode,0)
  self.assertIn(bytes([27,42,39,2,0,129,128,1,64,0,0]),p.stdout)
  self.assertTrue(p.stdout.endswith(bytes([12,27,64,13])))
 def test_second_band_padding(self):
  p=run(pbm(1,25,b'\0'*24+b'\x80')); self.assertEqual(p.returncode,0)
  self.assertEqual(p.stdout.count(bytes([27,42,39,1,0])),2)
  self.assertIn(bytes([13,27,74,24,13,27,36,44,0,27,42,39,1,0,128,0,0]),p.stdout)
 def test_reject_bad_jobs_without_output(self):
  for data in [b'%PDF-1.7',pbm(1,1,b''),pbm(1444,1,b'\0'*181),pbm(1,2045,b'\0'*2045),pbm(1,1,b'\0extra'),b'P4\n0 1\n',b'P4\n1x 1\n']:
   with self.subTest(data=data[:30]):
    p=run(data); self.assertNotEqual(p.returncode,0); self.assertEqual(p.stdout,b'')
 def test_binary_whitespace_preserved(self):
  p=run(b'P4\n# comment\n8 1\n\x0a'); self.assertEqual(p.returncode,0)
  marker=bytes([27,42,39,8,0]); payload=p.stdout.split(marker)[1][:24]
  self.assertEqual(payload[4*3],128); self.assertEqual(payload[6*3],128)
 def test_d4_is_explicit(self):
  data=pbm(1,1,b'\0'); self.assertFalse(run(data).stdout.startswith(b'\0'))
  self.assertTrue(run(data,'--d4').stdout.startswith(b'\0\0\0\x1b\x01@EJL 1284.4\n'))
 def test_cups_bad_options(self):
  p=run(pbm(1,1,b'\0'),'1','user','job','1','landscape'); self.assertNotEqual(p.returncode,0); self.assertEqual(p.stdout,b'')
 def test_max_area(self):
  p=run(pbm(1443,2044,b'\0'*(181*2044))); self.assertEqual(p.returncode,0)
  self.assertEqual(p.stdout.count(bytes([27,42,39,163,5])),86)
if __name__=='__main__': unittest.main(verbosity=2)
